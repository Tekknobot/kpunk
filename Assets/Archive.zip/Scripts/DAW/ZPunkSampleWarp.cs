using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZPunk.DAW
{
    /// <summary>
    /// Offline, pitch-preserving, transient-protected WSOLA time stretch.
    /// Optional playhead-anchored beat alignment locks prominent attacks near
    /// quarter-note positions (1, 2, 3, 4), while less important transients
    /// remain unquantized. This is NOT Ableton's proprietary Complex Pro engine.
    /// Original AudioClip data is never modified. Long processing is cooperative.
    /// </summary>
    public static class ZPunkSampleWarp
    {
        // A 46ms Hann grain with 75% overlap reduces flutter and audible
        // re-triggering of sustained tones compared with the old 23ms/50% grains.
        // The original phase of each source grain is preserved (no resampling).
        private const int WindowSize = 2048;
        private const int SynthesisHop = 512;
        private const int AnalysisHop = 512;
        private static readonly float[] Hann = MakeWindow();

        private struct WarpPoint
        {
            public int source;
            public int destination;
            public WarpPoint(int src, int dst) { source = src; destination = dst; }
        }

        private static float[] MakeWindow()
        {
            var window = new float[WindowSize];
            for (int i = 0; i < window.Length; i++)
                window[i] = .5f - .5f * Mathf.Cos(2f * Mathf.PI * (i + .5f) / WindowSize);
            return window;
        }

        // These are *suggested* attack locations, not stem separation. Classification
        // is based on low-frequency versus broadband onset energy and is intentionally
        // displayed as an estimate, not a guaranteed kick/snare identification.
        /// <summary>
        /// Original-to-output sample positions produced by the actual warp curve.
        /// Normalized coordinates let amber guides follow beat alignment without
        /// scanning the rendered audio a second time.
        /// </summary>
        public struct TimeMapPoint
        {
            public float source01;
            public float destination01;
            public TimeMapPoint(float source, float destination)
            {
                source01 = source;
                destination01 = destination;
            }
        }

        /// <summary>
        /// Warp already computed the exact piecewise-linear timing map: reuse it
        /// to move cached source hit guides onto the displayed sample timeline.
        /// The original guide coordinates are never mutated.
        /// </summary>
        public static List<TransientHint> RemapTransientHints(
            List<TransientHint> original, List<TimeMapPoint> map)
        {
            if (original == null) return new List<TransientHint>();
            if (map == null || map.Count < 2) return new List<TransientHint>(original);
            var remapped = new List<TransientHint>(original.Count);
            int segment = 0;
            foreach (var hit in original)
            {
                float source = Mathf.Clamp01(hit.position01);
                while (segment + 2 < map.Count && source > map[segment + 1].source01)
                    segment++;
                TimeMapPoint left = map[segment], right = map[segment + 1];
                float fraction = Mathf.Clamp01((source - left.source01) /
                    Mathf.Max(.0000001f, right.source01 - left.source01));
                float destination = Mathf.Lerp(left.destination01, right.destination01, fraction);
                remapped.Add(new TransientHint(Mathf.Clamp01(destination), hit.kick, hit.strength));
            }
            return remapped;
        }

        public struct TransientHint
        {
            public float position01;
            public bool kick;
            // Normalized onset intensity: used to distinguish prominent
            // kick/snare attacks from soft hats when selecting beat slices.
            public float strength;
            public TransientHint(float position, bool isKick, float intensity = 1f)
            { position01 = position; kick = isKick; strength = intensity; }
        }
        /// <summary>One numbered quarter-note in ORIGINAL song coordinates.
        /// Detected attacks refine source positions but never change beat numbers.
        /// This is a tempo-grid estimate, not variable-tempo warping.</summary>
        public struct SourceBeat
        {
            public int index;
            public float seconds;
            public bool hitAligned;
            public SourceBeat(int number, float time, bool aligned)
            { index = number; seconds = time; hitAligned = aligned; }
        }

        /// <summary>
        /// Scan the original intro for sustained audible material. A small adaptive
        /// noise threshold and three consecutive RMS windows avoid one-off clicks.
        /// A quiet intro is not necessarily a downbeat: beat inference is separate.
        /// Work in bounded buffers and yield for mobile responsiveness.
        /// </summary>
        public static IEnumerator DetectLeadingSilence(AudioClip source,
            Action<float> complete, Func<bool> cancelled = null)
        {
            if (source == null || source.frequency <= 0 || source.samples <= 0)
            { complete?.Invoke(0f); yield break; }
            const int hop = 512;
            const int chunk = 8192;
            int channels = source.channels;
            int limit = Mathf.Min(source.samples, source.frequency * 30);
            var levels = new List<float>(Mathf.CeilToInt(limit / (float)hop));
            var buffer = new float[chunk * channels];
            double energy = 0;
            int accumulated = 0;
            float peak = 0f;
            for (int at = 0; at < limit; at += chunk)
            {
                if (cancelled != null && cancelled()) yield break;
                int count = Mathf.Min(chunk, limit - at);
                if (!source.GetData(buffer, at))
                { complete?.Invoke(0f); yield break; }
                for (int i = 0; i < count; i++)
                {
                    double monoEnergy = 0;
                    for (int channel = 0; channel < channels; channel++)
                    {
                        float sample = buffer[i * channels + channel];
                        monoEnergy += sample * (double)sample;
                    }
                    energy += monoEnergy / channels;
                    if (++accumulated != hop) continue;
                    float rms = (float)Math.Sqrt(energy / accumulated);
                    levels.Add(rms);
                    peak = Mathf.Max(peak, rms);
                    accumulated = 0;
                    energy = 0;
                }
                yield return null;
            }
            if (levels.Count == 0 || peak < .0004f)
            { complete?.Invoke(0f); yield break; }
            // -58 dBFS floor, while rejecting low-level hiss in a louder file.
            float threshold = Mathf.Max(.00125f, peak * .024f);
            int firstWindow = -1;
            for (int i = 0; i + 2 < levels.Count; i++)
            {
                if (levels[i] > threshold && levels[i + 1] > threshold &&
                    levels[i + 2] > threshold)
                { firstWindow = i; break; }
            }
            complete?.Invoke(firstWindow < 0 ? 0f :
                Mathf.Max(0f, (firstWindow * hop - hop) / (float)source.frequency));
        }

        /// <summary>
        /// Estimate the first reliable QUARTER-NOTE pulse near the beginning.
        /// Bar-one ambiguity cannot be solved from kicks/snares in every song;
        /// user HEAD remains the authoritative way to identify downbeat 1.
        /// </summary>
        public static bool EstimateFirstPulse(List<TransientHint> hits,
            float durationSeconds, float bpm, float audibleStartSeconds,
            out float originSeconds, out float confidence)
        {
            originSeconds = Mathf.Clamp(audibleStartSeconds, 0f, durationSeconds);
            confidence = 0f;
            if (hits == null || hits.Count < 5 || bpm < 30f ||
                durationSeconds <= 0f) return false;
            double beat = 60.0 / bpm;
            double searchEnd = Math.Min(durationSeconds, audibleStartSeconds + 35.0);
            double tolerance = Math.Min(.052, beat * .115);
            const int bins = 96;
            double bestScore = 0, total = 0;
            int bestBin = 0, evidence = 0;
            foreach (var hit in hits)
            {
                double sec = hit.position01 * durationSeconds;
                if (sec + tolerance < audibleStartSeconds || sec > searchEnd ||
                    hit.strength < .5f) continue;
                double weight = Math.Min(2.0, hit.strength) * (hit.kick ? 1.55 : 1.0);
                total += weight;
                evidence++;
            }
            if (evidence < 5) return false;
            for (int bin = 0; bin < bins; bin++)
            {
                double phase = beat * bin / bins;
                double score = 0;
                foreach (var hit in hits)
                {
                    double sec = hit.position01 * durationSeconds;
                    if (sec + tolerance < audibleStartSeconds || sec > searchEnd ||
                        hit.strength < .5f) continue;
                    double distance = Math.Abs((sec - phase + beat * 4096.5) % beat - beat * .5);
                    if (distance >= tolerance) continue;
                    score += Math.Min(2.0, hit.strength) * (hit.kick ? 1.55 : 1.0) *
                        (1.0 - distance / tolerance);
                }
                if (score > bestScore) { bestScore = score; bestBin = bin; }
            }
            confidence = Mathf.Clamp01((float)(bestScore / Math.Max(.00001, total)));
            if (confidence < .20f || bestScore < 3.0) return false;
            double phaseSeconds = bestBin * beat / bins;
            // Walk forward to the first strong attack that belongs to this phase.
            // Do not align an opening pickup to a later, fabricated bar one.
            double first = double.MaxValue;
            foreach (var hit in hits)
            {
                double sec = hit.position01 * durationSeconds;
                if (sec + tolerance < audibleStartSeconds || sec > searchEnd ||
                    hit.strength < (hit.kick ? .6f : .75f)) continue;
                double distance = Math.Abs((sec - phaseSeconds + beat * 4096.5) % beat - beat * .5);
                if (distance < tolerance && sec < first) first = sec;
            }
            if (first == double.MaxValue) return false;
            originSeconds = Mathf.Clamp((float)first, 0f, durationSeconds);
            return true;
        }

        /// <summary>
        /// Create a source-wide numbered beat timeline. Only confident nearby
        /// attacks refine source positions (<=50ms), and every beat retains an
        /// evenly spaced target position after the selected-region warp.
        /// </summary>
        public static List<SourceBeat> BuildSourceBeatMap(List<TransientHint> hits,
            float durationSeconds, float bpm, float originSeconds)
        {
            var map = new List<SourceBeat>();
            if (durationSeconds <= 0f || bpm <= 0f) return map;
            double beat = 60.0 / bpm;
            int first = Math.Max(-20000, (int)Math.Ceiling(-originSeconds / beat));
            int last = Math.Min(20000, (int)Math.Floor((durationSeconds - originSeconds) / beat));
            double tolerance = Math.Min(.050, beat * .115);
            double previous = -1.0;
            for (int index = first; index <= last; index++)
            {
                double ideal = originSeconds + index * beat;
                double refined = ideal;
                double best = double.NegativeInfinity;
                if (index != 0 && hits != null)
                {
                    foreach (var hint in hits)
                    {
                        if (hint.strength < (hint.kick ? .50f : .65f)) continue;
                        double candidate = hint.position01 * durationSeconds;
                        double distance = Math.Abs(candidate - ideal);
                        if (distance > tolerance) continue;
                        double score = 1.0 - .72 * distance / tolerance +
                            .14 * Math.Min(2.0, hint.strength) + (hint.kick ? .05 : 0);
                        if (score <= best) continue;
                        refined = candidate;
                        best = score;
                    }
                }
                if (refined <= previous + Math.Min(.06, beat * .35))
                    refined = ideal; // No duplicate/non-monotonic beats.
                if (refined < 0 || refined > durationSeconds) continue;
                map.Add(new SourceBeat(index, (float)refined,
                    best > double.NegativeInfinity && refined != ideal));
                previous = refined;
            }
            return map;
        }

        private struct AttackCandidate
        {
            public int frame;
            public float strength;
            public bool kick;
            public AttackCandidate(int at, float value, bool isKick)
            { frame = at; strength = value; kick = isKick; }
        }

        // 2.1.0b: attack placement is based on the first sustained rise above a
        // locally measured floor, NOT a local energy maximum. This is also used
        // to align guides with actually rendered warped PCM; WSOLA overlap can
        // shift/smear attacks by more than one analysis hop. All offsets here
        // are in AUDIO SAMPLE FRAMES, never pixels or UI display coordinates.
        private static int RefineAttackFrame(AudioClip clip, int estimate,
            ref float[] pcm, ref float[] envelope)
        {
            int rate = clip.frequency;
            int channels = clip.channels;
            int start = Mathf.Max(0, estimate - Mathf.RoundToInt(rate * .072f));
            int end = Mathf.Min(clip.samples, estimate + Mathf.RoundToInt(rate * .017f));
            int frames = end - start;
            if (frames < 64) return Mathf.Clamp(estimate, 0, clip.samples - 1);
            int needed = frames * channels;
            if (pcm == null || pcm.Length < needed) pcm = new float[needed];
            if (!clip.GetData(pcm, start)) return Mathf.Clamp(estimate, 0, clip.samples - 1);

            int step = Mathf.Max(8, Mathf.RoundToInt(rate * .0005f));
            int bins = frames / step;
            if (bins < 8) return Mathf.Clamp(estimate, 0, clip.samples - 1);
            if (envelope == null || envelope.Length < bins) envelope = new float[bins];
            // Stereo RMS energy, never (L+R)/2; opposing channels must not cancel.
            for (int b = 0; b < bins; b++)
            {
                double power = 0d;
                for (int i = b * step; i < (b + 1) * step; ++i)
                {
                    int p = i * channels;
                    for (int c = 0; c < channels; ++c)
                    {
                        float sample = pcm[p + c];
                        power += (double)sample * sample;
                    }
                }
                envelope[b] = Mathf.Sqrt((float)(power / (step * channels)));
            }

            int center = (estimate - start) / step;
            int searchFrom = Mathf.Max(4, center - Mathf.RoundToInt(rate * .055f / step));
            int searchTo = Mathf.Min(bins - 4, center + Mathf.RoundToInt(rate * .009f / step));
            int steepest = -1;
            float bestSlope = 0f;
            for (int b = searchFrom; b <= searchTo; ++b)
            {
                float before = (envelope[b - 3] + 2f * envelope[b - 2] +
                    2f * envelope[b - 1] + envelope[b]) / 6f;
                float after = (envelope[b] + 2f * envelope[b + 1] +
                    2f * envelope[b + 2] + envelope[b + 3]) / 6f;
                float slope = after - before;
                if (slope > bestSlope) { bestSlope = slope; steepest = b; }
            }
            if (steepest < 0 || bestSlope < .0003f)
                return Mathf.Clamp(estimate, 0, clip.samples - 1);

            int earliest = Mathf.Max(2, steepest - Mathf.RoundToInt(rate * .037f / step));
            // The 12% energy threshold used previously fell into the body of
            // soft/slow kicks. Use a 5% relative edge and adapt to local floor.
            // The floor is computed before the steep flank, not from the peak.
            float floor = float.MaxValue;
            for (int b = earliest; b < Mathf.Max(earliest + 1, steepest - 3); ++b)
                floor = Mathf.Min(floor, envelope[b]);
            if (floor == float.MaxValue) floor = envelope[earliest];
            float peak = envelope[steepest];
            for (int b = steepest + 1; b <= Mathf.Min(bins - 1, steepest + 7); ++b)
                peak = Mathf.Max(peak, envelope[b]);
            float excursion = peak - floor;
            if (excursion < .001f) return Mathf.Clamp(estimate, 0, clip.samples - 1);
            float threshold = floor + Mathf.Max(.00035f, excursion * .05f);

            // Find the quiet -> above-threshold transition immediately before
            // the dominant rise. Requiring two quiet bins reduces false triggers
            // on periodic zero crossings of bass-heavy sounds.
            int onset = steepest;
            bool found = false;
            for (int b = steepest - 1; b >= earliest + 2; --b)
            {
                if (envelope[b] <= threshold && envelope[b - 1] <= threshold)
                {
                    onset = b + 1;
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                // Dense audio may have no quiet gap: use the beginning of the
                // positive-slope region, not the late max-energy location.
                onset = steepest;
                for (int b = steepest - 1; b >= earliest + 2; --b)
                {
                    float slope = envelope[b + 1] - envelope[b - 1];
                    if (slope <= bestSlope * .15f) break;
                    onset = b;
                }
            }
            return Mathf.Clamp(start + onset * step, 0, clip.samples - 1);
        }

        /// <summary>
        /// After rendering, place DISPLAY guides against the PCM that the
        /// listener actually hears. A piecewise warp time map predicts the
        /// timing but WSOLA synthesis can smear an attack around that estimate.
        /// The original on-disk/in-memory hit cache is NOT modified. Only the
        /// projected positions on the warped AudioClip receive small corrections.
        /// Intended to run once when a warp completes, never per UI redraw.
        /// </summary>
        public static List<TransientHint> RefineRenderedTransientHints(
            AudioClip warped, List<TransientHint> projected)
        {
            if (projected == null) return new List<TransientHint>();
            if (warped == null || warped.samples < 1024 || warped.frequency <= 0 ||
                warped.channels < 1 || warped.channels > 2)
                return new List<TransientHint>(projected);
            var aligned = new List<TransientHint>(projected.Count);
            float[] pcm = null, envelope = null;
            int last = -1;
            int minGap = Mathf.RoundToInt(warped.frequency * .022f);
            int maxEarly = Mathf.RoundToInt(warped.frequency * .057f);
            int maxLate = Mathf.RoundToInt(warped.frequency * .012f);
            int correctedCount = 0;
            float totalCorrectionMs = 0f, maxCorrectionMs = 0f;
            for (int i = 0; i < projected.Count; i++)
            {
                TransientHint guide = projected[i];
                int predicted = Mathf.Clamp(Mathf.RoundToInt(guide.position01 * warped.samples),
                    0, warped.samples - 1);
                int refined = RefineAttackFrame(warped, predicted, ref pcm, ref envelope);
                // Avoid snapping to an unrelated sound, even in dense mixes.
                if (refined < predicted - maxEarly || refined > predicted + maxLate ||
                    refined <= last + minGap)
                    refined = predicted;
                if (refined != predicted)
                {
                    correctedCount++;
                    float correctionMs = Mathf.Abs(predicted - refined) * 1000f / warped.frequency;
                    totalCorrectionMs += correctionMs;
                    maxCorrectionMs = Mathf.Max(maxCorrectionMs, correctionMs);
                }
                aligned.Add(new TransientHint(refined / (float)warped.samples,
                    guide.kick, guide.strength));
                last = refined;
            }
            ZPunkSampleAnalysisCache.Trace("RENDERED guide alignment / checked=" + projected.Count +
                " corrected=" + correctedCount + " avgMs=" +
                (correctedCount > 0 ? totalCorrectionMs / correctedCount : 0f).ToString("0.0") +
                " maxMs=" + maxCorrectionMs.ToString("0.0"));
            return aligned;
        }

        public static IEnumerator AnalyzeTransientHints(AudioClip clip,
            Action<List<TransientHint>> complete, Func<bool> cancelled = null,
            Action<float> progress = null)
        {
            var hints = new List<TransientHint>();
            if (clip == null || clip.samples < 1024 || clip.frequency <= 0 ||
                clip.channels < 1 || clip.channels > 2)
            { complete?.Invoke(hints); yield break; }

            int channels = clip.channels, rate = clip.frequency;
            const int hop = 512;
            const int chunkFrames = 16384;
            float[] buffer = new float[chunkFrames * channels];
            float bassL = 0, bassR = 0, presenceL = 0, presenceR = 0;
            float slowLow = 0, slowHigh = 0;
            float lowEnergy = 0, highEnergy = 0, sumStrength = 0;
            int accumulator = 0;
            float lowAlpha = 1f - Mathf.Exp(-2f * Mathf.PI * 190f / rate);
            float presenceAlpha = 1f - Mathf.Exp(-2f * Mathf.PI * 1800f / rate);
            var candidates = new List<AttackCandidate>();
            progress?.Invoke(0f);
            for (int offset = 0; offset < clip.samples; offset += chunkFrames)
            {
                if (cancelled != null && cancelled()) yield break;
                int length = Mathf.Min(chunkFrames, clip.samples - offset);
                if (!clip.GetData(buffer, offset))
                { complete?.Invoke(hints); yield break; }
                for (int i = 0; i < length; ++i)
                {
                    int at = i * channels;
                    float left = buffer[at];
                    float right = channels == 2 ? buffer[at + 1] : left;
                    bassL += lowAlpha * (left - bassL);
                    bassR += lowAlpha * (right - bassR);
                    presenceL += presenceAlpha * (left - presenceL);
                    presenceR += presenceAlpha * (right - presenceR);
                    float highL = left - presenceL;
                    float highR = right - presenceR;
                    lowEnergy += .5f * (bassL * bassL + bassR * bassR);
                    highEnergy += .5f * (highL * highL + highR * highR);
                    if (++accumulator != hop) continue;
                    float lo = Mathf.Sqrt(lowEnergy / hop);
                    float hi = Mathf.Sqrt(highEnergy / hop);
                    float onsetLow = Mathf.Max(0f, lo - slowLow * 1.15f);
                    float onsetHigh = Mathf.Max(0f, hi - slowHigh * 1.17f);
                    float strength = onsetLow * 1.45f + onsetHigh * .8f;
                    sumStrength += strength;
                    // Local contrast suppresses most steady tones and quiet noise.
                    if (strength > .001f && (onsetLow > slowLow * .13f ||
                        onsetHigh > slowHigh * .16f))
                        candidates.Add(new AttackCandidate(Mathf.Max(0, offset + i),
                            strength, onsetLow * 1.15f >= onsetHigh * .85f));
                    slowLow = .87f * slowLow + .13f * lo;
                    slowHigh = .87f * slowHigh + .13f * hi;
                    lowEnergy = highEnergy = 0f;
                    accumulator = 0;
                }
                progress?.Invoke(.84f * Mathf.Clamp01((offset + length) / (float)clip.samples));
                yield return null; // bounded PCM work on the main thread
            }
            float threshold = Mathf.Max(.0015f, sumStrength /
                Mathf.Max(1f, clip.samples / (float)hop) * 1.7f);
            int minimumSpacing = Mathf.RoundToInt(rate * .075f);
            // Keep the strongest candidate in each ~75ms neighborhood.
            var picked = new List<AttackCandidate>();
            int preserveIntroThrough = Mathf.Min(clip.samples,
                Mathf.RoundToInt(clip.frequency * 35f));
            foreach (var hit in candidates)
            {
                float localThreshold = hit.frame < preserveIntroThrough ?
                    threshold * .65f : threshold;
                if (hit.strength < localThreshold) continue;
                if (picked.Count > 0 && hit.frame - picked[picked.Count - 1].frame < minimumSpacing)
                {
                    if (hit.strength > picked[picked.Count - 1].strength)
                        picked[picked.Count - 1] = hit;
                }
                else picked.Add(hit);
            }
            // Reserve candidates from the opening 35 seconds as well as the
            // strongest from the rest. Otherwise a loud ending can evict the
            // opening beat evidence from a long imported song entirely.
            const int maxHints = 256;
            if (picked.Count > maxHints)
            {
                int introEnd = Mathf.Min(clip.samples,
                    Mathf.RoundToInt(clip.frequency * 35f));
                var intro = picked.FindAll(h => h.frame < introEnd);
                var later = picked.FindAll(h => h.frame >= introEnd);
                intro.Sort((a, b) => b.strength.CompareTo(a.strength));
                later.Sort((a, b) => b.strength.CompareTo(a.strength));
                if (intro.Count > 96) intro.RemoveRange(96, intro.Count - 96);
                int remaining = maxHints - intro.Count;
                if (later.Count > remaining) later.RemoveRange(remaining, later.Count - remaining);
                picked.Clear();
                picked.AddRange(intro);
                picked.AddRange(later);
                picked.Sort((a, b) => a.frame.CompareTo(b.frame));
            }
            progress?.Invoke(.86f);
            float[] detailPcm = null, detailEnvelope = null;
            int lastFrame = -minimumSpacing;
            for (int i = 0; i < picked.Count; i++)
            {
                if (cancelled != null && cancelled()) yield break;
                var hit = picked[i];
                int attackFrame = RefineAttackFrame(clip, hit.frame, ref detailPcm, ref detailEnvelope);
                // Refinement must not collapse distinct events into a duplicate.
                if (attackFrame - lastFrame < minimumSpacing / 2) continue;
                hints.Add(new TransientHint(Mathf.Clamp01(attackFrame / (float)clip.samples),
                    hit.kick, Mathf.Clamp(hit.strength / Mathf.Max(.001f, threshold * 2f), .1f, 2f)));
                lastFrame = attackFrame;
                if ((i & 31) == 31 || i == picked.Count - 1)
                {
                    progress?.Invoke(.86f + .14f * (i + 1) / Mathf.Max(1f, picked.Count));
                    if ((i & 31) == 31) yield return null;
                }
            }
            progress?.Invoke(1f);
            complete?.Invoke(hints);
        }

        // Duration-derived estimate only. For an untrimmed song, users must set
        // source BPM manually; guessing BPM from duration is not beat detection.
        public static float EstimateLoopBpm(AudioClip clip, float songBpm)
        {
            if (clip == null || clip.length < .35f) return 0f;
            float preferred = Mathf.Clamp(songBpm, 40f, 240f);
            float best = 0f, error = float.MaxValue;
            for (int bars = 1; bars <= 16384; bars *= 2)
            {
                float bpm = bars * 240f / clip.length;
                if (bpm < 40f || bpm > 240f) continue;
                float difference = Mathf.Abs(Mathf.Log(bpm / preferred));
                if (difference < error) { error = difference; best = bpm; }
            }
            return best > 0f ? Mathf.Round(best * 10f) / 10f : 0f;
        }

        /// <summary>
        /// Estimate SOURCE BPM from periodic attack times, not the duration of
        /// the file. Returns zero when timing is ambiguous. Half/double-time
        /// aliases cannot always be resolved in a mixed song; the user can
        /// override the result with the existing +/- source BPM controls.
        /// </summary>
        public static float EstimateRhythmicBpm(List<TransientHint> hits,
            float durationSeconds, float preferredBpm, out float confidence)
        {
            confidence = 0f;
            // A full song can have many weak hats, muted measures and intros;
            // use convincing percussive spacing and section-local pulse evidence.
            // Don't fabricate a tempo for truly non-rhythmic recordings.
            if (hits == null || hits.Count < 6 || durationSeconds < 3f)
                return 0f;

            int n = hits.Count;
            double[] times = new double[n], weights = new double[n];
            double[] sectionWeights = new double[3];
            int useful = 0;
            for (int i = 0; i < n; i++)
            {
                var hit = hits[i];
                // Weaker hats and incidental highs remain available as supporting
                // evidence, but kick-like low-frequency hits dominate the pulse.
                double strength = Math.Max(.1, Math.Min(2.0, hit.strength));
                double weight = Math.Sqrt(strength) * (hit.kick ? 1.75 : .95);
                if (strength < .65) weight *= .35;
                times[i] = Math.Max(0, Math.Min(durationSeconds, hit.position01 * durationSeconds));
                weights[i] = weight;
                if (strength >= .24) useful++;
                int section = Math.Min(2, (int)(3.0 * times[i] / durationSeconds));
                sectionWeights[section] += weight;
            }
            if (useful < 6) return 0f;

            // The spacing of strong attacks helps resolve 65/130 or 90/180
            // aliases without inventing a tempo from the file's length.
            var strongGaps = new List<double>();
            double lastStrong = -1;
            for (int i = 0; i < n; i++)
            {
                if (hits[i].strength < .8f) continue;
                if (lastStrong >= 0)
                {
                    double gap = times[i] - lastStrong;
                    if (gap >= .22 && gap <= 1.3) strongGaps.Add(gap);
                }
                lastStrong = times[i];
            }
            strongGaps.Sort();
            double primaryGap = strongGaps.Count >= 3 ?
                strongGaps[strongGaps.Count / 2] : 0;
            double bestScore = 0, winningPulse = 0, winningSpacing = 0;
            float bestBpm = 0;
            float preference = Mathf.Clamp(preferredBpm, 50f, 220f);
            // Evaluate the percussive beat interval directly. Section-specific
            // phase allows imperfect live performances to drift slightly rather
            // than cancelling a valid tempo over several minutes.
            // Coarse half-BPM sweep followed by tenths near the strongest
            // candidate. This saves most of the mobile CPU work versus a
            // 0.1-BPM brute-force sweep across the entire tempo range.
            double[] real = new double[3], imaginary = new double[3];
            for (int pass = 0; pass < 2; pass++)
            {
                int begin = pass == 0 ? 500 :
                    Math.Max(500, Mathf.RoundToInt(bestBpm * 10f) - 25);
                int end = pass == 0 ? 2200 :
                    Math.Min(2200, Mathf.RoundToInt(bestBpm * 10f) + 25);
                int step = pass == 0 ? 5 : 1;
                for (int tenth = begin; tenth <= end; tenth += step)
                {
                Array.Clear(real, 0, 3);
                Array.Clear(imaginary, 0, 3);
                double bpm = tenth * .1;
                double period = 60.0 / bpm;
                for (int i = 0; i < n; i++)
                {
                    double cycle = times[i] / period;
                    double angle = (cycle - Math.Floor(cycle)) * Math.PI * 2;
                    int section = Math.Min(2, (int)(3.0 * times[i] / durationSeconds));
                    real[section] += Math.Cos(angle) * weights[i];
                    imaginary[section] += Math.Sin(angle) * weights[i];
                }
                double pulse = 0, pulseWeight = 0;
                for (int section = 0; section < 3; section++)
                {
                    if (sectionWeights[section] < 2.5) continue;
                    // Bound the influence of a percussion-heavy section so a
                    // lengthy drum solo doesn't drown out other sections.
                    double influence = Math.Sqrt(sectionWeights[section]);
                    pulse += influence * Math.Sqrt(real[section] * real[section] +
                        imaginary[section] * imaginary[section]) / sectionWeights[section];
                    pulseWeight += influence;
                }
                if (pulseWeight <= 0) continue;
                pulse /= pulseWeight;

                // Look at the timing of nearby hits rather than song duration.
                // Include half-beat subdivisions while favoring recurring
                // quarter-note intervals between strong percussion attacks.
                double spacingMatched = 0, spacingPossible = 0;
                double eighth = period * .5;
                for (int i = 0; i < n; i++)
                {
                    if (weights[i] < .30) continue;
                    for (int j = i + 1; j < n && j <= i + 8; j++)
                    {
                        double delta = times[j] - times[i];
                        if (delta > period * 4.25) break;
                        if (delta < .10) continue;
                        int units = (int)Math.Round(delta / eighth);
                        if (units < 1 || units > 8) continue;
                        double gapWeight = Math.Sqrt(weights[i] * weights[j]) /
                            Math.Sqrt(units);
                        spacingPossible += gapWeight;
                        double error = Math.Abs(delta - units * eighth);
                        double tolerance = Math.Max(.025, Math.Min(.075, period * .12));
                        if (error < tolerance)
                            spacingMatched += gapWeight * (1.0 - error / tolerance) *
                                (units % 2 == 0 ? 1.0 : .67);
                    }
                }
                double spacing = spacingPossible > 0 ? spacingMatched / spacingPossible : 0;
                // Only use the project tempo as a weak alias tie-breaker.
                double prior = .025 * Math.Min(1.0, Math.Abs(Math.Log(bpm / preference)) / .70);
                double pulseGapBonus = 0;
                if (primaryGap > .0)
                {
                    double logError = Math.Log(period / primaryGap) / .18;
                    pulseGapBonus = .085 * Math.Exp(-.5 * logError * logError);
                }
                double score = .72 * pulse + .28 * spacing + pulseGapBonus - prior;
                if (score > bestScore)
                {
                    bestScore = score;
                    bestBpm = (float)bpm;
                    winningPulse = pulse;
                    winningSpacing = spacing;
                }
                }
            }
            // Confidence is a measure of rhythmic support, not a guaranteed
            // probability that a mixed recording's BPM is objectively correct.
            confidence = Mathf.Clamp01((float)(.73 * winningPulse +
                .27 * winningSpacing));
            if (bestScore < .235 || winningPulse < .18 || winningSpacing < .11)
                return 0f;
            return Mathf.Round(bestBpm * 10f) / 10f;
        }

        public static AudioClip Stretch(AudioClip source, float sourceBpm, float targetBpm,
            out string reason)
        {
            AudioClip result = null;
            string status = "WARP NOT STARTED";
            IEnumerator task = StretchAsync(source, sourceBpm, targetBpm,
                (clip, message) => { result = clip; status = message; });
            var pending = new Stack<IEnumerator>();
            pending.Push(task);
            while (pending.Count > 0)
            {
                IEnumerator current = pending.Peek();
                if (!current.MoveNext()) pending.Pop();
                else if (current.Current is IEnumerator nested) pending.Push(nested);
            }
            reason = status;
            return result;
        }

        /// <param name="progress">Normalized 0..1, with stage text.</param>
        /// <param name="beatAnchor01">Normalized ORIGINAL sample position of beat 1.
        /// Negative value preserves the legacy automatic warp behavior.</param>
        public static IEnumerator StretchAsync(AudioClip original, float sourceBpm,
            float targetBpm, Action<AudioClip, string> complete,
            Func<bool> cancelled = null, Action<float, string> progress = null,
            float beatAnchor01 = -1f,
            Action<List<TimeMapPoint>> timeMapReady = null,
            IList<float> chopBoundaries01 = null,
            IList<float> amberHitGuides01 = null,
            int gridBeatsPerChop = 0,
            IList<float> sourceGridBeats01 = null)
        {
            if (original == null) { complete?.Invoke(null, "NO SAMPLE"); yield break; }
            if (sourceBpm <= 0f || targetBpm <= 0f)
            { complete?.Invoke(null, "SET SOURCE BPM"); yield break; }
            int channels = original.channels;
            int sampleRate = original.frequency;
            if (channels < 1 || channels > 2 || original.samples < 1024 || sampleRate < 1)
            { complete?.Invoke(null, "UNSUPPORTED AUDIO FORMAT"); yield break; }
            float ratio = Mathf.Clamp(sourceBpm / targetBpm, .25f, 4f);
            // Don't resynthesize minutes of PCM when the tempo already matches.
            // Explicit HEAD alignment still needs the full beat-grid algorithm.
            if (beatAnchor01 < 0f && Mathf.Abs(ratio - 1f) < .0005f)
            {
                progress?.Invoke(1f, "TEMPO ALREADY MATCHED");
                complete?.Invoke(original, "ORIGINAL / TEMPO MATCHED");
                yield break;
            }
            long longCount = (long)Math.Round(original.samples * (double)ratio);
            if (longCount > int.MaxValue - 4096 || longCount < 1024)
            { complete?.Invoke(null, "EXCEEDS UNITY AUDIOCLIP LIMIT"); yield break; }
            int outputCount = (int)longCount;
            bool fixedBeatGrid = chopBoundaries01 != null && chopBoundaries01.Count >= 2 &&
                (gridBeatsPerChop == 1 || gridBeatsPerChop == 2 || gridBeatsPerChop == 4);
            if (fixedBeatGrid)
            {
                // Beat-anchored source markers may shift by a few milliseconds.
                // Do NOT inherit those shifts in the warped loop's total duration:
                // the last boundary must still end at an exact project beat.
                long fixedFrames = (long)Math.Round((chopBoundaries01.Count - 1) *
                    (double)gridBeatsPerChop * sampleRate * 60.0 / targetBpm);
                if (fixedFrames < 1024 || fixedFrames > int.MaxValue - 4096)
                { complete?.Invoke(null, "GRID REGION TOO LONG"); yield break; }
                outputCount = (int)fixedFrames;
            }
            // Native AudioClip memory is additive: the source, destination and
            // CHOPS voices may coexist during rendering. On low-RAM phones,
            // preserving the original is safer than an oversized allocation.
            long inputBytes = (long)original.samples * channels * sizeof(float);
            long outputBytes = (long)outputCount * channels * sizeof(float);
            long budget = SystemInfo.systemMemorySize > 0 && SystemInfo.systemMemorySize <= 3072
                ? 160L * 1024L * 1024L : 320L * 1024L * 1024L;
            if (inputBytes + outputBytes > budget)
            {
                complete?.Invoke(null, "WARP SKIPPED / AUDIO MEMORY LIMIT");
                yield break;
            }

            // Spectral-band energy onsets, analyzed in bounded buffers. No large
            // full-song PCM arrays or allocations on the audio callback thread.
            var strengths = new List<float>();
            var lowOnsets = new List<float>();
            var highOnsets = new List<float>();
            var positions = new List<int>();
            int analysisFrames = Math.Max(AnalysisHop, sampleRate / 4);
            var pcm = new float[analysisFrames * channels];
            float low = 0f, presence = 0f, slowLow = 0f, slowHigh = 0f;
            float lowPower = 0f, highPower = 0f, totalScore = 0f;
            int accumulator = 0, scan = 0;
            float lowFactor = 1f - Mathf.Exp(-2f * Mathf.PI * 190f / sampleRate);
            float presenceFactor = 1f - Mathf.Exp(-2f * Mathf.PI * 1800f / sampleRate);
            progress?.Invoke(0f, "FINDING TRANSIENTS");
            while (scan < original.samples)
            {
                if (cancelled != null && cancelled()) yield break;
                int count = Math.Min(analysisFrames, original.samples - scan);
                if (!original.GetData(pcm, scan))
                { complete?.Invoke(null, "PCM READ FAILED"); yield break; }
                for (int i = 0; i < count; ++i)
                {
                    float sample = 0f;
                    int offset = i * channels;
                    for (int c = 0; c < channels; c++) sample += pcm[offset + c];
                    sample /= channels;
                    low += lowFactor * (sample - low);
                    presence += presenceFactor * (sample - presence);
                    float high = sample - presence;
                    lowPower += low * low;
                    highPower += high * high;
                    if (++accumulator == AnalysisHop)
                    {
                        float lowRms = Mathf.Sqrt(lowPower / AnalysisHop);
                        float highRms = Mathf.Sqrt(highPower / AnalysisHop);
                        float lowRise = Mathf.Max(0f, lowRms - slowLow * 1.12f);
                        float highRise = Mathf.Max(0f, highRms - slowHigh * 1.16f);
                        float score = lowRise * 1.35f + highRise * .75f;
                        positions.Add(scan + i);
                        strengths.Add(score);
                        lowOnsets.Add(lowRise);
                        highOnsets.Add(highRise);
                        totalScore += score;
                        slowLow = .9f * slowLow + .1f * lowRms;
                        slowHigh = .9f * slowHigh + .1f * highRms;
                        lowPower = highPower = 0f;
                        accumulator = 0;
                    }
                }
                scan += count;
                progress?.Invoke(.25f * scan / original.samples, "FINDING TRANSIENTS");
                yield return null;
            }

            var points = new List<WarpPoint> { new WarpPoint(0, 0) };
            var attackFrames = new List<int>();
            float meanScore = totalScore / Mathf.Max(1, strengths.Count);
            float threshold = Mathf.Max(.0009f, meanScore * 1.8f);
            float[] attackPcm = null, attackEnvelope = null;
            int anchorBeatCount = 0, anchoredAlignedCount = 0;
            bool anchoredBeats = beatAnchor01 >= 0f && beatAnchor01 <= 1f;
            // A bounded chop warp uses the actual onset positions as anchors.
            // An FFT envelope peak can lag the visually refined amber marker;
            // the marker's source coordinate MUST be the warp control point.
            bool guidedChops = chopBoundaries01 != null && chopBoundaries01.Count >= 2;
            bool explicitGrid = guidedChops &&
                (gridBeatsPerChop == 1 || gridBeatsPerChop == 2 || gridBeatsPerChop == 4);
            if (anchoredBeats || guidedChops)
            {
                // The user's HEAD position explicitly establishes beat 1. Each
                // subsequent source beat is projected using the SOURCE tempo.
                // The best local percussion onset (not every hat/ghost hit) can
                // be locked to that beat's corresponding TARGET timeline position.
                // This avoids the old eighth-note nearest-peak quantizer.
                int sourceAnchor = Mathf.Clamp(Mathf.RoundToInt(beatAnchor01 * original.samples),
                    0, original.samples - 1);
                float sourceBeat = sampleRate * 60f / sourceBpm;
                float targetBeat = sampleRate * 60f / targetBpm;
                float targetAnchor = sourceAnchor * ratio;
                int firstBeat = Mathf.CeilToInt((0f - sourceAnchor) / sourceBeat);
                int lastBeat = Mathf.FloorToInt((original.samples - 1f - sourceAnchor) / sourceBeat);
                int beatWindow = Mathf.RoundToInt(Mathf.Min(sampleRate * .055f, sourceBeat * .12f));
                int searchBins = Mathf.Max(1, beatWindow / AnalysisHop + 2);
                int edgeGuard = Mathf.RoundToInt(sampleRate * .060f);
                var proposed = new List<WarpPoint>();
                if (guidedChops)
                {
                    // Marker-first warp: user-created boundaries are temporal
                    // anchors even when deliberately placed off the beat. Apply
                    // only a very small (<20ms) beat correction to a marker
                    // already near the destination grid; do not drag a hit by
                    // a quarter-beat. The map stays reversible, and WSOLA cannot
                    // accumulate drift across all sixteen defined slices.
                    float maxBeatCorrection = Mathf.Min(sampleRate * .020f, targetBeat * .06f);
                    int previousSource = 0, previousDestination = 0;
                    bool hasGlobalBeatMap = explicitGrid && sourceGridBeats01 != null &&
                        sourceGridBeats01.Count == (chopBoundaries01.Count - 1) *
                            gridBeatsPerChop + 1;
                    for (int marker = 1; marker < chopBoundaries01.Count - 1 &&
                        !hasGlobalBeatMap; marker++)
                    {
                        int src = Mathf.RoundToInt(Mathf.Clamp01(chopBoundaries01[marker]) * original.samples);
                        int unshifted = Mathf.RoundToInt(src * ratio);
                        // Only GRID chops have numbered musical destinations.
                        // HIT/FREE chops retain their original groove instead
                        // of being moved wholesale toward the nearest beat.
                        int dst;
                        if (explicitGrid)
                        {
                            dst = Mathf.RoundToInt(marker * gridBeatsPerChop * targetBeat);
                        }
                        else
                        {
                            int beatTarget = Mathf.RoundToInt(targetAnchor +
                                Mathf.Round((unshifted - targetAnchor) / targetBeat) * targetBeat);
                            dst = Mathf.Abs(beatTarget - unshifted) <= maxBeatCorrection
                                ? beatTarget : unshifted;
                        }
                        if (src < edgeGuard || src > original.samples - edgeGuard ||
                            dst < edgeGuard || dst > outputCount - edgeGuard ||
                            src - previousSource < sampleRate * .050f ||
                            dst - previousDestination < sampleRate * .050f * ratio)
                            continue;
                        proposed.Add(new WarpPoint(src, dst));
                        previousSource = src;
                        previousDestination = dst;
                    }
                    // For half-bar and full-bar chopping, beat 2/3/4 can
                    // occur INSIDE a chop. Anchor those strong amber attacks
                    // to their numbered project beats too; otherwise only the
                    // bar edges are correct and the kick/snare inside may drift.
                    // Work in source coordinates from the immutable PCM, using
                    // the already-snapped chop edges as local beat references.
                    int expectedBeats = (chopBoundaries01.Count - 1) * gridBeatsPerChop;
                    if (hasGlobalBeatMap)
                    {
                        // Song-wide source beat numbers survive region cropping.
                        // Marker 0/output 0 and the closing beat/output end are
                        // implicit endpoints. Only interiors need warp points.
                        for (int beatIndex = 1; beatIndex < expectedBeats; beatIndex++)
                        {
                            int src = Mathf.RoundToInt(Mathf.Clamp01(
                                sourceGridBeats01[beatIndex]) * original.samples);
                            int dst = Mathf.RoundToInt(beatIndex * targetBeat);
                            if (src > edgeGuard && src < original.samples - edgeGuard &&
                                dst > edgeGuard && dst < outputCount - edgeGuard)
                                proposed.Add(new WarpPoint(src, dst));
                        }
                    }
                    else if (explicitGrid && gridBeatsPerChop > 1 &&
                        amberHitGuides01 != null && amberHitGuides01.Count > 0)
                    {
                        float innerWindow = sampleRate * Mathf.Min(.050f,
                            .115f * 60f / sourceBpm);
                        for (int segment = 0; segment < chopBoundaries01.Count - 1; segment++)
                        {
                            float left = Mathf.Clamp01(chopBoundaries01[segment]) * original.samples;
                            float right = Mathf.Clamp01(chopBoundaries01[segment + 1]) * original.samples;
                            if (right - left <= sampleRate * .12f) continue;
                            for (int inner = 1; inner < gridBeatsPerChop; inner++)
                            {
                                // Interpolate between the actual detected chop
                                // boundary hits, not an unrelated file-start grid.
                                float ideal = Mathf.Lerp(left, right,
                                    inner / (float)gridBeatsPerChop);
                                float nearest = -1f, smallestDistance = innerWindow;
                                foreach (float guide01 in amberHitGuides01)
                                {
                                    float candidate = Mathf.Clamp01(guide01) * original.samples;
                                    float distance = Mathf.Abs(candidate - ideal);
                                    if (distance >= smallestDistance) continue;
                                    smallestDistance = distance;
                                    nearest = candidate;
                                }
                                if (nearest < edgeGuard || nearest > original.samples - edgeGuard)
                                    continue;
                                int beatIndex = segment * gridBeatsPerChop + inner;
                                int destination = Mathf.RoundToInt(beatIndex * targetBeat);
                                if (destination < edgeGuard || destination > outputCount - edgeGuard)
                                    continue;
                                proposed.Add(new WarpPoint(Mathf.RoundToInt(nearest), destination));
                            }
                        }
                    }
                    // In FREE/HIT mode, guide candidates remain visual only.
                    // They never drag intentionally loose manual slices to grid.
                }
                else for (int beat = firstBeat; beat <= lastBeat; beat++)
                {
                    if (cancelled != null && cancelled()) yield break;
                    float idealSource = sourceAnchor + beat * sourceBeat;
                    float idealTarget = targetAnchor + beat * targetBeat;
                    if (idealSource < edgeGuard || idealSource > original.samples - edgeGuard ||
                        idealTarget < edgeGuard || idealTarget > outputCount - edgeGuard) continue;
                    anchorBeatCount++;
                    // Beat 1 is user-pinned, not overridden by an unrelated onset.
                    if (beat == 0)
                    {
                        proposed.Add(new WarpPoint(sourceAnchor,
                            Mathf.RoundToInt(targetAnchor)));
                        continue;
                    }
                    int middle = Mathf.RoundToInt(idealSource / AnalysisHop);
                    float bestScore = 0f;
                    int best = -1;
                    for (int j = Mathf.Max(2, middle - searchBins);
                        j < Mathf.Min(strengths.Count - 2, middle + searchBins + 1); j++)
                    {
                        if (strengths[j] < threshold * .58f ||
                            strengths[j] < strengths[j - 1] ||
                            strengths[j] < strengths[j + 1]) continue;
                        float offset = Mathf.Abs(positions[j] - idealSource);
                        if (offset > beatWindow) continue;
                        // Alternating downbeat/backbeat evidence: kicks tend to
                        // reinforce beats 1/3 and broadband snares beats 2/4.
                        // Still accept either type on any beat for non-4/4 mixes.
                        bool backbeat = (Math.Abs(beat) & 1) != 0;
                        float drumScore = backbeat
                            ? highOnsets[j] * 1.05f + lowOnsets[j] * .75f
                            : lowOnsets[j] * 1.65f + highOnsets[j] * .63f;
                        float proximity = 1f - .42f * offset / Mathf.Max(1f, beatWindow);
                        float score = drumScore * proximity;
                        if (score > bestScore) { bestScore = score; best = j; }
                    }
                    if (best < 0) continue; // missing beat: don't invent a hit
                    int refined = RefineAttackFrame(original, positions[best],
                        ref attackPcm, ref attackEnvelope);
                    if (Mathf.Abs(refined - idealSource) > beatWindow + sampleRate * .012f)
                        continue;
                    proposed.Add(new WarpPoint(refined, Mathf.RoundToInt(idealTarget)));
                    if ((anchorBeatCount & 31) == 0)
                    {
                        progress?.Invoke(.25f, "LOCKING MAIN BEATS");
                        yield return null;
                    }
                }
                proposed.Sort((a, b) => a.source.CompareTo(b.source));
                if (guidedChops) anchorBeatCount = proposed.Count;
                int sourceGuard = Mathf.RoundToInt(sampleRate * .075f);
                foreach (var proposedPoint in proposed)
                {
                    WarpPoint previous = points[points.Count - 1];
                    if (proposedPoint.source - previous.source < sourceGuard ||
                        proposedPoint.destination - previous.destination < sourceGuard * ratio)
                        continue;
                    float localRatio = (proposedPoint.destination - previous.destination) /
                        Mathf.Max(1f, proposedPoint.source - previous.source);
                    float endRatio = (outputCount - proposedPoint.destination) /
                        Mathf.Max(1f, original.samples - proposedPoint.source);
                    if (localRatio < ratio * (guidedChops ? .74f : .82f) ||
                        localRatio > ratio * (guidedChops ? 1.30f : 1.22f) ||
                        endRatio < ratio * .72f || endRatio > ratio * 1.32f) continue;
                    points.Add(proposedPoint);
                    anchoredAlignedCount++;
                }
                // Preserve original attack PCM for all accepted main beats;
                // do not overwrite these cores with overlapping WSOLA grains.
                for (int i = 1; i < points.Count; i++)
                    attackFrames.Add(points[i].source);
            }
            else
            {
            int lastAttack = -sampleRate;
            int lastAccepted = -sampleRate;
            int minGap = Mathf.RoundToInt(sampleRate * .135f);
            float eighthFrames = sampleRate * 30f / targetBpm;
            float beatFrames = eighthFrames * 2f;
            // A song may have silence before the first kick. Find the phase
            // shared by rhythmic transients instead of forcing every attack
            // toward a grid with its first beat at sample frame zero.
            float phaseFrames = 0f, peakPhaseScore = 0f, phaseTotal = 0f;
            float phaseTolerance = Mathf.Min(sampleRate * .055f, beatFrames * .18f);
            const int phaseBins = 48;
            for (int phaseBin = 0; phaseBin < phaseBins; phaseBin++)
            {
                float phase = beatFrames * phaseBin / phaseBins;
                float score = 0f, total = 0f;
                for (int k = 2; k + 2 < strengths.Count; k++)
                {
                    float power = strengths[k];
                    if (power < threshold || power < strengths[k - 1] ||
                        power < strengths[k + 1]) continue;
                    float at = positions[k] * ratio;
                    float distance = Mathf.Abs(Mathf.Repeat(at - phase + beatFrames * .5f,
                        beatFrames) - beatFrames * .5f);
                    total += power;
                    if (distance < phaseTolerance)
                        score += power * (1f - distance / phaseTolerance);
                }
                if (score > peakPhaseScore)
                { peakPhaseScore = score; phaseFrames = phase; phaseTotal = total; }
                if ((phaseBin & 7) == 7)
                {
                    if (cancelled != null && cancelled()) yield break;
                    progress?.Invoke(.25f, "LOCKING BEAT GRID");
                    yield return null;
                }
            }
            // Low-confidence audio is left on the normal zero-based beat grid.
            if (phaseTotal <= .0001f || peakPhaseScore / phaseTotal < .16f)
                phaseFrames = 0f;
            float maxSnapFrames = sampleRate * Mathf.Min(.032f, 4.6f / targetBpm);
            int inputGuard = Mathf.RoundToInt(sampleRate * .1f);
            int lastDest = 0;
            for (int i = 2; i + 2 < strengths.Count; i++)
            {
                if (cancelled != null && cancelled()) yield break;
                float strength = strengths[i];
                if (strength < threshold || strength < strengths[i - 1] ||
                    strength < strengths[i + 1] || strength < strengths[i - 2] ||
                    strength < strengths[i + 2]) continue;
                int sourceAt = RefineAttackFrame(original, positions[i], ref attackPcm, ref attackEnvelope);
                if (sourceAt - lastAttack >= minGap && sourceAt >= 0 &&
                    sourceAt < original.samples - inputGuard)
                {
                    attackFrames.Add(sourceAt);
                    lastAttack = sourceAt;
                }
                if (sourceAt - lastAccepted < minGap || sourceAt < inputGuard ||
                    sourceAt > original.samples - inputGuard) continue;
                int expected = Mathf.RoundToInt(sourceAt * ratio);
                int snapped = Mathf.RoundToInt(phaseFrames +
                    Mathf.Round((expected - phaseFrames) / eighthFrames) * eighthFrames);
                float deviation = Mathf.Abs(snapped - expected);
                if (deviation < sampleRate * .004f || deviation > maxSnapFrames ||
                    snapped <= lastDest + sampleRate * .13f ||
                    snapped >= outputCount - sampleRate * .10f) continue;
                WarpPoint previous = points[points.Count - 1];
                float sourceDelta = sourceAt - previous.source;
                float destinationDelta = snapped - previous.destination;
                float localRatio = destinationDelta / Mathf.Max(1f, sourceDelta);
                // Enforce monotonic, moderate stretch between neighboring hits.
                if (localRatio < ratio * .85f || localRatio > ratio * 1.18f) continue;
                float remainingRatio = (outputCount - snapped) /
                    Mathf.Max(1f, original.samples - sourceAt);
                if (remainingRatio < ratio * .85f || remainingRatio > ratio * 1.18f) continue;
                points.Add(new WarpPoint(sourceAt, snapped));
                lastAccepted = sourceAt;
                lastDest = snapped;
            }

            }
            points.Add(new WarpPoint(original.samples, outputCount));
            progress?.Invoke(.25f, anchoredBeats || guidedChops ? "ALIGNING CHOP HITS" : "ALIGNING GRID");
            yield return null;
            if (cancelled != null && cancelled()) yield break;
            int shifted = points.Count - 2;
            bool movedAttack = false;
            for (int i = 1; i + 1 < points.Count; i++)
            {
                if (Mathf.Abs(points[i].destination - points[i].source * ratio) >
                    sampleRate * .0015f) { movedAttack = true; break; }
            }
            if (!movedAttack && Mathf.Abs(ratio - 1f) < .0001f &&
                outputCount == original.samples)
            {
                progress?.Invoke(1f, "ALREADY ALIGNED");
                complete?.Invoke(original, anchoredBeats || guidedChops ? "BEATS ALREADY ALIGNED" :
                    "GRID / NO CORRECTION NEEDED");
                yield break;
            }
            AudioClip target = null;
            try
            {
                target = AudioClip.Create(original.name + " [Grid Warp]",
                    outputCount, channels, sampleRate, false);
            }
            catch (Exception ex)
            {
                complete?.Invoke(null, "NOT ENOUGH MEMORY: " + ex.GetType().Name);
                yield break;
            }
            if (target == null) { complete?.Invoke(null, "UNABLE TO ALLOCATE AUDIO"); yield break; }

            bool failed = false;
            int block = Math.Max(4096, sampleRate * 2);
            int overlap = Mathf.Min(2048, block / 8);
            int cursor = 0;
            float[] tail = null;
            float[] inputBuffer = null;
            float[] outputBuffer = new float[block * channels];
            float[] weightBuffer = new float[block];
            float[] writeBuffer = new float[(block - overlap) * channels];
            while (cursor < outputCount)
            {
                if (cancelled != null && cancelled())
                { UnityEngine.Object.Destroy(target); yield break; }
                int outFrames = Math.Min(block, outputCount - cursor);
                int margin = WindowSize + sampleRate / 20;
                int sourceStart = Mathf.Max(0,
                    Mathf.FloorToInt(MapOutputToSource(points, cursor)) - margin);
                int sourceEnd = Mathf.Min(original.samples,
                    Mathf.CeilToInt(MapOutputToSource(points, cursor + outFrames)) + margin);
                int sourceFrames = sourceEnd - sourceStart;
                if (sourceFrames < WindowSize)
                { failed = true; break; }
                if (inputBuffer == null || inputBuffer.Length < sourceFrames * channels)
                    inputBuffer = new float[sourceFrames * channels];
                // GetData can wrap at the end of a non-streaming AudioClip.
                // The synthesis routine only reads sourceFrames from this buffer.
                if (!original.GetData(inputBuffer, sourceStart)) { failed = true; break; }
                Array.Clear(outputBuffer, 0, outFrames * channels);
                Array.Clear(weightBuffer, 0, outFrames);
                yield return StretchMappedBlock(inputBuffer, sourceFrames, sourceStart,
                    cursor, outFrames, channels, points, outputBuffer, weightBuffer, cancelled);
                // WSOLA can double/blur sharp attacks. Replace just the narrow
                // transient core with untouched source PCM and crossfade its edges.
                // The body of each sound remains time-warped / pitch-preserved.
                PreserveTransientCores(inputBuffer, sourceFrames, sourceStart,
                    cursor, outFrames, channels, sampleRate, points, attackFrames, outputBuffer);
                if (cancelled != null && cancelled())
                { UnityEngine.Object.Destroy(target); yield break; }
                if (tail != null)
                {
                    int blend = Math.Min(overlap, outFrames);
                    for (int f = 0; f < blend; f++)
                    {
                        float t = (f + 1f) / (blend + 1f);
                        for (int c = 0; c < channels; c++)
                        {
                            int at = f * channels + c;
                            outputBuffer[at] = tail[at] * (1f - t) + outputBuffer[at] * t;
                        }
                    }
                }
                bool more = cursor + outFrames < outputCount;
                int writeFrames = more ? outFrames - overlap : outFrames;
                int copySamples = writeFrames * channels;
                float[] write = writeBuffer;
                if (write.Length != copySamples)
                {
                    // Last block may have a shorter final write.
                    write = new float[copySamples];
                }
                Array.Copy(outputBuffer, 0, write, 0, copySamples);
                if (!target.SetData(write, cursor)) { failed = true; break; }
                if (more)
                {
                    if (tail == null) tail = new float[overlap * channels];
                    Array.Copy(outputBuffer, writeFrames * channels, tail, 0, tail.Length);
                }
                cursor += writeFrames;
                progress?.Invoke(.25f + .75f * cursor / outputCount,
                    anchoredBeats || guidedChops ? "STRETCHING CHOP SECTIONS" :
                    shifted > 0 ? "ALIGNING TRANSIENTS" : "MATCHING TEMPO");
                yield return null;
            }
            if (cancelled != null && cancelled())
            { UnityEngine.Object.Destroy(target); yield break; }
            if (failed)
            {
                UnityEngine.Object.Destroy(target);
                complete?.Invoke(null, "PCM READ/WRITE FAILED");
                yield break;
            }
            // The map is delivered only for a successfully rendered warp. A
            // cancelled/failed stretch must never replace the prior map.
            if (timeMapReady != null)
            {
                var map = new List<TimeMapPoint>(points.Count);
                for (int i = 0; i < points.Count; i++)
                    map.Add(new TimeMapPoint(points[i].source / (float)original.samples,
                        points[i].destination / (float)outputCount));
                timeMapReady(map);
            }
            progress?.Invoke(1f, anchoredBeats || guidedChops ? "CHOP HIT ALIGN COMPLETE" : "GRID WARP COMPLETE");
            if (anchoredBeats || guidedChops)
            {
                complete?.Invoke(target, "BEAT ALIGN / " + anchoredAlignedCount +
                    " OF " + anchorBeatCount + " BEATS / " +
                    sourceBpm.ToString("0.#") + " TO " + targetBpm.ToString("0.#") + " BPM");
                yield break;
            }
            complete?.Invoke(target, shifted > 0 ?
                "GRID ALIGNED / " + shifted + " ATTACKS / " +
                sourceBpm.ToString("0.#") + " TO " + targetBpm.ToString("0.#") + " BPM" :
                "TEMPO MATCHED / NO GRID ATTACKS FOUND");
        }

        private static float MapSourceToOutput(List<WarpPoint> points, float source)
        {
            int left = 0, right = points.Count - 1;
            while (left + 1 < right)
            {
                int middle = (left + right) / 2;
                if (points[middle].source <= source) left = middle;
                else right = middle;
            }
            WarpPoint a = points[left], b = points[right];
            float t = Mathf.Clamp01((source - a.source) / Mathf.Max(1f, b.source - a.source));
            return Mathf.Lerp(a.destination, b.destination, t);
        }

        private static void PreserveTransientCores(float[] input, int inputFrames, int inputStart,
            int outputStart, int outputFrames, int channels, int rate,
            List<WarpPoint> points, List<int> attacks, float[] output)
        {
            int pre = Mathf.Max(32, Mathf.RoundToInt(.014f * rate));
            int post = Mathf.Max(64, Mathf.RoundToInt(.060f * rate));
            int fade = Mathf.Max(16, Mathf.RoundToInt(.012f * rate));
            foreach (int attack in attacks)
            {
                int center = Mathf.RoundToInt(MapSourceToOutput(points, attack));
                int start = Mathf.Max(0, center - pre);
                int end = Mathf.Min(outputStart + outputFrames, center + post);
                if (end <= outputStart || start >= outputStart + outputFrames) continue;
                for (int global = Mathf.Max(start, outputStart); global < end; global++)
                {
                    int sourceAt = attack + (global - center) - inputStart;
                    if (sourceAt < 0 || sourceAt >= inputFrames) continue;
                    float fadeIn = Mathf.Clamp01((global - (center - pre)) / (float)fade);
                    float fadeOut = Mathf.Clamp01((center + post - global) / (float)fade);
                    float blend = Mathf.Min(fadeIn, fadeOut);
                    // Equal across channels to preserve stereo imaging.
                    int outAt = (global - outputStart) * channels;
                    int inAt = sourceAt * channels;
                    for (int c = 0; c < channels; c++)
                        output[outAt + c] = Mathf.Lerp(output[outAt + c], input[inAt + c], blend);
                }
            }
        }

        private static float MapOutputToSource(List<WarpPoint> points, float output)
        {
            int left = 0, right = points.Count - 1;
            while (left + 1 < right)
            {
                int middle = (left + right) / 2;
                if (points[middle].destination <= output) left = middle;
                else right = middle;
            }
            WarpPoint a = points[left], b = points[right];
            float span = Mathf.Max(1f, b.destination - a.destination);
            float t = Mathf.Clamp01((output - a.destination) / span);
            return Mathf.Lerp(a.source, b.source, t);
        }

        private static IEnumerator StretchMappedBlock(float[] input, int inputFrames,
            int inputStart, int outputStart, int outFrames, int channels,
            List<WarpPoint> points, float[] result, float[] weights,
            Func<bool> cancelled)
        {
            int available = Math.Max(0, inputFrames - WindowSize);
            for (int outPos = 0; outPos < outFrames; outPos += SynthesisHop)
            {
                int expected = Mathf.Clamp(Mathf.RoundToInt(
                    MapOutputToSource(points, outputStart + outPos) - inputStart),
                    0, available);
                int position = expected;
                // FIX: match the audio that has ALREADY been synthesized before
                // this grain, against the source preceding the candidate grain.
                // The old code compared the UNRENDERED region after outPos and
                // mostly chose arbitrary shifts; that produced warble and flams.
                int correlationFrames = Math.Min(512, outPos);
                if (correlationFrames >= 128 && inputFrames >= WindowSize)
                {
                    const int radius = 192;
                    float best = -2f;
                    int low = Math.Max(correlationFrames, expected - radius);
                    int high = Math.Min(available, expected + radius);
                    for (int offset = low; offset <= high; offset += 8)
                    {
                        double dot = 0.0, energyA = 0.0, energyB = 0.0;
                        for (int j = 0; j < correlationFrames; j += 3)
                        {
                            int renderedFrame = outPos - correlationFrames + j;
                            float norm = weights[renderedFrame];
                            if (norm < .04f) continue;
                            int renderedAt = renderedFrame * channels;
                            int sourceAt = (offset - correlationFrames + j) * channels;
                            for (int c = 0; c < channels; c++)
                            {
                                float a = result[renderedAt + c] / norm;
                                float b = input[sourceAt + c];
                                dot += a * b;
                                energyA += a * a;
                                energyB += b * b;
                            }
                        }
                        if (energyA < 1e-8 || energyB < 1e-8) continue;
                        float score = (float)(dot / Math.Sqrt(energyA * energyB));
                        // In ties, prefer the true tempo curve rather than
                        // drifting off the time-aligned transient position.
                        score -= .012f * Math.Abs(offset - expected) / radius;
                        if (score > best) { best = score; position = offset; }
                    }
                }
                int count = Mathf.Min(WindowSize, outFrames - outPos);
                for (int j = 0; j < count; j++)
                {
                    float weight = Hann[j];
                    int src = Math.Min(inputFrames - 1, position + j) * channels;
                    int dst = (outPos + j) * channels;
                    for (int c = 0; c < channels; c++)
                        result[dst + c] += input[src + c] * weight;
                    weights[outPos + j] += weight;
                }
                if (outPos > 0 && outPos % 8192 == 0)
                {
                    if (cancelled != null && cancelled()) yield break;
                    yield return null;
                }
            }
            for (int f = 0; f < outFrames; f++)
            {
                float normalization = 1f / Mathf.Max(.0001f, weights[f]);
                for (int c = 0; c < channels; c++)
                    result[f * channels + c] *= normalization;
                if (f > 0 && f % 16384 == 0)
                {
                    if (cancelled != null && cancelled()) yield break;
                    yield return null;
                }
            }
        }
    }
}
