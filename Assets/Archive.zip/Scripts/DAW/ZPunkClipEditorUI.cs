using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

namespace ZPunk.DAW
{
    /// <summary>
    /// Clip-native step grid / piano roll. All edits go to SongData events, not the
    /// old 16-step groovebox buffers. Playback uses the next Play snapshot.
    /// </summary>
    public sealed class ZPunkClipEditorUI : MonoBehaviour
    {
        private static readonly Color Ink = new Color(.91f,.94f,.98f);
        private static readonly Color Muted = new Color(.55f,.64f,.75f);
        private static readonly Color Surface = new Color(.075f,.105f,.15f);
        private static readonly Color Raised = new Color(.13f,.18f,.25f);
        private static readonly Color Accent = new Color(.31f,.88f,.74f);
        private readonly Color[] colors = {
            new Color(.98f,.66f,.28f), new Color(.96f,.36f,.48f),
            new Color(.35f,.60f,.98f), new Color(.66f,.45f,.94f), new Color(.24f,.82f,.69f), new Color(.91f,.81f,.36f)
        };
        private VisualElement root, canvas, gridScrollContainer, chips, labelViewport, labelColumn;
        // Note hit targets sit ABOVE (not inside) the ScrollView. This prevents
        // ScrollView's touch pan manipulator from taking ownership of note drags.
        private VisualElement noteTouchLayer;
        private readonly List<MidiNoteTouchTarget> midiNoteTouchTargets = new List<MidiNoteTouchTarget>();
        // This ruler is outside the note ScrollView, so vertical swipes never hide the bar positions.
        private VisualElement rulerGutter, rulerContent, rulerPlayhead;
        private readonly List<VisualElement> pitchRowBackgrounds = new List<VisualElement>();
        private readonly List<Label> pitchRowLabels = new List<Label>();
        // The guide may follow either a detected sample or the selected generator key.
        private bool sampleKeyGuideEnabled;
        private bool sampleKeyGuideFromSample;
        private int sampleKeyGuideTonic;
        private bool sampleKeyGuideMinor;
        private string sampleKeyGuideSampleId;
        private int sampleKeyGuideProjectSlot = -1;
        private VisualElement generatorPanel, generatorGenres, generatorStyles, generatorBarsRow, generatorSynthModeRow;
        private VisualElement normalGeneratorSections, acidGeneratorSections;
        private Label acidKeyLabel, acidGeneratorSummary, acidLiveStatus;
        private VisualElement acidPatternPreview;
        private Button generatorApplyButton, generatorCancelButton, acidLiveButton;
        private bool acidLiveEnabled = true, acidAppliedInSession, acidUnappliedChanges;
        private IVisualElementScheduledItem acidLiveUpdate;
        // Unity's touch ScrollView can claim a gesture before a child knob's
        // bubble-phase pointer handlers run. The visible knobs stay in the
        // scrolling content, but their *pickable* hit targets are transparent
        // siblings ABOVE the ScrollView, so the pan manipulator never sees a
        // knob drag. This is the same approach used for MIDI note dragging.
        private ScrollView acidGeneratorScroll;
        private VisualElement acidKnobTouchLayer;
        private readonly List<VisualElement> acidKnobFaces = new List<VisualElement>();
        private readonly List<VisualElement> acidKnobHitTargets = new List<VisualElement>();
        private VisualElement acidActiveKnobTarget;
        private int acidKnobPointerId = -1;
        private readonly ZPunkAcidPatternGenerator.Settings acidSettings =
            new ZPunkAcidPatternGenerator.Settings();
        private bool acidSettingsInitialized;
        private int acidSettingsProjectSlot = -1;
        // Each control owns its visual refresh, so returning to the sheet never
        // reconstructs controls (or loses a captured touch/scroll position).
        private readonly List<Action> acidControlPainters = new List<Action>();
        private VisualElement generatorHistoryRows;
        private Label generatorHistoryLabel;
        private Button generatorQuickButton, generatorMelodyButton, generatorChordsButton;
        private Label generatorHeading, generatorSummary, generatorHint, generatorKeyLabel, generatorVariationLabel;
        private Label generatorProgressionLabel, generatorProgressionChords;
        private VisualElement generatorProgressionSection;
        private int generatorGenre = 1, generatorStyle, generatorBars = 2, generatorKey = 9, generatorVariation;
        private bool generatorMinor = true, generatorSynthChords;
        private int generatorTargetTrack;
        private VisualElement editorPlayhead;
        private VisualElement samplerPage, samplerWave;
        private ScrollView samplerScroll;
        private Label samplerSelectedMarker, samplerHitSliceStatus, samplerBpmLabel, samplerHitProgressLabel, samplerTapBpmStatus;
        private VisualElement samplerHitProgressTrack, samplerHitProgressFill;
        private Button samplerGridButton;
        private Button samplerSnapButton;
        private readonly List<Button> samplerChopPads = new List<Button>();
        private readonly List<VisualElement> samplerChopRangeBars = new List<VisualElement>();
        private Label samplerTitle, samplerWarpLabel, samplerLibraryLabel, samplerPitchLabel;
        private Label samplerSourceKeyLabel, samplerPitchedKeyLabel, generatorSampleKeyHint, clipSampleKeyReference;
        private Button generatorSampleKeyButton;
        private Button samplerWarpButton;
        private VisualElement samplerWarpProgressTrack, samplerWarpProgressFill;
        private Label samplerWarpProgressLabel;
        private bool showingSampler;
        private KMusicPlayerUI samplePlayer;
        private ZPunkSongTransport songTransport;
        private ScrollView scroller;
        private Label title, info, selectedInfo;
        // 2.3.4: The chord brush is exclusive to SYNTH and PADS. Chord groups
        // are ordinary MIDI notes, with an optional persistent edit-group ID.
        private VisualElement acidNoteToolbar;
        private Button accentNoteButton, slideNoteButton, sampleLabButton;
        private Button previousClipButton, nextClipButton;
        private VisualElement chordDrawToolbar;
        private Button noteDrawButton, chordDrawButton;
        // Compact ZPUNK-styled selectors: the Unity PopupField's reserved arrow
        // space clipped labels such as MIN7 and 2 BARS on portrait phones.
        private Button chordQualityButton, chordLengthButton;
        private Label chordQualityValue, chordLengthValue;
        private VisualElement chordMenuOverlay, chordMenuPanel;
        private bool chordDrawEnabled;
        private int chordQualityIndex = 1; // Minor triad
        private int chordLengthIndex = 2; // Quarter note
        private static readonly string[] ChordQualityLabels =
            { "MAJ", "MIN", "DIM", "SUS2", "SUS4", "7", "MAJ7", "MIN7" };
        private static readonly int[][] ChordIntervals = {
            new[] { 0, 4, 7 }, new[] { 0, 3, 7 }, new[] { 0, 3, 6 },
            new[] { 0, 2, 7 }, new[] { 0, 5, 7 }, new[] { 0, 4, 7, 10 },
            new[] { 0, 4, 7, 11 }, new[] { 0, 3, 7, 10 }
        };
        private static readonly string[] ChordLengthLabels =
            { "1/16", "1/8", "1/4", "1/2", "1 BAR", "2 BARS" };
        private static readonly long[] ChordLengthTicks = {
            SongData.TicksPerSixteenth, SongData.TicksPerSixteenth * 2L,
            SongData.TicksPerQuarter, SongData.TicksPerQuarter * 2L,
            SongData.TicksPerBar4, SongData.TicksPerBar4 * 2L
        };
        private VisualElement velocityFill, velocityThumb;
        private readonly List<VelocityDisplay> velocityDisplays = new List<VelocityDisplay>();
        private VisualElement kitSelector, trackScopeRow;
        private Label kitName, trackScopeTitle, trackScopeStatus;
        private ZPunkTrackScope trackScope;
        private float nextTrackScopeSample;
        private KMusicDrumSequencer drumEngine;
        private VisualElement drumDesignerPage, drumPresetOverlay, drumPresetPanel;
        private Button drumPresetButton;
        private Label drumDesignerLaneLabel;
        private int drumDesignerLane;
        private Button drumCharacterButton, drumCharacterMinus, drumCharacterPlus;
        private Label drumCharacterAmountLabel;
        private static readonly string[] DrumCharacterNames = { "OFF", "CRUSH", "PITCH", "ROOM", "METAL", "ECHO", "GATE" };
        private bool showingDrumDesigner;
        private static readonly string[] DrumDesignerNames = { "KICK", "SNARE", "CLAP", "CLOSED", "OPEN", "RIDE", "RIM", "CRASH" };
        private ScrollView trackScroller;
        private KMusicProjectManager projects;
        private SongData song;
        private ClipData clip;
        private ClipContentData content;
        private int trackIndex;
        private string clipId;
        // Read-only selection for ARRANGE navigation. No mutation of song/clip data.
        public int SelectedTrackIndex => trackIndex;
        public string SelectedClipId => clipId;
        private int octave = 4;
        private int noteFocusRevision;
        private long quantum = SongData.TicksPerSixteenth;
        private int selectedNote = -1;
        private int selectedEventRow = -1;
        private long selectedEventTick = -1;
        private int velocity = 110;
        private const float StepW = 32f;
        private const float RowH = 36f;
        // Render every MIDI pitch (C-1 through G9). The user scrolls the same
        // continuous 128-note keyboard; octave controls only move the viewport.
        private const int MidiRows = 128;
        private int steps;
        private bool ready;
        private float nextPlayheadPaint;
        private float lastPlayheadX = -1f;

        // MIDI notes use two unambiguous gestures: drag the note body to move
        // its position (snapped in time and pitch); drag ONLY the trailing/right
        // handle to resize its duration. There is no leading/left-edge resize.
        // Empty piano-roll space remains scrollable.
        private enum MidiDragMode { Move, ResizeEnd }
        private const float MidiGestureThreshold = 5f;
        private const float MidiEdgeScrollZone = 34f;
        private const float MidiMaxEdgeScrollPerTick = 11f; // 16 ms scheduler tick
        private sealed class Drag
        {
            public int index;
            public Vector2 start;
            public Vector2 latestWorldPosition;
            public Vector2 allowedScrollOffset;
            public long startTick;
            public long duration;
            public int pitch;
            public MidiDragMode mode;
            public bool moved;
            public int pointerId;
            public VisualElement preview;
            public VelocityDisplay display;
            public IVisualElementScheduledItem edgeScroll;
            public long candidateTick;
            public long candidateDuration;
            public int candidatePitch;
            public List<ChordGestureNote> chordMembers; // populated only in CHORD mode
        }
        private sealed class ChordGestureNote
        {
            public int index;
            public long tick, duration;
            public int pitch;
            public long candidateTick, candidateDuration;
            public int candidatePitch;
            public VelocityDisplay display;
        }
        private Drag drag;
        private sealed class MidiNoteTouchTarget
        {
            public VisualElement body;
            public int noteIndex;
        }
        private sealed class Tap
        {
            public int pointerId;
            public Vector2 start;
            public int row;
            public int step;
            public bool handled;
            public IVisualElementScheduledItem hold;
        }
        private sealed class VelocityDisplay
        {
            public VisualElement cell;
            public VisualElement meter;
            public Label number;
            public int row;
            public int noteIndex;
            public long tick;
            public float width;
            public int velocity;
        }
        private Tap pendingTap;
        public Action OnClipChanged;

        public void Initialize(VisualElement host)
        {
            if (host == null) return;
            root = host;
            projects = FindObjectOfType<KMusicProjectManager>();
            songTransport = FindObjectOfType<ZPunkSongTransport>();
            BuildShell();
            ready = true;
        }

        private static Label Txt(string str, int size=12, Color? color=null)
        {
            var label = new Label(str);
            label.style.fontSize = Mathf.Max(12, size);
            label.style.color = color ?? Ink;
            label.style.unityTextAlign = TextAnchor.MiddleLeft;
            return label;
        }
        private static VisualElement Box(Color bg, float radius=8)
        {
            var e = new VisualElement();
            e.style.backgroundColor = bg;
            e.style.borderTopLeftRadius = radius;
            e.style.borderTopRightRadius = radius;
            e.style.borderBottomLeftRadius = radius;
            e.style.borderBottomRightRadius = radius;
            return e;
        }
        private static Button Btn(string text, Action action, int width=48)
        {
            var b = new Button(action) { text = text };
            b.style.minWidth = width;
            b.style.flexShrink = 0;
            b.style.flexGrow = 0;
            b.style.height = 44;
            b.style.marginRight = 5;
            b.style.marginBottom = 1;
            b.style.whiteSpace = WhiteSpace.NoWrap;
            b.style.paddingLeft = 9;
            b.style.paddingRight = 9;
            b.style.backgroundColor = Raised;
            b.style.color = Ink;
            b.style.borderTopLeftRadius = 7;
            b.style.borderTopRightRadius = 7;
            b.style.borderBottomLeftRadius = 7;
            b.style.borderBottomRightRadius = 7;
            b.style.fontSize = 13;
            b.style.unityFontStyleAndWeight = FontStyle.Bold;
            return b;
        }
        private static Button EqualButton(string label, Action action)
        {
            var button = Btn(label, action, 0);
            button.style.flexGrow = 1;
            button.style.flexShrink = 1;
            button.style.flexBasis = new Length(0, LengthUnit.Pixel);
            button.style.minWidth = 0;
            button.style.marginLeft = 2;
            button.style.marginRight = 2;
            button.style.paddingLeft = 2;
            button.style.paddingRight = 2;
            button.style.fontSize = 11;
            return button;
        }

        private void BuildShell()
        {
            root.Clear();
            root.style.flexDirection = FlexDirection.Column;
            root.style.position = Position.Relative;
            root.style.flexGrow = 1;
            root.style.minHeight = 0;
            root.style.paddingLeft = 9;
            root.style.paddingRight = 9;
            root.style.paddingTop = 8;
            root.style.backgroundColor = Surface;

            var heading = new VisualElement { name = "ZPunkEditorHeading" };
            heading.style.flexDirection = FlexDirection.Row;
            heading.style.alignItems = Align.Center;
            heading.style.justifyContent = Justify.SpaceBetween;
            title = Txt("CLIP EDITOR", 16);
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.flexShrink = 1;
            title.style.minWidth = 0;
            title.style.whiteSpace = WhiteSpace.NoWrap;
            title.style.overflow = Overflow.Hidden;
            title.style.textOverflow = TextOverflow.Ellipsis;
            heading.style.height = 50;
            heading.style.flexShrink = 0;
            heading.Add(title);
            var newClipButton = Btn("+ NEW CLIP", NewClip, 98);
            ZPunkUIIcons.Apply(newClipButton, "plus", "NEW CLIP", 17f, false);
            newClipButton.style.minWidth = 99;
            newClipButton.style.paddingLeft = 5;
            newClipButton.style.paddingRight = 5;
            newClipButton.style.borderTopWidth = 1;
            newClipButton.style.borderBottomWidth = 1;
            newClipButton.style.borderLeftWidth = 1;
            newClipButton.style.borderRightWidth = 1;
            // Clip browsing lives beside NEW CLIP, not on another vertical row.
            // Users can return to and edit clips they created without visiting ARRANGE.
            previousClipButton = Btn("<", () => StepClip(-1), 33);
            previousClipButton.style.minWidth = 33;
            previousClipButton.style.marginRight = 2;
            previousClipButton.style.paddingLeft = 2;
            previousClipButton.style.paddingRight = 2;
            previousClipButton.tooltip = "Edit previous clip on this track";
            nextClipButton = Btn(">", () => StepClip(1), 33);
            nextClipButton.style.minWidth = 33;
            nextClipButton.style.marginRight = 4;
            nextClipButton.style.paddingLeft = 2;
            nextClipButton.style.paddingRight = 2;
            nextClipButton.tooltip = "Edit next clip on this track";
            heading.Add(previousClipButton);
            heading.Add(nextClipButton);
            heading.Add(newClipButton);
            root.Add(heading);

            var tracks = new ScrollView(ScrollViewMode.Horizontal);
            trackScroller = tracks;
            tracks.style.height = 55;
            tracks.style.flexShrink = 0;
            tracks.style.marginTop = 6;
            tracks.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            tracks.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            chips = tracks.contentContainer;
            chips.style.flexDirection = FlexDirection.Row;
            chips.style.flexWrap = Wrap.NoWrap;
            chips.style.width = new Length(100, LengthUnit.Percent);
            chips.style.flexGrow = 1;
            root.Add(tracks);

            // Reserve this one toolbar row for every track: switching Drums/Bass/etc
            // must not shift the piano roll or the scroll viewport vertically.
            kitSelector = new VisualElement { name = "ZPunkDrumKitSelector" };
            kitSelector.style.height = 50;
            kitSelector.style.minHeight = 50;
            kitSelector.style.maxHeight = 50;
            kitSelector.style.flexShrink = 0;
            kitSelector.style.flexDirection = FlexDirection.Row;
            kitSelector.style.alignItems = Align.Center;
            kitSelector.style.marginTop = 2;
            // A single, centred preset selector, like a compact VST patch browser.
            // Preserves the old +/- kit callbacks and its reserved 50-point row.
            var previousKit = Btn("<", () => StepDrumKit(-1), 40);
            ZPunkUIIcons.Apply(previousKit, "left", "", 19f);
            previousKit.tooltip = "Previous drum kit";
            kitSelector.Add(previousKit);
            var kitDetails = new VisualElement();
            kitDetails.style.flexGrow = 1;
            kitDetails.style.minWidth = 0;
            kitDetails.style.alignItems = Align.Center;
            kitDetails.style.justifyContent = Justify.Center;
            kitName = Txt("LOADING", 13, Ink);
            kitName.style.unityTextAlign = TextAnchor.MiddleCenter;
            kitName.style.unityFontStyleAndWeight = FontStyle.Bold;
            kitName.style.whiteSpace = WhiteSpace.NoWrap;
            kitName.style.textOverflow = TextOverflow.Ellipsis;
            kitName.style.overflow = Overflow.Hidden;
            kitName.style.maxWidth = Length.Percent(100);
            kitDetails.Add(kitName);
            var kitCaption = Txt("DRUM KIT", 10, Muted);
            kitCaption.style.unityTextAlign = TextAnchor.MiddleCenter;
            kitDetails.Add(kitCaption);
            kitSelector.Add(kitDetails);
            var nextKit = Btn(">", () => StepDrumKit(1), 40);
            ZPunkUIIcons.Apply(nextKit, "right", "", 19f);
            nextKit.tooltip = "Next drum kit";
            kitSelector.Add(nextKit);
            var shapeButton = Btn("DESIGN", OpenDrumDesigner, 72);
            shapeButton.name = "ZPunkDrumDesignerButton";
            shapeButton.tooltip = "Shape the eight drum sounds";
            kitSelector.Add(shapeButton);
            root.Add(kitSelector);

            // Use the very same 50-point slot as the drum-kit selector, so
            // switching tracks never shifts the note grid or changes touch areas.
            // One audio-reactive identity display per BASS/SYNTH/PADS/CHOPS;
            // the selected track alone is visible, each with its own history.
            trackScopeRow = new VisualElement { name = "ZPunkCreateTrackSignal" };
            trackScopeRow.style.height = 50;
            trackScopeRow.style.minHeight = 50;
            trackScopeRow.style.maxHeight = 50;
            trackScopeRow.style.flexShrink = 0;
            trackScopeRow.style.flexDirection = FlexDirection.Row;
            trackScopeRow.style.alignItems = Align.Center;
            trackScopeRow.style.marginTop = 2;
            trackScopeRow.style.paddingLeft = 7;
            trackScopeRow.style.paddingRight = 7;
            trackScopeRow.style.backgroundColor = new Color(.061f, .084f, .122f);
            trackScopeRow.style.borderTopLeftRadius = 6;
            trackScopeRow.style.borderTopRightRadius = 6;
            trackScopeRow.style.borderBottomLeftRadius = 6;
            trackScopeRow.style.borderBottomRightRadius = 6;
            trackScopeRow.pickingMode = PickingMode.Position;
            var scopeLegend = new VisualElement();
            scopeLegend.style.width = 74;
            scopeLegend.style.flexShrink = 0;
            scopeLegend.style.justifyContent = Justify.Center;
            scopeLegend.pickingMode = PickingMode.Ignore;
            trackScopeTitle = Txt("BASS", 10, colors[1]);
            trackScopeTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
            trackScopeTitle.pickingMode = PickingMode.Ignore;
            scopeLegend.Add(trackScopeTitle);
            trackScopeStatus = Txt("SIGNAL", 10, Muted);
            trackScopeStatus.pickingMode = PickingMode.Ignore;
            scopeLegend.Add(trackScopeStatus);
            trackScopeRow.Add(scopeLegend);
            trackScope = new ZPunkTrackScope();
            trackScopeRow.Add(trackScope);
            sampleLabButton = Btn("SAMPLE", OpenSampler, 84);
            sampleLabButton.style.display = DisplayStyle.None;
            sampleLabButton.tooltip = "Open CHOPS sampler and slice editor";
            trackScopeRow.Add(sampleLabButton);
            root.Add(trackScopeRow);

            // Six equally sized controls fit a portrait phone on ONE row.
            // Never make the last buttons inaccessible through a hidden scroller.
            var controls = new VisualElement { name = "ZPunkNoteCommands" };
            controls.style.flexDirection = FlexDirection.Row;
            controls.style.flexWrap = Wrap.NoWrap;
            controls.style.alignItems = Align.Center;
            controls.style.width = new Length(100, LengthUnit.Percent);
            controls.style.height = 54;
            controls.style.flexShrink = 0;
            controls.style.marginTop = 2;
            var octaveDown = EqualButton("OCT -", () => { octave = Mathf.Max(-1,octave-1); ScrollToOctave(); });
            var octaveUp = EqualButton("OCT +", () => { octave = Mathf.Min(9,octave+1); ScrollToOctave(); });
            var lengthDown = EqualButton("LEN -", () => ChangeLength(-1));
            var lengthUp = EqualButton("LEN +", () => ChangeLength(1));
            var deleteNote = EqualButton("DEL", DeleteSelectedNote);
            generatorQuickButton = EqualButton("GEN", () => OpenGenerator(trackIndex));
            ZPunkUIIcons.Apply(octaveDown, "up", "OCT -", 17f);
            ZPunkUIIcons.Apply(octaveUp, "down", "OCT +", 17f);
            ZPunkUIIcons.Apply(lengthDown, "minus", "LEN -", 17f);
            ZPunkUIIcons.Apply(lengthUp, "plus", "LEN +", 17f);
            ZPunkUIIcons.Apply(deleteNote, "delete", "DEL", 17f);
            ZPunkUIIcons.Apply(generatorQuickButton, "spark", "GEN", 17f);
            controls.Add(octaveDown);
            controls.Add(octaveUp);
            controls.Add(lengthDown);
            controls.Add(lengthUp);
            controls.Add(deleteNote);
            controls.Add(generatorQuickButton);
            root.Add(controls);

            // A compact second row appears only on SYNTH/PADS. Popup selectors
            // offer direct access to every chord quality and duration on phones.
            chordDrawToolbar = new VisualElement { name = "ZPunkChordDrawToolbar" };
            chordDrawToolbar.style.flexDirection = FlexDirection.Row;
            chordDrawToolbar.style.flexWrap = Wrap.NoWrap;
            chordDrawToolbar.style.alignItems = Align.Center;
            chordDrawToolbar.style.width = new Length(100, LengthUnit.Percent);
            chordDrawToolbar.style.height = 45;
            chordDrawToolbar.style.flexShrink = 0;
            chordDrawToolbar.style.marginBottom = 3;
            noteDrawButton = EqualButton("NOTE", () => { chordDrawEnabled = false; RefreshChordDrawToolbar(); RefreshVelocityDisplays(); });
            chordDrawButton = EqualButton("CHORD", () => { chordDrawEnabled = true; RefreshChordDrawToolbar(); RefreshVelocityDisplays(); });
            noteDrawButton.tooltip = "Draw and edit individual notes";
            chordDrawButton.tooltip = "Tap a root pitch to draw a whole chord; drag any chord note to move the group";
            chordDrawToolbar.Add(noteDrawButton);
            chordDrawToolbar.Add(chordDrawButton);
            // Chord selectors deliberately get more width than NOTE / CHORD.
            // The selected value and arrow are separate, so neither can force
            // the other to truncate or trigger a horizontal scroll.
            noteDrawButton.style.flexGrow = .95f;
            chordDrawButton.style.flexGrow = .95f;
            chordQualityButton = CreateChordSelector("ZPunkChordQuality", "Chord type",
                ChordQualityLabels[chordQualityIndex], () => OpenChordMenu(true), out chordQualityValue);
            chordLengthButton = CreateChordSelector("ZPunkChordLength", "Chord note length",
                ChordLengthLabels[chordLengthIndex], () => OpenChordMenu(false), out chordLengthValue);
            chordDrawToolbar.Add(chordQualityButton);
            chordDrawToolbar.Add(chordLengthButton);
            root.Add(chordDrawToolbar);
            // One optional row, only visible on ACID; per-note gestures are saved
            // into regular MIDI notes and remain editable after arrangement copies.
            acidNoteToolbar = new VisualElement { name = "ZPunkAcidNoteModifiers" };
            acidNoteToolbar.style.height = 45;
            acidNoteToolbar.style.flexDirection = FlexDirection.Row;
            acidNoteToolbar.style.flexShrink = 0;
            accentNoteButton = EqualButton("ACCENT", () => ToggleAcidNoteModifier(true));
            slideNoteButton = EqualButton("SLIDE", () => ToggleAcidNoteModifier(false));
            accentNoteButton.tooltip = "Toggle 303 accent on the selected note";
            slideNoteButton.tooltip = "Slide from the preceding note into this note";
            acidNoteToolbar.Add(accentNoteButton);
            acidNoteToolbar.Add(slideNoteButton);
            root.Add(acidNoteToolbar);
            RefreshChordDrawToolbar();

            info = Txt("Choose a track, then create or select a clip.",11,Muted);
            info.style.height = 28;
            info.style.flexShrink = 0;
            root.Add(info);
            clipSampleKeyReference = Txt("", 11, Accent);
            clipSampleKeyReference.style.height = 19;
            clipSampleKeyReference.style.flexShrink = 0;
            clipSampleKeyReference.style.display = DisplayStyle.None;
            root.Add(clipSampleKeyReference);

            // The names stay on screen while the note grid scrolls horizontally.
            // Both areas share the same vertical scroll position.
            var editorViewport = new VisualElement { name = "ZPunkPianoRollViewport" };
            editorViewport.style.flexDirection = FlexDirection.Row;
            editorViewport.style.flexGrow = 1;
            editorViewport.style.minHeight = 125;
            editorViewport.style.maxHeight = 655;
            editorViewport.style.minWidth = 0;
            editorViewport.style.overflow = Overflow.Hidden;
            editorViewport.style.backgroundColor = new Color(.047f,.068f,.105f);
            editorViewport.style.borderTopLeftRadius = 8;
            editorViewport.style.borderTopRightRadius = 8;
            labelViewport = new VisualElement { name = "ZPunkPianoRollLabels" };
            labelViewport.style.position = Position.Relative;
            labelViewport.style.flexShrink = 0;
            labelViewport.style.width = 57;
            labelViewport.style.overflow = Overflow.Hidden;
            labelViewport.style.backgroundColor = new Color(.095f,.13f,.18f);
            editorViewport.Add(labelViewport);

            scroller = new ScrollView(ScrollViewMode.VerticalAndHorizontal) { name = "ZPunkNoteScroll" };
            scroller.style.flexGrow = 1;
            scroller.style.minWidth = 0;
            scroller.style.minHeight = 0;
            scroller.style.backgroundColor = new Color(.047f,.068f,.105f);
            scroller.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            scroller.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            gridScrollContainer = new VisualElement();
            gridScrollContainer.style.flexDirection = FlexDirection.Row;
            scroller.Add(gridScrollContainer);
            scroller.verticalScroller.valueChanged += _ => { SyncPianoRollLabels(); SyncMidiNoteTouchTargets(); };
            scroller.horizontalScroller.valueChanged += _ => { SyncFixedRuler(); SyncMidiNoteTouchTargets(); };
            editorViewport.Add(scroller);

            // Fixed top ruler: identical on DRUMS, CHOPS and the 128-note piano roll.
            // Only the ruler's inner content translates when the grid moves horizontally.
            var fixedRuler = new VisualElement { name = "ZPunkPinnedBarRuler" };
            fixedRuler.style.position = Position.Absolute;
            fixedRuler.style.top = 0;
            fixedRuler.style.left = 0;
            fixedRuler.style.right = 0;
            fixedRuler.style.height = 25;
            fixedRuler.style.flexDirection = FlexDirection.Row;
            fixedRuler.style.backgroundColor = new Color(.065f, .092f, .13f);
            fixedRuler.pickingMode = PickingMode.Ignore;

            rulerGutter = new VisualElement { name = "ZPunkRulerGutter" };
            rulerGutter.style.width = 57;
            rulerGutter.style.flexShrink = 0;
            rulerGutter.style.backgroundColor = new Color(.095f, .13f, .18f);
            rulerGutter.pickingMode = PickingMode.Ignore;
            fixedRuler.Add(rulerGutter);

            var rulerViewport = new VisualElement { name = "ZPunkRulerViewport" };
            rulerViewport.style.flexGrow = 1;
            rulerViewport.style.minWidth = 0;
            rulerViewport.style.overflow = Overflow.Hidden;
            rulerViewport.pickingMode = PickingMode.Ignore;
            rulerContent = new VisualElement { name = "ZPunkRulerTicks" };
            rulerContent.style.position = Position.Relative;
            rulerContent.style.flexShrink = 0;
            rulerContent.style.height = 25;
            rulerContent.pickingMode = PickingMode.Ignore;
            rulerViewport.Add(rulerContent);
            fixedRuler.Add(rulerViewport);
            editorViewport.Add(fixedRuler);

            // This transparent sibling of the ScrollView is only pickable at
            // existing MIDI notes. Empty spaces still reach the ScrollView for
            // normal scrolling and tap-to-add editing.
            noteTouchLayer = new VisualElement { name = "ZPunkMidiNoteTouchOverlay" };
            noteTouchLayer.style.position = Position.Absolute;
            noteTouchLayer.style.left = 57;
            noteTouchLayer.style.right = 0;
            noteTouchLayer.style.top = 25;
            noteTouchLayer.style.bottom = 0;
            noteTouchLayer.style.overflow = Overflow.Hidden;
            noteTouchLayer.pickingMode = PickingMode.Ignore;
            noteTouchLayer.style.display = DisplayStyle.None;
            editorViewport.Add(noteTouchLayer);
            root.Add(editorViewport);

            var velocityRow = new VisualElement();
            velocityRow.style.flexDirection = FlexDirection.Row;
            velocityRow.style.alignItems = Align.Center;
            velocityRow.style.marginTop = 9;
            var caption = Txt("VELOCITY",10,Muted);
            caption.style.width = 75;
            velocityRow.Add(caption);
            var velRail = new VisualElement { name = "ZPunkVelocity" };
            velRail.style.flexGrow = 1;
            velRail.style.height = 36;
            velRail.style.position = Position.Relative;
            velRail.style.justifyContent = Justify.Center;
            var velBase = Box(new Color(.055f,.075f,.12f),5);
            velBase.style.height = 8;
            velBase.pickingMode=PickingMode.Ignore;
            velRail.Add(velBase);
            var velFill = Box(Accent,5);
            velFill.style.position = Position.Absolute;
            velFill.style.left = 0;
            velFill.style.top = 14;
            velFill.style.height = 8;
            velFill.style.width = new Length(velocity/127f*100,LengthUnit.Percent);
            velFill.pickingMode=PickingMode.Ignore;
            velRail.Add(velFill);
            var velThumb = Box(Ink,6);
            velThumb.style.position=Position.Absolute;
            velThumb.style.width=13;
            velThumb.style.height=22;
            velThumb.style.top=7;
            velThumb.style.left=new Length(velocity/127f*100,LengthUnit.Percent);
            velThumb.pickingMode=PickingMode.Ignore;
            velRail.Add(velThumb);
            velocityFill = velFill;
            velocityThumb = velThumb;
            Action<Vector2> setVelocity=(position)=>
            {
                float normalized=Mathf.Clamp01(velRail.WorldToLocal(position).x/Mathf.Max(1,velRail.contentRect.width));
                int next = Mathf.Clamp(Mathf.RoundToInt(1+126*normalized),1,127);
                if (next == velocity) return;
                velocity = next;
                RefreshVelocityRail();
                ChangeVelocity();
            };
            velRail.RegisterCallback<PointerDownEvent>(evt=>
            {
                if(evt.button!=0)return;
                velRail.CapturePointer(evt.pointerId);
                setVelocity(evt.position);
                evt.StopPropagation();
            });
            velRail.RegisterCallback<PointerMoveEvent>(evt=>
            {
                if(!velRail.HasPointerCapture(evt.pointerId))return;
                setVelocity(evt.position);
                evt.StopPropagation();
            });
            velRail.RegisterCallback<PointerUpEvent>(evt=>
            {
                if(!velRail.HasPointerCapture(evt.pointerId))return;
                setVelocity(evt.position);
                velRail.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            velocityRow.Add(velRail);
            selectedInfo = Txt("110",11,Accent);
            selectedInfo.style.width = 43;
            selectedInfo.style.unityTextAlign = TextAnchor.MiddleRight;
            velocityRow.Add(selectedInfo);
            root.Add(velocityRow);
            var footer = Txt("TAP: add/remove  |  DRAG NOTE: move steps / pitch  |  RIGHT END: resize  |  EDGE: scroll",10,Muted);
            footer.style.whiteSpace = WhiteSpace.Normal;
            footer.style.marginTop = 5;
            footer.style.marginBottom = 8;
            root.Add(footer);
            BuildSamplerPage();
            BuildGeneratorPanel();
            BuildDrumDesignerPage();
            BuildChordMenuOverlay(); // Added last so it floats above the piano roll.
        }

        // The designer is a compact, fixed two-row panel rather than a scroll view.
        // UI Toolkit pointer handling below uses discrete detents; the DSP/audio
        // implementation remains in the existing drum sequencer and master tap.
        private void BuildDrumDesignerPage()
        {
            drumDesignerPage = new VisualElement { name = "ZPunkDrumDesignerPage" };
            drumDesignerPage.style.position = Position.Absolute;
            drumDesignerPage.style.left = 0;
            drumDesignerPage.style.right = 0;
            drumDesignerPage.style.top = 0;
            drumDesignerPage.style.bottom = 0;
            drumDesignerPage.style.backgroundColor = Surface;
            drumDesignerPage.style.paddingLeft = 8;
            drumDesignerPage.style.paddingRight = 8;
            drumDesignerPage.style.paddingTop = 8;
            drumDesignerPage.style.paddingBottom = 8;
            drumDesignerPage.style.flexDirection = FlexDirection.Column;
            drumDesignerPage.style.overflow = Overflow.Hidden;
            drumDesignerPage.style.display = DisplayStyle.None;

            // Keep all actions visible above the pad selector and knobs.
            var head = new VisualElement();
            head.style.flexDirection = FlexDirection.Row;
            head.style.justifyContent = Justify.SpaceBetween;
            head.style.alignItems = Align.Center;
            var back = Btn("BACK", () => ShowDrumDesigner(false), 70);
            var audition = Btn("AUDITION", AuditionDrumDesigner, 90);
            var reset = Btn("RESET", ResetDrumShape, 76);
            back.style.height = 38;
            audition.style.height = 38;
            reset.style.height = 38;
            back.style.minWidth = 65;
            audition.style.minWidth = 85;
            reset.style.minWidth = 72;
            head.Add(back);
            head.Add(audition);
            head.Add(reset);
            drumDesignerPage.Add(head);

            var heading = Txt("DRUM DESIGNER", 15, Accent);
            heading.style.unityFontStyleAndWeight = FontStyle.Bold;
            heading.style.marginTop = 3;
            heading.style.marginBottom = 4;
            drumDesignerPage.Add(heading);

            // Presets sit above the pads without adding a scroll region or changing
            // the original two-row, four-knob layout.
            var presetRow = new VisualElement();
            presetRow.style.flexDirection = FlexDirection.Row;
            presetRow.style.alignItems = Align.Center;
            presetRow.style.height = 35;
            presetRow.style.flexShrink = 0;
            presetRow.style.marginBottom = 4;
            var presetCaption = Txt("PRESET", 11, Muted);
            presetCaption.style.minWidth = 52;
            presetCaption.style.unityFontStyleAndWeight = FontStyle.Bold;
            presetRow.Add(presetCaption);
            drumPresetButton = Btn("CUSTOM  ▾", OpenDrumPresetMenu, 0);
            drumPresetButton.style.height = 33;
            drumPresetButton.style.flexGrow = 1;
            drumPresetButton.style.flexShrink = 1;
            drumPresetButton.style.minWidth = 0;
            drumPresetButton.style.fontSize = 11;
            drumPresetButton.style.unityTextAlign = TextAnchor.MiddleCenter;
            presetRow.Add(drumPresetButton);
            var savePreset = Btn("SAVE", OpenSaveDrumPresetMenu, 54);
            savePreset.style.height = 33;
            savePreset.style.fontSize = 11;
            savePreset.style.marginRight = 0;
            presetRow.Add(savePreset);
            drumDesignerPage.Add(presetRow);

            // Explicitly arrange the eight drum sounds in two rows of four.
            // Using dedicated rows avoids flex-wrap rounding placing only three
            // buttons on a row on narrow phone displays.
            var pads = new VisualElement();
            pads.style.flexDirection = FlexDirection.Column;
            pads.style.width = Length.Percent(100);
            pads.style.flexShrink = 0;
            for (int rowIndex = 0; rowIndex < 2; ++rowIndex)
            {
                var padRow = new VisualElement();
                padRow.style.flexDirection = FlexDirection.Row;
                padRow.style.width = Length.Percent(100);
                padRow.style.height = 40;
                padRow.style.flexShrink = 0;
                for (int column = 0; column < 4; ++column)
                {
                    int lane = rowIndex * 4 + column;
                    var button = Btn(DrumDesignerNames[lane], () =>
                    {
                        drumDesignerLane = lane;
                        RefreshDrumDesigner();
                        AuditionDrumDesigner();
                    }, 0);
                    button.style.flexGrow = 1;
                    button.style.flexShrink = 1;
                    button.style.flexBasis = new Length(0, LengthUnit.Pixel);
                    button.style.minWidth = 0;
                    button.style.height = 38;
                    button.style.marginRight = column == 3 ? 0 : 2;
                    button.style.marginBottom = 2;
                    button.style.paddingLeft = 1;
                    button.style.paddingRight = 1;
                    button.style.fontSize = 11;
                    button.style.unityTextAlign = TextAnchor.MiddleCenter;
                    button.name = "ZPunkDrumDesignLane" + lane;
                    padRow.Add(button);
                }
                pads.Add(padRow);
            }
            drumDesignerPage.Add(pads);

            drumDesignerLaneLabel = Txt("KICK / SHAPE", 13, Accent);
            drumDesignerLaneLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            drumDesignerLaneLabel.style.marginTop = 8;
            drumDesignerLaneLabel.style.marginBottom = 3;
            drumDesignerPage.Add(drumDesignerLaneLabel);

            var shaping = new VisualElement { name = "ZPunkDrumDesignControls" };
            shaping.style.flexDirection = FlexDirection.Row;
            shaping.style.flexWrap = Wrap.Wrap;
            shaping.style.width = Length.Percent(100);
            shaping.style.flexShrink = 0;
            drumDesignerPage.Add(shaping);

            // Seven choices including OFF; a compact row keeps the fixed,
            // non-scrolling phone layout and the existing 4x2 knob grid.
            var characterRow = new VisualElement { name = "ZPunkDrumCharacterRow" };
            characterRow.style.flexDirection = FlexDirection.Row;
            characterRow.style.alignItems = Align.Center;
            characterRow.style.height = 36;
            characterRow.style.flexShrink = 0;
            characterRow.style.marginTop = 2;
            characterRow.Add(Txt("FX", 11, Accent));
            drumCharacterButton = Btn("OFF  ▾", OpenDrumCharacterMenu, 91);
            drumCharacterButton.style.height = 32;
            drumCharacterButton.style.marginLeft = 5;
            drumCharacterButton.style.marginRight = 6;
            characterRow.Add(drumCharacterButton);
            characterRow.Add(Txt("AMT", 11, Muted));
            drumCharacterMinus = Btn("−", () => StepDrumCharacter(-1), 34);
            drumCharacterMinus.style.height = 32;
            drumCharacterMinus.style.marginLeft = 3;
            characterRow.Add(drumCharacterMinus);
            drumCharacterAmountLabel = Txt("0%", 11, Ink);
            drumCharacterAmountLabel.style.width = 38;
            drumCharacterAmountLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
            characterRow.Add(drumCharacterAmountLabel);
            drumCharacterPlus = Btn("+", () => StepDrumCharacter(1), 34);
            drumCharacterPlus.style.height = 32;
            characterRow.Add(drumCharacterPlus);
            drumDesignerPage.Add(characterRow);

            var hint = Txt("TAP LEFT/RIGHT: -/+  •  DRAG VERTICALLY: STEPS  •  GLUE: MASTER", 10, Muted);
            hint.style.whiteSpace = WhiteSpace.Normal;
            hint.style.unityTextAlign = TextAnchor.MiddleCenter;
            hint.style.marginTop = 5;
            drumDesignerPage.Add(hint);
            root.Add(drumDesignerPage);
            BuildDrumPresetOverlay();
        }

        // Menu content is an overlay, not a second page or persistent scroller.
        // Only the popup may scroll on exceptionally short phone screens.
        private void BuildDrumPresetOverlay()
        {
            drumPresetOverlay = new VisualElement { name = "ZPunkDrumPresetOverlay" };
            drumPresetOverlay.style.position = Position.Absolute;
            drumPresetOverlay.style.left = 0;
            drumPresetOverlay.style.right = 0;
            drumPresetOverlay.style.top = 0;
            drumPresetOverlay.style.bottom = 0;
            drumPresetOverlay.style.alignItems = Align.Center;
            drumPresetOverlay.style.justifyContent = Justify.Center;
            drumPresetOverlay.style.backgroundColor = new Color(0f, 0f, 0f, .55f);
            drumPresetOverlay.style.display = DisplayStyle.None;
            drumPresetOverlay.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.target != drumPresetOverlay) return;
                CloseDrumPresetMenu();
                evt.StopPropagation();
            });
            drumPresetPanel = new VisualElement { name = "ZPunkDrumPresetPanel" };
            drumPresetPanel.style.width = Length.Percent(94);
            drumPresetPanel.style.flexDirection = FlexDirection.Column;
            drumPresetPanel.style.flexShrink = 1;
            drumPresetPanel.style.minHeight = 0;
            drumPresetPanel.style.paddingTop = 9;
            drumPresetPanel.style.paddingBottom = 9;
            drumPresetPanel.style.paddingLeft = 8;
            drumPresetPanel.style.paddingRight = 8;
            drumPresetPanel.style.backgroundColor = Surface;
            drumPresetPanel.style.borderTopLeftRadius = 9;
            drumPresetPanel.style.borderTopRightRadius = 9;
            drumPresetPanel.style.borderBottomLeftRadius = 9;
            drumPresetPanel.style.borderBottomRightRadius = 9;
            drumPresetPanel.style.borderTopWidth = 1;
            drumPresetPanel.style.borderBottomWidth = 1;
            drumPresetPanel.style.borderLeftWidth = 1;
            drumPresetPanel.style.borderRightWidth = 1;
            drumPresetPanel.style.borderTopColor = Accent;
            drumPresetPanel.style.borderBottomColor = Accent;
            drumPresetPanel.style.borderLeftColor = Accent;
            drumPresetPanel.style.borderRightColor = Accent;
            drumPresetOverlay.Add(drumPresetPanel);
            root.Add(drumPresetOverlay);
        }

        private void CloseDrumPresetMenu()
        {
            if (drumPresetOverlay != null)
                drumPresetOverlay.style.display = DisplayStyle.None;
        }

        private void ShowDrumPresetMenu(string heading, Action<VisualElement> populate,
            float preferredHeight = 405f)
        {
            if (!showingDrumDesigner || drumPresetOverlay == null || drumPresetPanel == null) return;
            drumPresetPanel.Clear();
            drumPresetPanel.style.height = Mathf.Min(preferredHeight,
                Mathf.Max(130f, root.resolvedStyle.height - 16f));
            var title = Txt(heading, 14, Accent);
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.marginBottom = 8;
            drumPresetPanel.Add(title);
            var list = new ScrollView(ScrollViewMode.Vertical);
            list.style.flexShrink = 1;
            list.style.flexGrow = 1;
            list.style.minHeight = 0;
            list.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            list.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            populate(list.contentContainer);
            drumPresetPanel.Add(list);
            var close = Btn("CANCEL", CloseDrumPresetMenu, 0);
            close.style.height = 34;
            close.style.marginRight = 0;
            close.style.marginTop = 6;
            close.style.unityTextAlign = TextAnchor.MiddleCenter;
            drumPresetPanel.Add(close);
            drumPresetOverlay.style.display = DisplayStyle.Flex;
            drumPresetOverlay.BringToFront();
        }

        private void AddDrumPresetOptions(VisualElement target, string[] labels, Action<int> click)
        {
            for (int start = 0; start < labels.Length; start += 2)
            {
                var row = new VisualElement();
                row.style.flexDirection = FlexDirection.Row;
                row.style.height = 38;
                row.style.flexShrink = 0;
                row.style.marginBottom = 3;
                for (int column = 0; column < 2; ++column)
                {
                    int index = start + column;
                    if (index >= labels.Length) break;
                    int chosen = index;
                    var b = Btn(labels[index], () => click(chosen), 0);
                    b.style.height = 36;
                    b.style.flexGrow = 1;
                    b.style.flexShrink = 1;
                    b.style.flexBasis = new Length(0, LengthUnit.Pixel);
                    b.style.minWidth = 0;
                    b.style.fontSize = 11;
                    b.style.unityTextAlign = TextAnchor.MiddleCenter;
                    b.style.paddingLeft = 3;
                    b.style.paddingRight = 3;
                    row.Add(b);
                }
                target.Add(row);
            }
        }

        private List<DrumShapeData> CurrentDrumShapes()
        {
            if (song == null || song.tracks == null || song.tracks.Count == 0 ||
                song.tracks[0] == null || song.tracks[0].instrument == null) return null;
            return song.tracks[0].instrument.drumDesign;
        }

        private string SelectedDrumKitId()
        {
            FindDrumEngine();
            if (drumEngine != null) return drumEngine.CaptureKitId();
            var inst = song != null && song.tracks != null && song.tracks.Count > 0 &&
                song.tracks[0] != null ? song.tracks[0].instrument : null;
            return inst != null ? inst.drumKitId : null;
        }

        private void RefreshDrumPresetLabel()
        {
            if (drumPresetButton == null) return;
            var shapes = CurrentDrumShapes();
            string kitId = SelectedDrumKitId();
            for (int i = 0; i < ZPunkDrumDesignPresets.Names.Length; ++i)
            {
                if (!ZPunkDrumDesignPresets.MatchesFactory(shapes,
                    ZPunkDrumDesignPresets.CreateFactory(i, kitId))) continue;
                drumPresetButton.text = ZPunkDrumDesignPresets.Names[i] + "  ▾";
                return;
            }
            for (int i = 0; i < ZPunkDrumDesignPresets.UserSlotCount; ++i)
            {
                if (!ZPunkDrumDesignPresets.Matches(shapes,
                    ZPunkDrumDesignPresets.LoadUser(i))) continue;
                drumPresetButton.text = ZPunkDrumDesignPresets.UserLabel(i) + "  ▾";
                return;
            }
            drumPresetButton.text = "CUSTOM  ▾";
        }

        private void ApplyDrumPreset(List<DrumShapeData> shapes)
        {
            if (shapes == null || !CanWriteDrumShape()) return;
            // An independent new list prevents modifying a saved user preset.
            song.tracks[0].instrument.drumDesign = ZPunkDrumDesignPresets.Clone(shapes);
            FindDrumEngine();
            if (drumEngine != null)
            {
                drumEngine.SetDrumFxTempo(song.bpm);
                drumEngine.ApplyDAWDrumDesign(song.tracks[0].instrument.drumDesign);
            }
            CloseDrumPresetMenu();
            RefreshDrumDesigner();
            AuditionDrumDesigner();
        }

        private void OpenDrumPresetMenu()
        {
            ShowDrumPresetMenu("DRUM DESIGN PRESETS", container =>
            {
                var factory = Txt("FACTORY / TUNED FOR SELECTED KIT", 10, Muted);
                factory.style.marginBottom = 5;
                container.Add(factory);
                AddDrumPresetOptions(container, ZPunkDrumDesignPresets.Names,
                    index => ApplyDrumPreset(ZPunkDrumDesignPresets.PreserveDecayAndTrim(
                        ZPunkDrumDesignPresets.CreateFactory(index, SelectedDrumKitId()), CurrentDrumShapes())));

                var user = Txt("YOUR SAVED DESIGNS", 10, Muted);
                user.style.marginTop = 5;
                user.style.marginBottom = 5;
                container.Add(user);
                var labels = new string[ZPunkDrumDesignPresets.UserSlotCount];
                for (int slot = 0; slot < labels.Length; ++slot)
                    labels[slot] = ZPunkDrumDesignPresets.LoadUser(slot) != null
                        ? ZPunkDrumDesignPresets.UserLabel(slot) : "EMPTY " + (slot + 1);
                AddDrumPresetOptions(container, labels, slot =>
                {
                    var saved = ZPunkDrumDesignPresets.LoadUser(slot);
                    if (saved != null) ApplyDrumPreset(saved);
                });
            });
        }

        private void OpenSaveDrumPresetMenu()
        {
            ShowDrumPresetMenu("SAVE CURRENT DRUM DESIGN", container =>
            {
                var hint = Txt("CHOOSE ONE OF FOUR DEVICE PRESET SLOTS", 11, Muted);
                hint.style.marginBottom = 9;
                container.Add(hint);
                var labels = new string[ZPunkDrumDesignPresets.UserSlotCount];
                for (int slot = 0; slot < labels.Length; ++slot)
                    labels[slot] = (ZPunkDrumDesignPresets.LoadUser(slot) == null ? "SAVE " : "REPLACE ") +
                        ZPunkDrumDesignPresets.UserLabel(slot);
                AddDrumPresetOptions(container, labels, slot =>
                {
                    if (ZPunkDrumDesignPresets.LoadUser(slot) != null)
                        ConfirmReplaceDrumPreset(slot);
                    else SaveDrumPresetSlot(slot);
                });
            }, 230f);
        }

        private void ConfirmReplaceDrumPreset(int slot)
        {
            ShowDrumPresetMenu("REPLACE " + ZPunkDrumDesignPresets.UserLabel(slot) + "?", container =>
            {
                var warning = Txt("THIS WILL REPLACE THE SAVED DESIGN IN THIS SLOT.", 12, Ink);
                warning.style.whiteSpace = WhiteSpace.Normal;
                warning.style.marginBottom = 10;
                container.Add(warning);
                AddDrumPresetOptions(container, new[] { "BACK", "REPLACE" },
                    option => { if (option == 0) OpenSaveDrumPresetMenu(); else SaveDrumPresetSlot(slot); });
            }, 195f);
        }

        private void SaveDrumPresetSlot(int slot)
        {
            if (!ZPunkDrumDesignPresets.SaveUser(slot, CurrentDrumShapes()))
            {
                ShowDrumPresetMenu("COULD NOT SAVE PRESET", container =>
                {
                    container.Add(Txt("CHECK DEVICE STORAGE AND TRY AGAIN.", 12, Ink));
                }, 185f);
                return;
            }
            CloseDrumPresetMenu();
            RefreshDrumPresetLabel();
        }

        private sealed class DrumKnobBinding
        {
            public VisualElement face;
            public VisualElement marker;
            public Label readout;
            public float min, max;
            public int detents;
            public int step, initialStep, pointerId = -1;
            public float initialY;
            public bool moved;
            public Action<float> write;
            public Func<float, string> display;
        }

        private static void PaintDrumKnob(DrumKnobBinding knob)
        {
            float fraction = knob.detents > 0 ? (float)knob.step / knob.detents : 0f;
            float value = Mathf.Lerp(knob.min, knob.max, fraction);
            knob.readout.text = knob.display != null ? knob.display(value) : value.ToString("0.##");
            // Marker moves along the upper 270 degrees: left/bottom -> top -> right/bottom.
            float theta = (-225f + 270f * fraction) * Mathf.Deg2Rad;
            knob.marker.style.left = 28f + Mathf.Cos(theta) * 22f;
            knob.marker.style.top = 28f + Mathf.Sin(theta) * 22f;
        }

        private static void SetDrumKnobStep(DrumKnobBinding knob, int step)
        {
            step = Mathf.Clamp(step, 0, knob.detents);
            if (step == knob.step) return; // no redundant save or preview within a detent
            knob.step = step;
            float value = Mathf.Lerp(knob.min, knob.max, (float)step / knob.detents);
            knob.write(value);
            PaintDrumKnob(knob);
        }

        private void AddDrumKnob(VisualElement target, string name, float min, float max, int detents,
            Func<float> read, Action<float> write, Func<float, string> display = null, bool master = false)
        {
            var tile = new VisualElement();
            tile.style.width = Length.Percent(25);
            tile.style.minWidth = 0;
            tile.style.height = 108;
            tile.style.flexShrink = 0;
            tile.style.alignItems = Align.Center;
            tile.style.justifyContent = Justify.Center;
            tile.style.paddingTop = 2;
            tile.style.paddingBottom = 2;

            var face = new VisualElement { name = "ZPunkDrumKnob" + name.Replace(" ", "") };
            face.style.width = 62;
            face.style.height = 62;
            face.style.flexShrink = 0;
            face.style.position = Position.Relative;
            face.style.backgroundColor = Raised;
            face.style.borderTopLeftRadius = 31;
            face.style.borderTopRightRadius = 31;
            face.style.borderBottomLeftRadius = 31;
            face.style.borderBottomRightRadius = 31;
            face.style.borderLeftWidth = 2;
            face.style.borderRightWidth = 2;
            face.style.borderTopWidth = 2;
            face.style.borderBottomWidth = 2;
            var rim = master ? Accent : new Color(.29f, .39f, .48f);
            face.style.borderLeftColor = rim;
            face.style.borderRightColor = rim;
            face.style.borderTopColor = rim;
            face.style.borderBottomColor = rim;
            face.style.alignItems = Align.Center;
            face.style.justifyContent = Justify.Center;
            face.pickingMode = PickingMode.Position;

            var valueLabel = Txt("", 12, master ? Accent : Ink);
            valueLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
            valueLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            valueLabel.style.whiteSpace = WhiteSpace.NoWrap;
            valueLabel.pickingMode = PickingMode.Ignore;
            face.Add(valueLabel);

            for (int tick = 0; tick <= 8; ++tick)
            {
                float angle = (-225f + tick * 33.75f) * Mathf.Deg2Rad;
                var notch = new VisualElement();
                notch.style.position = Position.Absolute;
                notch.style.left = 29f + Mathf.Cos(angle) * 26f;
                notch.style.top = 29f + Mathf.Sin(angle) * 26f;
                notch.style.width = 3;
                notch.style.height = 3;
                notch.style.borderTopLeftRadius = 1.5f;
                notch.style.borderTopRightRadius = 1.5f;
                notch.style.borderBottomLeftRadius = 1.5f;
                notch.style.borderBottomRightRadius = 1.5f;
                notch.style.backgroundColor = new Color(.45f, .55f, .62f, .7f);
                notch.pickingMode = PickingMode.Ignore;
                face.Add(notch);
            }

            var marker = new VisualElement();
            marker.style.position = Position.Absolute;
            marker.style.width = 6;
            marker.style.height = 6;
            marker.style.borderTopLeftRadius = 3;
            marker.style.borderTopRightRadius = 3;
            marker.style.borderBottomLeftRadius = 3;
            marker.style.borderBottomRightRadius = 3;
            marker.style.backgroundColor = Accent;
            marker.pickingMode = PickingMode.Ignore;
            face.Add(marker);
            tile.Add(face);

            var caption = Txt(name, 11, master ? Accent : Muted);
            caption.style.unityFontStyleAndWeight = FontStyle.Bold;
            caption.style.unityTextAlign = TextAnchor.MiddleCenter;
            caption.style.marginTop = 5;
            caption.style.whiteSpace = WhiteSpace.NoWrap;
            tile.Add(caption);

            var knob = new DrumKnobBinding
            {
                face = face, marker = marker, readout = valueLabel,
                min = min, max = max, detents = Mathf.Max(1, detents),
                write = write, display = display
            };
            knob.step = Mathf.Clamp(Mathf.RoundToInt(
                Mathf.InverseLerp(min, max, Mathf.Clamp(read(), min, max)) * knob.detents), 0, knob.detents);
            PaintDrumKnob(knob);

            face.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || knob.pointerId >= 0) return;
                knob.pointerId = evt.pointerId;
                knob.initialY = evt.position.y;
                knob.initialStep = knob.step;
                knob.moved = false;
                face.CapturePointer(evt.pointerId);
                evt.StopPropagation();
            });
            face.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (knob.pointerId != evt.pointerId) return;
                float distance = knob.initialY - evt.position.y;
                if (Mathf.Abs(distance) >= 5f) knob.moved = true;
                if (knob.moved)
                    SetDrumKnobStep(knob, knob.initialStep + Mathf.RoundToInt(distance / 12f));
                evt.StopPropagation();
            });
            face.RegisterCallback<PointerUpEvent>(evt =>
            {
                if (knob.pointerId != evt.pointerId) return;
                // A tap moves one detent. Left half decreases; right half increases.
                if (!knob.moved)
                {
                    float midpoint = face.worldBound.xMin + face.worldBound.width * .5f;
                    SetDrumKnobStep(knob, knob.step + (evt.position.x < midpoint ? -1 : 1));
                }
                knob.pointerId = -1;
                if (face.HasPointerCapture(evt.pointerId)) face.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            face.RegisterCallback<PointerCancelEvent>(evt =>
            {
                if (knob.pointerId != evt.pointerId) return;
                knob.pointerId = -1;
                if (face.HasPointerCapture(evt.pointerId)) face.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            face.RegisterCallback<PointerCaptureOutEvent>(evt =>
            {
                if (knob.pointerId == evt.pointerId) knob.pointerId = -1;
            });
            face.RegisterCallback<DetachFromPanelEvent>(evt => { knob.pointerId = -1; });
            target.Add(tile);
        }

        private void AuditionDrumDesigner()
        {
            // Shape edits and preset changes still apply live, but must never
            // create an extra drum hit while either sequencer is running.
            if (songTransport == null)
                songTransport = FindObjectOfType<ZPunkSongTransport>();
            if (songTransport != null && songTransport.IsPlaying) return;

            FindDrumEngine();
            if (drumEngine == null || drumEngine.IsPlaying) return;
            drumEngine.PreviewDAWDrum(drumDesignerLane);
        }

        private bool CanWriteDrumShape()
        {
            if (projects == null || song == null || song.tracks == null || song.tracks.Count == 0) return false;
            if (!ReferenceEquals(song, projects.CurrentSong))
                song = ArrangementEditing.IndependentCopy(song);
            projects.AcceptArrangementEdit(song);
            if (song.tracks[0].instrument == null)
                song.tracks[0].instrument = new InstrumentState();
            return true;
        }

        private DrumShapeData GetDrumShape(int lane, bool create)
        {
            if (song == null || song.tracks == null || song.tracks.Count == 0) return null;
            var instrument = song.tracks[0].instrument;
            if (instrument == null) return null;
            if (instrument.drumDesign == null)
            {
                if (!create) return null;
                instrument.drumDesign = new List<DrumShapeData>();
            }
            while (create && instrument.drumDesign.Count < 8)
                instrument.drumDesign.Add(new DrumShapeData());
            return lane < instrument.drumDesign.Count ? instrument.drumDesign[lane] : null;
        }

        private void SetDrumShape(Action<DrumShapeData> update)
        {
            if (!CanWriteDrumShape()) return;
            var shape = GetDrumShape(drumDesignerLane, true);
            if (shape == null) return;
            update(shape);
            FindDrumEngine();
            if (drumEngine != null)
            {
                drumEngine.SetDrumFxTempo(song.bpm);
                drumEngine.ApplyDAWDrumDesign(song.tracks[0].instrument.drumDesign);
            }
            AuditionDrumDesigner();
            // Moving any manual knob makes this a custom design, without
            // forcing a re-layout while the user's pointer owns the knob.
            if (drumPresetButton != null) drumPresetButton.text = "CUSTOM  ▾";
        }

        private void OpenDrumCharacterMenu()
        {
            ShowDrumPresetMenu("DRUM CHARACTER FX", container =>
            {
                var note = Txt("ONE EFFECT PER DRUM / 0% IS OFF", 10, Muted);
                note.style.marginBottom = 9;
                container.Add(note);
                AddDrumPresetOptions(container, DrumCharacterNames, index =>
                {
                    CloseDrumPresetMenu();
                    SetDrumShape(shape =>
                    {
                        shape.characterFx = index;
                        // First selection should be immediately audible. Preserve
                        // the user's depth if they temporarily switch effects.
                        if (index != 0 && shape.characterAmount < .01f)
                            shape.characterAmount = .5f;
                    });
                    RefreshDrumDesigner();
                });
            }, 320f);
        }

        private void StepDrumCharacter(int direction)
        {
            var current = GetDrumShape(drumDesignerLane, false);
            if (current == null || current.characterFx == 0) return;
            SetDrumShape(shape => shape.characterAmount = Mathf.Clamp01(
                Mathf.Round(shape.characterAmount * 10f + direction) / 10f));
            RefreshDrumCharacterRow();
        }

        private void RefreshDrumCharacterRow()
        {
            var shape = GetDrumShape(drumDesignerLane, false) ?? new DrumShapeData();
            int effect = Mathf.Clamp(shape.characterFx, 0, DrumCharacterNames.Length - 1);
            bool enabled = effect != 0;
            if (drumCharacterButton != null) drumCharacterButton.text = DrumCharacterNames[effect] + "  ▾";
            if (drumCharacterAmountLabel != null)
                drumCharacterAmountLabel.text = enabled
                    ? Mathf.RoundToInt(shape.characterAmount * 100f) + "%" : "—";
            drumCharacterMinus?.SetEnabled(enabled);
            drumCharacterPlus?.SetEnabled(enabled);
        }

        private void ResetDrumShape()
        {
            SetDrumShape(shape => { shape.tune = 0; shape.tone = .5f; shape.decay = 1f;
                shape.pan = 0; shape.trim = 0; shape.drive = 0; shape.punch = 0;
                shape.characterFx = 0; shape.characterAmount = 0f; });
            RefreshDrumDesigner();
        }

        private void RefreshDrumDesigner()
        {
            if (drumDesignerPage == null || song == null) return;
            RefreshDrumPresetLabel();
            RefreshDrumCharacterRow();
            drumDesignerLaneLabel.text = DrumDesignerNames[drumDesignerLane] + "  /  SHAPE";
            for (int i = 0; i < 8; ++i)
            {
                var pad = drumDesignerPage.Q<Button>("ZPunkDrumDesignLane" + i);
                if (pad != null) pad.style.backgroundColor = i == drumDesignerLane ? Accent : Raised;
                if (pad != null) pad.style.color = i == drumDesignerLane ? Surface : Ink;
            }
            var controls = drumDesignerPage.Q<VisualElement>("ZPunkDrumDesignControls");
            if (controls == null) return;
            controls.Clear();
            var shape = GetDrumShape(drumDesignerLane, false) ?? new DrumShapeData();
            // Four stepped knobs per row. Eight knobs: seven per-drum plus master GLUE.
            AddDrumKnob(controls, "TUNE", -12f, 12f, 24, () => shape.tune,
                v => SetDrumShape(d => d.tune = Mathf.Round(v)),
                v => (v > 0f ? "+" : "") + Mathf.RoundToInt(v) + " st");
            AddDrumKnob(controls, "TONE", 0f, 1f, 20, () => shape.tone,
                v => SetDrumShape(d => d.tone = v),
                v => Mathf.RoundToInt(v * 100f) + "%");
            AddDrumKnob(controls, "DECAY", .04f, 1f, 24, () => shape.decay,
                v => SetDrumShape(d => d.decay = v),
                v => DrumDecayKnobLabel(v));
            AddDrumKnob(controls, "PAN", -1f, 1f, 20, () => shape.pan,
                v => SetDrumShape(d => d.pan = v),
                v => Mathf.Abs(v) < .001f ? "C" :
                    Mathf.RoundToInt(Mathf.Abs(v) * 100f) + (v < 0 ? " L" : " R"));
            AddDrumKnob(controls, "TRIM", -12f, 12f, 24, () => shape.trim,
                v => SetDrumShape(d => d.trim = Mathf.Round(v)),
                v => (v > 0f ? "+" : "") + Mathf.RoundToInt(v) + " dB");
            AddDrumKnob(controls, "DRIVE", 0f, 1f, 20, () => shape.drive,
                v => SetDrumShape(d => d.drive = v),
                v => Mathf.RoundToInt(v * 100f) + "%");
            AddDrumKnob(controls, "PUNCH", 0f, 1f, 20, () => shape.punch,
                v => SetDrumShape(d => d.punch = v),
                v => Mathf.RoundToInt(v * 100f) + "%");
            AddDrumKnob(controls, "GLUE", 0f, 1f, 20,
                () => song != null ? song.masterGlue : 0f,
                v =>
                {
                    if (!CanWriteDrumShape()) return;
                    song.masterGlue = v;
                    ZPunkMasterAudioTap.GlueAmount = v;
                    AuditionDrumDesigner();
                },
                v => Mathf.RoundToInt(v * 100f) + "%", true);
        }

        private string DrumDecayKnobLabel(float amount)
        {
            if (amount >= .9999f) return "FULL";
            FindDrumEngine();
            float seconds = drumEngine != null
                ? drumEngine.GetDrumDecaySeconds(drumDesignerLane + 1, amount) : -1f;
            if (seconds <= 0f) return "PCM?";
            return seconds < 1f ? Mathf.RoundToInt(seconds * 1000f) + "ms"
                : seconds.ToString("0.0") + "s";
        }

        private void OpenDrumDesigner()
        {
            if (song?.tracks == null || trackIndex != 0) return;
            drumDesignerLane = Mathf.Clamp(selectedEventRow, 0, 7);
            ShowSampler(false);
            ShowDrumDesigner(true);
        }

        private void ShowDrumDesigner(bool show)
        {
            showingDrumDesigner = show;
            if (!show) CloseDrumPresetMenu();
            if (drumDesignerPage == null) return;
            drumDesignerPage.style.display = show ? DisplayStyle.Flex : DisplayStyle.None;
            if (show) RefreshDrumDesigner();
        }

        private void BuildSamplerPage()
        {
            // One vertical scroll surface: no horizontally clipped transport or
            // nested scroll areas that steal pad and waveform drag gestures.
            samplerScroll = new ScrollView(ScrollViewMode.Vertical) { name = "ZPunkSamplerPage" };
            samplerScroll.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            samplerScroll.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            samplerScroll.contentContainer.style.flexDirection = FlexDirection.Column;
            samplerScroll.contentContainer.style.paddingBottom = 20;
            samplerPage = samplerScroll;
            samplerPage.style.display = DisplayStyle.None;
            samplerPage.style.flexDirection = FlexDirection.Column;
            samplerPage.style.flexGrow = 1;
            samplerPage.style.flexShrink = 1;
            samplerPage.style.minHeight = 0;
            samplerPage.style.paddingTop = 9;

            var headingRow = new VisualElement();
            headingRow.style.flexDirection = FlexDirection.Row;
            headingRow.style.alignItems = Align.Center;
            headingRow.style.justifyContent = Justify.SpaceBetween;
            headingRow.style.height = 43;
            var heading = Txt("SAMPLER / SLICE LAB", 16, Ink);
            heading.style.unityFontStyleAndWeight = FontStyle.Bold;
            heading.style.flexShrink = 1;
            headingRow.Add(heading);
            heading.style.flexGrow = 1;
            heading.style.minWidth = 0;
            var back = Btn("BACK", () => ShowSampler(false), 62);
            back.style.height = 38;
            back.style.marginRight = 6;
            headingRow.Add(back);
            var browse = Btn("BROWSE", () => { FindSampler(); samplePlayer?.DawOpenBrowser(); }, 78);
            browse.style.height = 38;
            browse.style.marginRight = 0;
            headingRow.Add(browse);
            samplerPage.Add(headingRow);

            var sampleRow = new VisualElement();
            sampleRow.style.flexDirection = FlexDirection.Row;
            sampleRow.style.alignItems = Align.Center;
            sampleRow.style.height = 36;
            sampleRow.style.marginBottom = 6;
            samplerTitle = Txt("NO SAMPLE", 12, Accent);
            samplerTitle.style.flexGrow = 1;
            samplerTitle.style.flexShrink = 1;
            samplerTitle.style.minWidth = 0;
            samplerTitle.style.whiteSpace = WhiteSpace.NoWrap;
            samplerTitle.style.overflow = Overflow.Hidden;
            samplerTitle.style.textOverflow = TextOverflow.Ellipsis;
            sampleRow.Add(samplerTitle);
            samplerPage.Add(sampleRow);

            // Keep sample tempo separate from the ARRANGE tempo. The TAP and
            // half/double controls are compact enough for portrait phones.
            var tempoRow = new VisualElement();
            tempoRow.style.flexDirection = FlexDirection.Row;
            tempoRow.style.alignItems = Align.Center;
            tempoRow.style.height = 41;
            tempoRow.style.marginBottom = 2;
            samplerBpmLabel = Txt("SOURCE BPM --", 11, Accent);
            samplerBpmLabel.style.flexGrow = 1;
            samplerBpmLabel.style.flexShrink = 1;
            samplerBpmLabel.style.minWidth = 0;
            tempoRow.Add(samplerBpmLabel);
            var tapBpm = Btn("TAP", () =>
            {
                FindSampler();
                samplePlayer?.DawTapSourceBpm();
                RefreshSampler();
            }, 70);
            tapBpm.style.height = 37;
            tapBpm.style.marginRight = 4;
            tapBpm.style.backgroundColor = Accent;
            tapBpm.style.color = new Color(.035f, .09f, .105f);
            tempoRow.Add(tapBpm);
            var halfBpm = Btn("1/2", () =>
            {
                FindSampler();
                samplePlayer?.DawScaleSourceBpm(.5f);
                RefreshSampler();
            }, 48);
            halfBpm.style.height = 37;
            halfBpm.style.marginRight = 4;
            tempoRow.Add(halfBpm);
            var doubleBpm = Btn("x2", () =>
            {
                FindSampler();
                samplePlayer?.DawScaleSourceBpm(2f);
                RefreshSampler();
            }, 48);
            doubleBpm.style.height = 37;
            doubleBpm.style.marginRight = 0;
            tempoRow.Add(doubleBpm);
            samplerPage.Add(tempoRow);
            samplerTapBpmStatus = Txt("", 10, Muted);
            samplerTapBpmStatus.style.display = DisplayStyle.None;
            samplerTapBpmStatus.style.whiteSpace = WhiteSpace.Normal;
            samplerTapBpmStatus.style.marginBottom = 3;
            samplerPage.Add(samplerTapBpmStatus);

            var primaryRow = new VisualElement();
            primaryRow.style.flexDirection = FlexDirection.Row;
            primaryRow.style.alignItems = Align.Center;
            primaryRow.style.height = 53;
            primaryRow.style.marginBottom = 4;
            var sliceHits = Btn("SLICE HITS", () =>
            {
                FindSampler();
                samplePlayer?.DawSliceHits();
                RefreshSampler();
            }, 110);
            sliceHits.style.flexGrow = 1;
            sliceHits.style.flexBasis = new Length(0, LengthUnit.Pixel);
            sliceHits.style.minWidth = 0;
            sliceHits.style.height = 50;
            sliceHits.style.backgroundColor = Accent;
            sliceHits.style.color = new Color(.035f, .09f, .105f);
            sliceHits.style.fontSize = 15;
            primaryRow.Add(sliceHits);
            samplerWarpButton = Btn("WARP OFF", () =>
            {
                FindSampler();
                samplePlayer?.DawToggleAutoWarp();
                RefreshSampler();
            }, 105);
            samplerWarpButton.style.height = 50;
            samplerWarpButton.style.flexGrow = 1;
            samplerWarpButton.style.flexBasis = new Length(0, LengthUnit.Pixel);
            samplerWarpButton.style.minWidth = 0;
            samplerWarpButton.style.marginRight = 0;
            samplerWarpButton.style.fontSize = 11;
            primaryRow.Add(samplerWarpButton);
            samplerPage.Add(primaryRow);

            // Bar slicing complements transient slicing, with exact divisions
            // derived from the original source BPM and the waveform HEAD.
            var barSliceRow = new VisualElement();
            barSliceRow.style.flexDirection = FlexDirection.Row;
            barSliceRow.style.alignItems = Align.Center;
            barSliceRow.style.height = 43;
            barSliceRow.style.marginBottom = 4;
            var barSliceTitle = Txt("SLICE BARS", 10, Muted);
            barSliceTitle.style.width = 85;
            barSliceTitle.style.flexShrink = 0;
            barSliceRow.Add(barSliceTitle);
            foreach (int division in new[] { 1, 2, 4 })
            {
                int beats = division;
                var fraction = beats == 1 ? "1/4" : beats == 2 ? "1/2" : "1/1";
                var button = Btn(fraction, () =>
                {
                    FindSampler();
                    samplePlayer?.DawSliceBars(beats);
                    RefreshSampler();
                }, 58);
                button.style.flexGrow = 1;
                button.style.flexBasis = new Length(0, LengthUnit.Pixel);
                button.style.minWidth = 0;
                button.style.height = 39;
                button.style.marginRight = beats == 4 ? 0 : 5;
                barSliceRow.Add(button);
            }
            samplerPage.Add(barSliceRow);

            samplerHitSliceStatus = Txt("SET HEAD ON A MAIN HIT, THEN SLICE HITS", 10, Muted);
            samplerHitSliceStatus.style.whiteSpace = WhiteSpace.Normal;
            samplerHitSliceStatus.style.marginBottom = 3;
            samplerPage.Add(samplerHitSliceStatus);
            // Amber guide detection runs asynchronously. Show real elapsed time
            // and measured progress; ETA is explicitly approximate.
            samplerHitProgressLabel = Txt("", 10, new Color(.98f, .7f, .37f));
            samplerHitProgressLabel.style.display = DisplayStyle.None;
            samplerPage.Add(samplerHitProgressLabel);
            samplerHitProgressTrack = Box(new Color(.06f, .08f, .12f), 3);
            samplerHitProgressTrack.style.height = 4;
            samplerHitProgressTrack.style.marginBottom = 4;
            samplerHitProgressTrack.style.display = DisplayStyle.None;
            samplerHitProgressFill = new VisualElement();
            samplerHitProgressFill.style.height = Length.Percent(100);
            samplerHitProgressFill.style.backgroundColor = new Color(.98f, .67f, .28f);
            samplerHitProgressFill.style.width = Length.Percent(0);
            samplerHitProgressTrack.Add(samplerHitProgressFill);
            samplerPage.Add(samplerHitProgressTrack);

            // Transport belongs to the waveform being auditioned; the main
            // application play/stop controls above remain unchanged.
            var transport = new VisualElement();
            transport.style.flexDirection = FlexDirection.Row;
            transport.style.alignItems = Align.Center;
            transport.style.height = 47;
            var samplePlay = Btn("PLAY", () => { FindSampler(); samplePlayer?.DawPlaySample(); }, 58);
            var sampleStop = Btn("STOP", () => { FindSampler(); samplePlayer?.DawStopSample(); }, 60);
            samplePlay.style.flexGrow = 1;
            samplePlay.style.flexBasis = new Length(0, LengthUnit.Pixel);
            samplePlay.style.minWidth = 0;
            sampleStop.style.flexGrow = 1;
            sampleStop.style.flexBasis = new Length(0, LengthUnit.Pixel);
            sampleStop.style.minWidth = 0;
            samplePlay.style.backgroundColor = new Color(.12f, .33f, .31f);
            transport.Add(samplePlay);
            transport.Add(sampleStop);
            samplerSnapButton = Btn("HIT SNAP", () =>
            {
                FindSampler();
                samplePlayer?.DawToggleTransientSnap();
                RefreshSampler();
            }, 85);
            samplerSnapButton.style.flexGrow = 1;
            samplerSnapButton.style.flexBasis = new Length(0, LengthUnit.Pixel);
            samplerSnapButton.style.minWidth = 0;
            samplerSnapButton.style.fontSize = 11;
            transport.Add(samplerSnapButton);
            var full = Btn("FULL", () => { FindSampler(); samplePlayer?.DawShowFullSample(); RefreshSampler(); }, 53);
            full.style.flexGrow = 1;
            full.style.flexBasis = new Length(0, LengthUnit.Pixel);
            full.style.minWidth = 0;
            full.style.marginRight = 0;
            transport.Add(full);
            samplerPage.Add(transport);

            samplerWave = Box(new Color(.049f,.073f,.105f), 5);
            samplerWave.style.height = 175;
            samplerWave.style.flexShrink = 0;
            samplerWave.style.marginTop = 3;
            samplerWave.style.marginBottom = 4;
            samplerPage.Add(samplerWave);

            // Keep the warp job status and optional pitch/key tools directly below
            // the waveform, where their effect can be seen while editing samples.
            samplerWarpLabel = Txt("ORIGINAL AUDIO / NON-DESTRUCTIVE SLICING", 10, Muted);
            samplerWarpLabel.style.whiteSpace = WhiteSpace.Normal;
            samplerWarpLabel.style.marginTop = 4;
            samplerPage.Add(samplerWarpLabel);
            samplerWarpProgressLabel = Txt("WARPING", 10, Muted);
            samplerWarpProgressLabel.style.display = DisplayStyle.None;
            samplerPage.Add(samplerWarpProgressLabel);
            samplerWarpProgressTrack = Box(Surface, 3);
            samplerWarpProgressTrack.style.height = 5;
            samplerWarpProgressTrack.style.overflow = Overflow.Hidden;
            samplerWarpProgressTrack.style.display = DisplayStyle.None;
            samplerWarpProgressFill = new VisualElement();
            samplerWarpProgressFill.style.height = Length.Percent(100);
            samplerWarpProgressFill.style.width = Length.Percent(0);
            samplerWarpProgressFill.style.backgroundColor = Accent;
            samplerWarpProgressTrack.Add(samplerWarpProgressFill);
            samplerPage.Add(samplerWarpProgressTrack);


            // Optional pitch/key tools remain available without dominating the
            // chopping workflow or pushing the waveform far down the screen.
            var utility = Box(new Color(.085f,.12f,.17f), 5);
            utility.style.marginTop = 8;
            utility.style.paddingLeft = 8;
            utility.style.paddingRight = 8;
            utility.style.paddingTop = 6;
            utility.style.paddingBottom = 6;
            var pitchRow = new VisualElement();
            pitchRow.style.flexDirection = FlexDirection.Row;
            pitchRow.style.alignItems = Align.Center;
            pitchRow.style.height = 43;
            pitchRow.Add(Txt("PITCH", 11, Muted));
            pitchRow.Add(Btn("-1", () => { FindSampler(); samplePlayer?.DawAdjustPitchSemitones(-1); RefreshSampler(); }, 43));
            samplerPitchLabel = Txt("0 ST", 12, Accent);
            samplerPitchLabel.style.flexGrow = 1;
            samplerPitchLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
            pitchRow.Add(samplerPitchLabel);
            pitchRow.Add(Btn("+1", () => { FindSampler(); samplePlayer?.DawAdjustPitchSemitones(1); RefreshSampler(); }, 43));
            pitchRow.Add(Btn("RESET", () => { FindSampler(); samplePlayer?.DawSetPitchSemitones(0); RefreshSampler(); }, 63));
            utility.Add(pitchRow);
            samplerSourceKeyLabel = Txt("SOURCE KEY / NO SAMPLE", 11, Ink);
            samplerSourceKeyLabel.style.whiteSpace = WhiteSpace.Normal;
            utility.Add(samplerSourceKeyLabel);
            samplerPitchedKeyLabel = Txt("PITCHED KEY / UNKNOWN", 11, Accent);
            samplerPitchedKeyLabel.style.whiteSpace = WhiteSpace.Normal;
            samplerPitchedKeyLabel.style.marginTop = 4;
            utility.Add(samplerPitchedKeyLabel);
            samplerLibraryLabel = Txt("SAMPLE LIBRARY", 10, Muted);
            samplerLibraryLabel.style.whiteSpace = WhiteSpace.Normal;
            samplerLibraryLabel.style.marginTop = 6;
            utility.Add(samplerLibraryLabel);
            samplerPage.Add(utility);


            var zoomRow = new VisualElement();
            zoomRow.style.flexDirection = FlexDirection.Row;
            zoomRow.style.alignItems = Align.Center;
            zoomRow.style.height = 45;
            var zoomOut = Btn("- ZOOM", () => { FindSampler(); samplePlayer?.DawZoomSample(false); }, 77);
            var zoomIn = Btn("+ ZOOM", () => { FindSampler(); samplePlayer?.DawZoomSample(true); }, 77);
            samplerGridButton = Btn("GRID ON", () => { FindSampler(); samplePlayer?.DawToggleWaveGrid(); RefreshSampler(); }, 77);
            foreach (var button in new[] { zoomOut, zoomIn, samplerGridButton })
            {
                button.style.flexGrow = 1;
                button.style.flexBasis = new Length(0, LengthUnit.Pixel);
                button.style.minWidth = 0;
                button.style.marginRight = 5;
                zoomRow.Add(button);
            }
            samplerGridButton.style.marginRight = 0;
            samplerPage.Add(zoomRow);

            var editRow = new VisualElement();
            editRow.style.flexDirection = FlexDirection.Row;
            editRow.style.alignItems = Align.Center;
            editRow.style.height = 47;
            var add = Btn("ADD MARK", () => { FindSampler(); samplePlayer?.DawAddMarker(); RefreshSampler(); }, 87);
            var del = Btn("DELETE", () => { FindSampler(); samplePlayer?.DawDeleteMarker(); RefreshSampler(); }, 72);
            var apply = Btn("APPLY CHOPS", ApplySamplerChops, 98);
            add.style.flexGrow = 1;
            del.style.flexGrow = 1;
            apply.style.flexGrow = 1;
            add.style.flexBasis = new Length(0, LengthUnit.Pixel);
            del.style.flexBasis = new Length(0, LengthUnit.Pixel);
            apply.style.flexBasis = new Length(0, LengthUnit.Pixel);
            add.style.minWidth = 0;
            del.style.minWidth = 0;
            apply.style.minWidth = 0;
            apply.style.marginRight = 0;
            editRow.Add(add);
            editRow.Add(del);
            editRow.Add(apply);
            samplerPage.Add(editRow);
            samplerSelectedMarker = Txt("TAP A PAD TO SELECT ITS MARKER", 10, Accent);
            samplerSelectedMarker.style.whiteSpace = WhiteSpace.Normal;
            samplerSelectedMarker.style.marginTop = 4;
            samplerSelectedMarker.style.marginBottom = 5;
            samplerPage.Add(samplerSelectedMarker);

            // These controls are for fine edits, not song navigation.
            var markerRow = new VisualElement();
            markerRow.style.flexDirection = FlexDirection.Row;
            markerRow.style.height = 43;
            var prev = Btn("< MARK", () => { FindSampler(); samplePlayer?.DawSelectMarker(-1); RefreshSampler(); }, 70);
            var next = Btn("MARK >", () => { FindSampler(); samplePlayer?.DawSelectMarker(1); RefreshSampler(); }, 70);
            var nudgeL = Btn("- 10 MS", () => { FindSampler(); samplePlayer?.DawNudgeSelectedMarker(-1); RefreshSampler(); }, 70);
            var nudgeR = Btn("+ 10 MS", () => { FindSampler(); samplePlayer?.DawNudgeSelectedMarker(1); RefreshSampler(); }, 70);
            foreach (var button in new[] { prev, next, nudgeL, nudgeR })
            {
                button.style.flexGrow = 1;
                button.style.flexBasis = new Length(0, LengthUnit.Pixel);
                button.style.minWidth = 0;
                button.style.paddingLeft = 3;
                button.style.paddingRight = 3;
                button.style.fontSize = 11;
                markerRow.Add(button);
            }
            nudgeR.style.marginRight = 0;
            samplerPage.Add(markerRow);

            var padScroll = new VisualElement();
            padScroll.style.flexDirection = FlexDirection.Column;
            padScroll.style.flexShrink = 0;
            for (int group = 0; group < 4; group++)
            {
                var padRow = new VisualElement();
                padRow.style.flexDirection = FlexDirection.Row;
                padRow.style.height = 68;
                padRow.style.flexShrink = 0;
                for (int j = 0; j < 4; j++)
                {
                    int slice = group * 4 + j + 1;
                    var button = Btn("S" + slice.ToString("00"), () =>
                    {
                        FindSampler();
                        samplePlayer?.DawSelectChopPad(slice);
                        RefreshSampler();
                    }, 44);
                    button.style.flexGrow = 1;
                    button.style.flexShrink = 1;
                    button.style.minWidth = 0;
                    button.style.marginRight = j == 3 ? 0 : 5;
                    button.style.height = 62;
                    button.style.fontSize = 10;
                    button.style.whiteSpace = WhiteSpace.Normal;
                    button.style.backgroundColor = Raised;
                    button.style.position = Position.Relative;
                    var track = new VisualElement();
                    track.pickingMode = PickingMode.Ignore;
                    track.style.position = Position.Absolute;
                    track.style.left = 5;
                    track.style.right = 5;
                    track.style.bottom = 5;
                    track.style.height = 4;
                    track.style.backgroundColor = Surface;
                    var bar = new VisualElement();
                    bar.pickingMode = PickingMode.Ignore;
                    bar.style.position = Position.Absolute;
                    bar.style.top = 0;
                    bar.style.bottom = 0;
                    bar.style.backgroundColor = Accent;
                    bar.style.display = DisplayStyle.None;
                    track.Add(bar);
                    button.Add(track);
                    samplerChopPads.Add(button);
                    samplerChopRangeBars.Add(bar);
                    padRow.Add(button);
                }
                padScroll.Add(padRow);
            }
            samplerPage.Add(padScroll);

            samplerPage.schedule.Execute(() =>
            {
                if (showingSampler) RefreshSampler();
                RefreshClipSampleKeyReference();
                if (generatorPanel != null && generatorPanel.style.display.value == DisplayStyle.Flex && generatorSampleKeyHint != null)
                {
                    RefreshGeneratorKeyGuideControls();
                }
            }).Every(500);
            root.Add(samplerPage);
        }

        // The editor remains usable at a small phone viewport: the generator is a
        // scrollable in-editor sheet instead of another permanent toolbar row.
        private void BuildGeneratorPanel()
        {
            generatorPanel = new VisualElement { name = "ZPunkGenreGenerator" };
            generatorPanel.style.position = Position.Absolute;
            generatorPanel.style.left = 0;
            generatorPanel.style.right = 0;
            generatorPanel.style.top = 0;
            generatorPanel.style.bottom = 0;
            generatorPanel.style.backgroundColor = new Color(.055f,.078f,.116f,.99f);
            generatorPanel.style.display = DisplayStyle.None;
            generatorPanel.style.paddingTop = 6;
            generatorPanel.style.paddingLeft = 8;
            generatorPanel.style.paddingRight = 8;
            var body = new ScrollView(ScrollViewMode.Vertical);
            body.style.flexGrow = 1;
            body.style.minHeight = 0;
            body.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            body.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            body.contentContainer.style.paddingBottom = 14;
            acidGeneratorScroll = body;
            body.verticalScroller.valueChanged += _ => SyncAcidKnobTouchTargets();
            body.RegisterCallback<GeometryChangedEvent>(_ => SyncAcidKnobTouchTargets());
            generatorPanel.RegisterCallback<GeometryChangedEvent>(_ => SyncAcidKnobTouchTargets());
            generatorPanel.Add(body);

            // Keep the hit targets OUTSIDE of the ScrollView's event hierarchy.
            // The layer itself is unpickable; only the three knob-sized targets
            // receive touches, leaving every other part of the sheet scrollable.
            acidKnobTouchLayer = new VisualElement { name = "ZPunkAcidKnobTouchOverlay" };
            acidKnobTouchLayer.style.position = Position.Absolute;
            acidKnobTouchLayer.style.left = 0;
            acidKnobTouchLayer.style.right = 0;
            acidKnobTouchLayer.style.top = 0;
            acidKnobTouchLayer.style.bottom = 0;
            acidKnobTouchLayer.pickingMode = PickingMode.Ignore;
            acidKnobTouchLayer.style.display = DisplayStyle.None;
            generatorPanel.Add(acidKnobTouchLayer);

            generatorHeading = Txt("GENERATE / DRUMS",16,Ink);
            generatorHeading.style.unityFontStyleAndWeight = FontStyle.Bold;
            generatorHeading.style.marginTop = 4;
            body.Add(generatorHeading);
            generatorHint = Txt("Select the sound before writing notes to your clip.",11,Muted);
            generatorHint.style.whiteSpace = WhiteSpace.Normal;
            generatorHint.style.marginTop = 4;
            generatorHint.style.marginBottom = 8;
            body.Add(generatorHint);

            body.Add(Txt("GENRE",11,Muted));
            var genresScroll = new ScrollView(ScrollViewMode.Horizontal);
            genresScroll.style.height = 52;
            genresScroll.style.flexShrink = 0;
            genresScroll.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            genresScroll.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            generatorGenres = genresScroll.contentContainer;
            generatorGenres.style.flexDirection = FlexDirection.Row;
            body.Add(genresScroll);

            body.Add(Txt("STYLE",11,Muted));
            var stylesScroll = new ScrollView(ScrollViewMode.Horizontal);
            stylesScroll.style.height = 52;
            stylesScroll.style.flexShrink = 0;
            stylesScroll.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            stylesScroll.verticalScrollerVisibility = ScrollerVisibility.Hidden;
            generatorStyles = stylesScroll.contentContainer;
            generatorStyles.style.flexDirection = FlexDirection.Row;
            body.Add(stylesScroll);

            // SYNTH alone can generate either a melody or scale-aware chord
            // progressions. Keep this inside the scrolling sheet for small phones.
            generatorSynthModeRow = new VisualElement();
            generatorSynthModeRow.style.flexDirection = FlexDirection.Column;
            var synthModeLabel = Txt("SYNTH / GENERATION TYPE",11,Muted);
            synthModeLabel.style.marginTop = 5;
            generatorSynthModeRow.Add(synthModeLabel);
            var synthModeButtons = new VisualElement();
            synthModeButtons.style.flexDirection = FlexDirection.Row;
            synthModeButtons.style.height = 48;
            synthModeButtons.style.alignItems = Align.Center;
            generatorMelodyButton = Btn("MELODY", () => { generatorSynthChords = false; RefreshGeneratorPanel(); }, 90);
            generatorChordsButton = Btn("CHORDS", () => { generatorSynthChords = true; RefreshGeneratorPanel(); }, 90);
            generatorMelodyButton.style.flexGrow = 1;
            generatorChordsButton.style.flexGrow = 1;
            synthModeButtons.Add(generatorMelodyButton);
            synthModeButtons.Add(generatorChordsButton);
            generatorSynthModeRow.Add(synthModeButtons);
            body.Add(generatorSynthModeRow);

            generatorSummary = Txt("",12,Accent);
            generatorSummary.style.whiteSpace = WhiteSpace.Normal;
            generatorSummary.style.marginTop = 8;
            generatorSummary.style.marginBottom = 8;
            body.Add(generatorSummary);

            body.Add(Txt("KEY / SHARED BY BASS, SYNTH AND PADS",10,Muted));
            var keyRow = new VisualElement();
            keyRow.style.height = 48;
            keyRow.style.flexDirection = FlexDirection.Row;
            keyRow.style.alignItems = Align.Center;
            keyRow.Add(Btn("<",() => { generatorKey = (generatorKey + 11)%12; SaveSharedHarmonicSelection(); RefreshGeneratorPanel(); },43));
            generatorKeyLabel = Txt("A MIN",13,Accent);
            generatorKeyLabel.style.flexGrow = 1;
            generatorKeyLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
            keyRow.Add(generatorKeyLabel);
            keyRow.Add(Btn(">",() => { generatorKey = (generatorKey + 1)%12; SaveSharedHarmonicSelection(); RefreshGeneratorPanel(); },43));
            keyRow.Add(Btn("MIN/MAJ",() => { generatorMinor = !generatorMinor; SaveSharedHarmonicSelection(); RefreshGeneratorPanel(); },85));
            body.Add(keyRow);

            // Shared project-level harmonic direction, independent of the selected
            // Bass / Synth / Pads track and independent of NEW VARIATION.
            generatorProgressionSection = new VisualElement();
            generatorProgressionSection.style.flexDirection = FlexDirection.Column;
            var progressionHeading = Txt("PROGRESSION / SHARED BY BASS, SYNTH AND PADS", 10, Muted);
            progressionHeading.style.marginTop = 8;
            generatorProgressionSection.Add(progressionHeading);
            var progressionRow = new VisualElement();
            progressionRow.style.height = 48;
            progressionRow.style.flexDirection = FlexDirection.Row;
            progressionRow.style.alignItems = Align.Center;
            progressionRow.Add(Btn("<", () => StepSharedProgression(-1), 43));
            generatorProgressionLabel = Txt("GENRE DEFAULT", 11, Accent);
            generatorProgressionLabel.style.flexGrow = 1;
            generatorProgressionLabel.style.minWidth = 0;
            generatorProgressionLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
            progressionRow.Add(generatorProgressionLabel);
            progressionRow.Add(Btn(">", () => StepSharedProgression(1), 43));
            generatorProgressionSection.Add(progressionRow);
            generatorProgressionChords = Txt("", 11, Ink);
            generatorProgressionChords.style.whiteSpace = WhiteSpace.Normal;
            generatorProgressionChords.style.unityTextAlign = TextAnchor.MiddleCenter;
            generatorProgressionChords.style.marginBottom = 6;
            generatorProgressionSection.Add(generatorProgressionChords);
            var progressionHelp = Txt("Changes future generations; existing clips are kept until regenerated.", 10, Muted);
            progressionHelp.style.whiteSpace = WhiteSpace.Normal;
            progressionHelp.style.marginBottom = 4;
            generatorProgressionSection.Add(progressionHelp);
            body.Add(generatorProgressionSection);

            // Explicit opt-in: guide the piano roll using the current key, or
            // adopt a detected sample key when one is available. Neither option
            // changes existing MIDI notes.
            var sampleKeyRow = new VisualElement();
            sampleKeyRow.style.flexDirection = FlexDirection.Row;
            sampleKeyRow.style.alignItems = Align.Center;
            sampleKeyRow.style.minHeight = 46;
            sampleKeyRow.style.marginTop = 4;
            generatorSampleKeyButton = Btn("USE SAMPLE KEY", () =>
            {
                FindSampler();
                if (sampleKeyGuideEnabled)
                {
                    // Reset every MIDI row to the original alternating keyboard
                    // colors. Do not alter the generator's selected key or notes.
                    sampleKeyGuideEnabled = false;
                    sampleKeyGuideFromSample = false;
                    sampleKeyGuideSampleId = null;
                    ApplySampleKeyGuide();
                    RefreshClipSampleKeyReference();
                    RefreshGeneratorPanel();
                    return;
                }
                bool hasSampleKey = samplePlayer != null && samplePlayer.DawSampleKeyAvailable;
                if (hasSampleKey)
                {
                    // Keep the original opt-in behavior: sample pitch and mode
                    // become the shared harmonic selection for future generations.
                    generatorKey = samplePlayer.DawPitchedKeyTonic;
                    generatorMinor = samplePlayer.DawSampleKeyMinor;
                    SaveSharedHarmonicSelection();
                }
                // Without a detected sample, highlight the manually selected key.
                // The guide never inserts, deletes or transposes any MIDI notes.
                sampleKeyGuideEnabled = true;
                sampleKeyGuideFromSample = hasSampleKey;
                sampleKeyGuideTonic = generatorKey;
                sampleKeyGuideMinor = generatorMinor;
                sampleKeyGuideProjectSlot = projects != null ? projects.CurrentSlot : -1;
                sampleKeyGuideSampleId = hasSampleKey
                    ? samplePlayer.DawSampleFolder + "/" + samplePlayer.DawSampleName : null;
                ApplySampleKeyGuide();
                RefreshClipSampleKeyReference();
                RefreshGeneratorPanel();
            }, 132);
            generatorSampleKeyButton.style.height = 42;
            generatorSampleKeyButton.style.flexShrink = 0;
            sampleKeyRow.Add(generatorSampleKeyButton);
            generatorSampleKeyHint = Txt("NO SAMPLE KEY", 11, Muted);
            generatorSampleKeyHint.style.flexGrow = 1;
            generatorSampleKeyHint.style.minWidth = 0;
            generatorSampleKeyHint.style.whiteSpace = WhiteSpace.Normal;
            generatorSampleKeyHint.style.marginLeft = 9;
            sampleKeyRow.Add(generatorSampleKeyHint);
            body.Add(sampleKeyRow);

            body.Add(Txt("LENGTH",10,Muted));
            generatorBarsRow = new VisualElement();
            generatorBarsRow.style.flexDirection = FlexDirection.Row;
            generatorBarsRow.style.height = 48;
            body.Add(generatorBarsRow);

            var variationRow = new VisualElement();
            variationRow.style.flexDirection = FlexDirection.Row;
            variationRow.style.alignItems = Align.Center;
            variationRow.style.height = 48;
            generatorVariationLabel = Txt("VARIATION 1",11,Muted);
            generatorVariationLabel.style.flexGrow = 1;
            variationRow.Add(generatorVariationLabel);
            variationRow.Add(Btn("NEW VARIATION",() => { generatorVariation++; RefreshGeneratorPanel(); },118));
            body.Add(variationRow);

            // Persistent history is scoped to the selected project, instrument, genre
            // and melodic/chord mode. It lives within the sheet's existing scroll area.
            generatorHistoryLabel = Txt("PREVIOUS GENERATIONS",11,Muted);
            generatorHistoryLabel.style.marginTop = 12;
            generatorHistoryLabel.style.marginBottom = 5;
            body.Add(generatorHistoryLabel);
            var past = new ScrollView(ScrollViewMode.Vertical);
            generatorHistoryRows = past.contentContainer;
            generatorHistoryRows.style.paddingRight = 1;
            // Share the same complete-height, draggable scrollbar as Project Library
            // and Browse Samples. No native white UI Toolkit arrow controls.
            var historyHost = ZPunkOverlaySkin.ScrollWithRail(past);
            historyHost.style.height = 184;
            historyHost.style.flexGrow = 0;
            historyHost.style.flexShrink = 0;
            historyHost.style.marginBottom = 7;
            body.Add(historyHost);

            // A second, independent generator body. Genre/history controls
            // remain unchanged for the other five instruments.
            normalGeneratorSections = new VisualElement();
            var normalChildren = new List<VisualElement>();
            // Heading and warning stay visible for both generator modes.
            foreach (var element in body.contentContainer.Children())
                if (element != generatorHeading && element != generatorHint) normalChildren.Add(element);
            foreach (var element in normalChildren) normalGeneratorSections.Add(element);
            body.Add(normalGeneratorSections);
            acidGeneratorSections = BuildAcidGeneratorControls();
            body.Add(acidGeneratorSections);

            var actionRow = new VisualElement();
            actionRow.style.flexDirection = FlexDirection.Row;
            actionRow.style.height = 52;
            actionRow.style.flexShrink = 0;
            generatorCancelButton = Btn("CANCEL",CloseGenerator,78);
            generatorCancelButton.style.flexGrow = 1;
            actionRow.Add(generatorCancelButton);
            acidLiveButton = Btn("LIVE ON", () =>
            {
                acidLiveEnabled = !acidLiveEnabled;
                if (!acidLiveEnabled && acidLiveUpdate != null) acidLiveUpdate.Pause();
                if (acidLiveEnabled && acidUnappliedChanges) QueueAcidLiveUpdate();
                RefreshAcidGeneratorPanel();
            }, 76);
            acidLiveButton.style.display = DisplayStyle.None;
            acidLiveButton.tooltip = "After APPLY, changes automatically rewrite the ACID clip";
            actionRow.Add(acidLiveButton);
            generatorApplyButton = Btn("GENERATE",ApplyGenerator,109);
            generatorApplyButton.style.backgroundColor = new Color(.12f,.36f,.34f);
            generatorApplyButton.style.color = Accent;
            generatorApplyButton.style.flexGrow = 1;
            actionRow.Add(generatorApplyButton);
            // Keep cancel/apply visible even on short phone displays.
            actionRow.style.paddingTop = 2;
            generatorPanel.Add(actionRow);
            root.Add(generatorPanel);
        }

        // Instrument-like ACID pattern designer. No horizontally scrolling rows
        // of configuration buttons: use compact selectors, touch sliders and knobs.
        private VisualElement BuildAcidGeneratorControls()
        {
            acidControlPainters.Clear();
            acidKnobFaces.Clear();
            acidKnobHitTargets.Clear();
            if (acidKnobTouchLayer != null) acidKnobTouchLayer.Clear();
            var panel = new VisualElement { name = "ZPunkAcid303GeneratorControls" };
            panel.style.flexDirection = FlexDirection.Column;
            panel.style.paddingBottom = 5;

            var subtitle = Txt("303 / PATTERN LAB", 13, Accent);
            subtitle.style.unityFontStyleAndWeight = FontStyle.Bold;
            subtitle.style.marginBottom = 5;
            panel.Add(subtitle);
            var instruction = Txt("Choose a phrase, shape its movement, then APPLY. LIVE ON updates the clip as you adjust.", 11, Muted);
            instruction.style.whiteSpace = WhiteSpace.Normal;
            instruction.style.marginBottom = 10;
            panel.Add(instruction);

            AddAcidSectionTitle(panel, "TONALITY");
            var tonicRow = new VisualElement();
            tonicRow.style.flexDirection = FlexDirection.Row;
            tonicRow.style.alignItems = Align.Center;
            tonicRow.style.height = 48;
            tonicRow.Add(Btn("<", () => ChangeAcidSetting(() => acidSettings.key = (acidSettings.key + 11) % 12), 44));
            acidKeyLabel = Txt("A / MINOR", 14, Accent);
            acidKeyLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
            acidKeyLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            acidKeyLabel.style.flexGrow = 1;
            tonicRow.Add(acidKeyLabel);
            tonicRow.Add(Btn(">", () => ChangeAcidSetting(() => acidSettings.key = (acidSettings.key + 1) % 12), 44));
            panel.Add(tonicRow);
            var useSongKey = Btn("USE SONG KEY", () =>
            {
                if (song == null) return;
                ChangeAcidSetting(() =>
                {
                    acidSettings.key = Mathf.Clamp(song.sharedProgressionKey, 0, 11);
                    int newScale = song.sharedProgressionMinor ? 0 : 1;
                    if (acidSettings.scale != newScale)
                    {
                        acidSettings.scale = newScale;
                        acidSettings.noteMask = -1;
                    }
                });
            }, 136);
            useSongKey.style.height = 36;
            useSongKey.style.marginBottom = 5;
            panel.Add(useSongKey);
            AddAcidCycler(panel, "SCALE", ZPunkAcidPatternGenerator.Scales,
                () => acidSettings.scale, value =>
                {
                    if (acidSettings.scale != value)
                    {
                        acidSettings.scale = value;
                        acidSettings.noteMask = -1; // All notes of the new scale start active.
                    }
                });
            AddAcidNotePool(panel);
            AddAcidCycler(panel, "ROOT OCTAVE", new[] { "C1", "C2", "C3", "C4" },
                () => acidSettings.octave - 1, value => acidSettings.octave = value + 1);
            AddAcidCycler(panel, "OCTAVE SPAN", new[] { "1 OCT", "2 OCT", "3 OCT" },
                () => acidSettings.range, value => acidSettings.range = value);

            AddAcidSectionTitle(panel, "SEQUENCE");
            AddAcidCycler(panel, "PHRASE", ZPunkAcidPatternGenerator.Motifs,
                () => acidSettings.motif, value => acidSettings.motif = value);
            AddAcidCycler(panel, "GROOVE", ZPunkAcidPatternGenerator.Syncopations,
                () => acidSettings.syncopation, value => acidSettings.syncopation = value);
            AddAcidSegments(panel, "BARS", new[] { "1", "2", "4", "8", "16" },
                () => acidSettings.bars, value => acidSettings.bars = value);
            AddAcidSegments(panel, "STEP GRID", ZPunkAcidPatternGenerator.Divisions,
                () => acidSettings.division, value => acidSettings.division = value);

            AddAcidSectionTitle(panel, "RHYTHM / FEEL");
            AddAcidSlider(panel, "NOTE DENSITY", new[] { "30%", "45%", "60%", "75%", "90%" },
                () => acidSettings.density, value => acidSettings.density = value);
            AddAcidSlider(panel, "SWING", new[] { "OFF", "15%", "30%", "45%" },
                () => acidSettings.swing, value => acidSettings.swing = value);
            AddAcidSegments(panel, "GATE", ZPunkAcidPatternGenerator.Gates,
                () => acidSettings.gate, value => acidSettings.gate = value);

            AddAcidSectionTitle(panel, "303 CHARACTER");
            var knobs = new VisualElement();
            knobs.style.flexDirection = FlexDirection.Row;
            knobs.style.alignItems = Align.Center;
            knobs.style.justifyContent = Justify.SpaceBetween;
            AddAcidKnob(knobs, "ACCENT", new[] { "OFF", "20%", "35%", "50%", "70%" },
                () => acidSettings.accent, value => acidSettings.accent = value);
            AddAcidKnob(knobs, "SLIDE", new[] { "OFF", "15%", "30%", "45%", "60%" },
                () => acidSettings.slide, value => acidSettings.slide = value);
            AddAcidKnob(knobs, "LEAPS", new[] { "OFF", "15%", "30%", "50%" },
                () => acidSettings.leap, value => acidSettings.leap = value);
            panel.Add(knobs);

            var variation = new VisualElement();
            variation.style.flexDirection = FlexDirection.Row;
            variation.style.alignItems = Align.Center;
            variation.style.height = 49;
            var variationLabel = Txt("PATTERN VARIATION", 11, Muted);
            variationLabel.style.flexGrow = 1;
            variation.Add(variationLabel);
            variation.Add(Btn("NEW SEED", () => ChangeAcidSetting(() => acidSettings.variation++), 107));
            panel.Add(variation);

            AddAcidSectionTitle(panel, "STEP ACTIVITY / FIRST BAR");
            acidPatternPreview = new VisualElement();
            acidPatternPreview.style.flexDirection = FlexDirection.Row;
            acidPatternPreview.style.height = 26;
            acidPatternPreview.style.marginTop = 5;
            acidPatternPreview.style.marginBottom = 5;
            for (int i = 0; i < 16; ++i)
            {
                var cell = new VisualElement();
                cell.style.flexGrow = 1;
                cell.style.flexBasis = new Length(0, LengthUnit.Pixel);
                cell.style.height = 19;
                cell.style.marginRight = 2;
                cell.style.backgroundColor = Raised;
                cell.style.borderTopLeftRadius = 3;
                cell.style.borderTopRightRadius = 3;
                cell.style.borderBottomLeftRadius = 3;
                cell.style.borderBottomRightRadius = 3;
                cell.pickingMode = PickingMode.Ignore;
                acidPatternPreview.Add(cell);
            }
            panel.Add(acidPatternPreview);
            var legend = Txt("HIT = GREEN   /   ACCENT = ORANGE   /   SLIDE = BLUE", 9, Muted);
            legend.style.whiteSpace = WhiteSpace.Normal;
            panel.Add(legend);
            acidLiveStatus = Txt("APPLY A PATTERN TO START LIVE EDITING", 11, Accent);
            acidLiveStatus.style.whiteSpace = WhiteSpace.Normal;
            acidLiveStatus.style.marginTop = 10;
            panel.Add(acidLiveStatus);
            acidGeneratorSummary = Txt("", 10, Muted);
            acidGeneratorSummary.style.whiteSpace = WhiteSpace.Normal;
            acidGeneratorSummary.style.marginTop = 4;
            acidGeneratorSummary.style.marginBottom = 9;
            panel.Add(acidGeneratorSummary);
            return panel;
        }

        // Select the actual pitches permitted by the active scale, without a
        // long row of toggles or a horizontally scrolling keyboard. Chromatic
        // mode uses three rows of four buttons on narrow portrait phones.
        private void AddAcidNotePool(VisualElement panel)
        {
            var header = new VisualElement();
            header.style.flexDirection = FlexDirection.Row;
            header.style.alignItems = Align.Center;
            header.style.justifyContent = Justify.SpaceBetween;
            header.style.marginTop = 11;
            header.style.marginBottom = 3;
            var titleLabel = Txt("ALLOWED NOTES", 10, Accent);
            titleLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            header.Add(titleLabel);
            var countLabel = Txt("", 10, Muted);
            countLabel.style.flexGrow = 1;
            countLabel.style.unityTextAlign = TextAnchor.MiddleRight;
            countLabel.style.marginRight = 9;
            header.Add(countLabel);
            var allButton = Btn("ALL", () =>
            {
                int count = ZPunkAcidPatternGenerator.DegreeCount(acidSettings.scale);
                if (ZPunkAcidPatternGenerator.EnabledDegreeCount(acidSettings) == count) return;
                ChangeAcidSetting(() => acidSettings.noteMask = -1);
            }, 48);
            allButton.style.height = 32;
            allButton.style.marginRight = 0;
            allButton.style.fontSize = 11;
            header.Add(allButton);
            panel.Add(header);

            var notes = new VisualElement();
            notes.style.flexDirection = FlexDirection.Row;
            notes.style.flexWrap = Wrap.Wrap;
            notes.style.justifyContent = Justify.SpaceBetween;
            notes.style.marginBottom = 4;
            var buttons = new Button[12];
            for (int i = 0; i < buttons.Length; i++)
            {
                int degree = i;
                var button = Btn("", () =>
                {
                    // Prevent empty patterns; all other changes flow through
                    // the existing debounced Live Apply path.
                    if (ZPunkAcidPatternGenerator.DegreeEnabled(acidSettings, degree) &&
                        ZPunkAcidPatternGenerator.EnabledDegreeCount(acidSettings) <= 1) return;
                    ChangeAcidSetting(() => ZPunkAcidPatternGenerator.ToggleDegree(acidSettings, degree));
                }, 0);
                button.style.width = new Length(23, LengthUnit.Percent);
                button.style.minWidth = 0;
                button.style.flexShrink = 0;
                button.style.height = 37;
                button.style.marginRight = 0;
                button.style.marginBottom = 5;
                button.style.paddingLeft = 1;
                button.style.paddingRight = 1;
                button.style.fontSize = 12;
                button.tooltip = "Include or exclude this note from generated ACID patterns";
                buttons[i] = button;
                notes.Add(button);
            }
            panel.Add(notes);
            var hint = Txt("TAP NOTES TO EXCLUDE THEM FROM GENERATION", 10, Muted);
            hint.style.whiteSpace = WhiteSpace.Normal;
            panel.Add(hint);
            acidControlPainters.Add(() =>
            {
                int count = ZPunkAcidPatternGenerator.DegreeCount(acidSettings.scale);
                int enabled = ZPunkAcidPatternGenerator.EnabledDegreeCount(acidSettings);
                countLabel.text = enabled + " / " + count + " SELECTED";
                allButton.style.color = enabled == count ? Accent : Ink;
                for (int i = 0; i < buttons.Length; i++)
                {
                    bool inScale = i < count;
                    buttons[i].style.display = inScale ? DisplayStyle.Flex : DisplayStyle.None;
                    if (!inScale) continue;
                    bool selected = ZPunkAcidPatternGenerator.DegreeEnabled(acidSettings, i);
                    buttons[i].text = ZPunkAcidPatternGenerator.DegreeName(
                        acidSettings.key, acidSettings.scale, i);
                    buttons[i].style.backgroundColor = selected ? SelectedColor() : Raised;
                    buttons[i].style.color = selected ? Accent : Muted;
                    buttons[i].style.opacity = selected ? 1f : .63f;
                }
            });
        }

        private void AddAcidSectionTitle(VisualElement panel, string name)
        {
            var titleLabel = Txt(name, 10, Accent);
            titleLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLabel.style.marginTop = 13;
            titleLabel.style.marginBottom = 4;
            panel.Add(titleLabel);
        }

        private void AddAcidCycler(VisualElement panel, string name, string[] names,
            Func<int> get, Action<int> set)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.height = 47;
            var titleLabel = Txt(name, 11, Muted);
            titleLabel.style.width = Length.Percent(35);
            titleLabel.style.flexShrink = 0;
            row.Add(titleLabel);
            row.Add(Btn("<", () => ChangeAcidSetting(() => set((get() + names.Length - 1) % names.Length)), 37));
            var value = Txt("", 12, Ink);
            value.style.flexGrow = 1;
            value.style.minWidth = 0;
            value.style.unityTextAlign = TextAnchor.MiddleCenter;
            value.style.unityFontStyleAndWeight = FontStyle.Bold;
            row.Add(value);
            row.Add(Btn(">", () => ChangeAcidSetting(() => set((get() + 1) % names.Length)), 37));
            acidControlPainters.Add(() => value.text = names[Mathf.Clamp(get(), 0, names.Length - 1)]);
            panel.Add(row);
        }

        private void AddAcidSegments(VisualElement panel, string name, string[] names,
            Func<int> get, Action<int> set)
        {
            var label = Txt(name, 10, Muted);
            label.style.marginTop = 7;
            panel.Add(label);
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.height = 43;
            var buttons = new Button[names.Length];
            for (int i = 0; i < names.Length; ++i)
            {
                int index = i;
                var button = Btn(names[i], () => ChangeAcidSetting(() => set(index)), 0);
                button.style.flexGrow = 1;
                button.style.flexShrink = 1;
                button.style.flexBasis = new Length(0, LengthUnit.Pixel);
                button.style.minWidth = 0;
                button.style.marginLeft = 2;
                button.style.marginRight = 2;
                button.style.paddingLeft = 2;
                button.style.paddingRight = 2;
                button.style.fontSize = 11;
                buttons[i] = button;
                row.Add(button);
            }
            acidControlPainters.Add(() =>
            {
                int selected = Mathf.Clamp(get(), 0, names.Length - 1);
                for (int i = 0; i < buttons.Length; ++i)
                {
                    buttons[i].style.backgroundColor = i == selected ? SelectedColor() : Raised;
                    buttons[i].style.color = i == selected ? Accent : Ink;
                }
            });
            panel.Add(row);
        }

        private void AddAcidSlider(VisualElement panel, string name, string[] names,
            Func<int> get, Action<int> set)
        {
            var heading = new VisualElement();
            heading.style.flexDirection = FlexDirection.Row;
            heading.style.justifyContent = Justify.SpaceBetween;
            heading.style.alignItems = Align.Center;
            heading.style.marginTop = 7;
            heading.Add(Txt(name, 10, Muted));
            var value = Txt("", 12, Accent);
            value.style.unityFontStyleAndWeight = FontStyle.Bold;
            heading.Add(value);
            panel.Add(heading);

            var rail = new VisualElement { name = "ZPunkAcidSlider" + name.Replace(" ", "") };
            rail.style.height = 33;
            rail.style.position = Position.Relative;
            rail.style.flexShrink = 0;
            rail.pickingMode = PickingMode.Position;
            var track = new VisualElement();
            track.style.position = Position.Absolute;
            track.style.left = 10;
            track.style.right = 10;
            track.style.top = 13;
            track.style.height = 7;
            track.style.backgroundColor = Raised;
            track.style.borderTopLeftRadius = 4;
            track.style.borderTopRightRadius = 4;
            track.style.borderBottomLeftRadius = 4;
            track.style.borderBottomRightRadius = 4;
            track.pickingMode = PickingMode.Ignore;
            rail.Add(track);
            var fill = new VisualElement();
            fill.style.height = 7;
            fill.style.backgroundColor = Accent;
            fill.style.borderTopLeftRadius = 4;
            fill.style.borderBottomLeftRadius = 4;
            fill.pickingMode = PickingMode.Ignore;
            track.Add(fill);
            var thumb = new VisualElement();
            thumb.style.position = Position.Absolute;
            thumb.style.top = -5;
            thumb.style.marginLeft = -8;
            thumb.style.width = 17;
            thumb.style.height = 17;
            thumb.style.backgroundColor = Ink;
            thumb.style.borderTopLeftRadius = 9;
            thumb.style.borderTopRightRadius = 9;
            thumb.style.borderBottomLeftRadius = 9;
            thumb.style.borderBottomRightRadius = 9;
            thumb.pickingMode = PickingMode.Ignore;
            track.Add(thumb);
            acidControlPainters.Add(() =>
            {
                int selected = Mathf.Clamp(get(), 0, names.Length - 1);
                float percent = selected * 100f / Mathf.Max(1, names.Length - 1);
                fill.style.width = Length.Percent(percent);
                thumb.style.left = Length.Percent(percent);
                value.text = names[selected];
            });
            int pointerId = -1;
            Action<float> changeFromX = x =>
            {
                float usable = Mathf.Max(1f, rail.worldBound.width - 20f);
                float normalized = Mathf.Clamp01((x - rail.worldBound.xMin - 10f) / usable);
                int step = Mathf.RoundToInt(normalized * (names.Length - 1));
                if (step != get()) ChangeAcidSetting(() => set(step));
            };
            rail.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || pointerId >= 0) return;
                pointerId = evt.pointerId;
                rail.CapturePointer(evt.pointerId);
                changeFromX(evt.position.x);
                evt.StopPropagation();
            });
            rail.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                changeFromX(evt.position.x);
                evt.StopPropagation();
            });
            rail.RegisterCallback<PointerUpEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                changeFromX(evt.position.x);
                pointerId = -1;
                if (rail.HasPointerCapture(evt.pointerId)) rail.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            rail.RegisterCallback<PointerCancelEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                pointerId = -1;
                if (rail.HasPointerCapture(evt.pointerId)) rail.ReleasePointer(evt.pointerId);
            });
            rail.RegisterCallback<PointerCaptureOutEvent>(evt => { if (pointerId == evt.pointerId) pointerId = -1; });
            panel.Add(rail);
        }

        // Map each visible face to a transparent pointer target outside the
        // scroll hierarchy. Clip the hit rectangles to the visible viewport so
        // off-screen knobs cannot intercept unrelated buttons or gestures.
        private void SyncAcidKnobTouchTargets()
        {
            if (acidKnobTouchLayer == null || acidGeneratorScroll == null ||
                generatorPanel == null || acidGeneratorSections == null) return;
            bool active = generatorPanel.style.display.value == DisplayStyle.Flex &&
                acidGeneratorSections.style.display.value == DisplayStyle.Flex;
            acidKnobTouchLayer.style.display = active ? DisplayStyle.Flex : DisplayStyle.None;
            if (!active) return;

            Rect viewport = acidGeneratorScroll.contentViewport.worldBound;
            Rect overlay = acidKnobTouchLayer.worldBound;
            for (int i = 0; i < acidKnobFaces.Count && i < acidKnobHitTargets.Count; i++)
            {
                VisualElement face = acidKnobFaces[i];
                VisualElement hit = acidKnobHitTargets[i];
                Rect bounds = face.worldBound;
                float left = Mathf.Max(bounds.xMin, viewport.xMin);
                float top = Mathf.Max(bounds.yMin, viewport.yMin);
                float right = Mathf.Min(bounds.xMax, viewport.xMax);
                float bottom = Mathf.Min(bounds.yMax, viewport.yMax);
                if (right - left < 2f || bottom - top < 2f)
                {
                    // Never hide an actively captured hit target mid-gesture.
                    if (hit != acidActiveKnobTarget) hit.style.display = DisplayStyle.None;
                    continue;
                }
                hit.style.display = DisplayStyle.Flex;
                // Do not move a hit target while it owns the pointer: pointer
                // capture must stay stable even if the viewport relayouts.
                if (hit == acidActiveKnobTarget) continue;
                hit.style.left = left - overlay.xMin;
                hit.style.top = top - overlay.yMin;
                hit.style.width = right - left;
                hit.style.height = bottom - top;
            }
        }

        private bool BeginAcidKnobGesture(VisualElement hit, int pointerId)
        {
            if (acidKnobPointerId >= 0) return false;
            acidKnobPointerId = pointerId;
            acidActiveKnobTarget = hit;
            return true;
        }

        private void EndAcidKnobGesture(int pointerId)
        {
            if (acidKnobPointerId != pointerId) return;
            acidKnobPointerId = -1;
            acidActiveKnobTarget = null;
            SyncAcidKnobTouchTargets();
        }

        private void CancelAcidKnobGesture()
        {
            VisualElement active = acidActiveKnobTarget;
            int pointer = acidKnobPointerId;
            acidKnobPointerId = -1;
            acidActiveKnobTarget = null;
            if (active != null && pointer >= 0 && active.HasPointerCapture(pointer))
                active.ReleasePointer(pointer);
            SyncAcidKnobTouchTargets();
        }

        private void AddAcidKnob(VisualElement row, string name, string[] names,
            Func<int> get, Action<int> set)
        {
            var tile = new VisualElement();
            tile.style.width = Length.Percent(33.3333f);
            tile.style.minWidth = 0;
            tile.style.height = 112;
            tile.style.alignItems = Align.Center;
            tile.style.justifyContent = Justify.Center;
            var face = new VisualElement { name = "ZPunkAcidKnob" + name };
            face.style.width = 64;
            face.style.height = 64;
            face.style.position = Position.Relative;
            face.style.backgroundColor = Raised;
            face.style.borderTopLeftRadius = 32;
            face.style.borderTopRightRadius = 32;
            face.style.borderBottomLeftRadius = 32;
            face.style.borderBottomRightRadius = 32;
            face.style.borderLeftWidth = 2;
            face.style.borderRightWidth = 2;
            face.style.borderTopWidth = 2;
            face.style.borderBottomWidth = 2;
            face.style.borderLeftColor = Accent;
            face.style.borderRightColor = Accent;
            face.style.borderTopColor = Accent;
            face.style.borderBottomColor = Accent;
            face.style.justifyContent = Justify.Center;
            face.style.alignItems = Align.Center;
            // Only the detached overlay hit target is pickable; these visuals
            // cannot pass a touch to the ScrollView's pan manipulator.
            face.pickingMode = PickingMode.Ignore;
            var readout = Txt("", 12, Ink);
            readout.style.unityTextAlign = TextAnchor.MiddleCenter;
            readout.style.unityFontStyleAndWeight = FontStyle.Bold;
            readout.pickingMode = PickingMode.Ignore;
            face.Add(readout);
            var marker = new VisualElement();
            marker.style.position = Position.Absolute;
            marker.style.width = 6;
            marker.style.height = 6;
            marker.style.backgroundColor = Accent;
            marker.style.borderTopLeftRadius = 3;
            marker.style.borderTopRightRadius = 3;
            marker.style.borderBottomLeftRadius = 3;
            marker.style.borderBottomRightRadius = 3;
            marker.pickingMode = PickingMode.Ignore;
            face.Add(marker);
            var hit = new VisualElement { name = "ZPunkAcidKnobTouch" + name };
            hit.style.position = Position.Absolute;
            hit.pickingMode = PickingMode.Position;
            hit.style.display = DisplayStyle.None;
            acidKnobFaces.Add(face);
            acidKnobHitTargets.Add(hit);
            if (acidKnobTouchLayer != null) acidKnobTouchLayer.Add(hit);
            face.RegisterCallback<GeometryChangedEvent>(_ => SyncAcidKnobTouchTargets());
            acidControlPainters.Add(() =>
            {
                int selected = Mathf.Clamp(get(), 0, names.Length - 1);
                float fraction = selected / (float)Mathf.Max(1, names.Length - 1);
                float theta = (-225f + 270f * fraction) * Mathf.Deg2Rad;
                marker.style.left = 29f + Mathf.Cos(theta) * 23f;
                marker.style.top = 29f + Mathf.Sin(theta) * 23f;
                readout.text = names[selected];
            });
            int pointerId = -1, startStep = 0;
            float downY = 0;
            bool moved = false;
            hit.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || pointerId >= 0) return;
                if (!BeginAcidKnobGesture(hit, evt.pointerId)) return;
                pointerId = evt.pointerId;
                downY = evt.position.y;
                startStep = get();
                moved = false;
                hit.CapturePointer(evt.pointerId);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                float distance = downY - evt.position.y;
                if (Mathf.Abs(distance) >= 5f) moved = true;
                int candidate = Mathf.Clamp(startStep + Mathf.RoundToInt(distance / 16f), 0, names.Length - 1);
                if (moved && candidate != get()) ChangeAcidSetting(() => set(candidate));
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerUpEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                if (!moved)
                {
                    int direction = evt.position.x < face.worldBound.center.x ? -1 : 1;
                    int candidate = Mathf.Clamp(get() + direction, 0, names.Length - 1);
                    if (candidate != get()) ChangeAcidSetting(() => set(candidate));
                }
                EndAcidKnobGesture(evt.pointerId);
                pointerId = -1;
                if (hit.HasPointerCapture(evt.pointerId)) hit.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerCancelEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                EndAcidKnobGesture(evt.pointerId);
                pointerId = -1;
                if (hit.HasPointerCapture(evt.pointerId)) hit.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerCaptureOutEvent>(evt =>
            {
                if (pointerId != evt.pointerId) return;
                EndAcidKnobGesture(evt.pointerId);
                pointerId = -1;
            });
            hit.RegisterCallback<DetachFromPanelEvent>(evt =>
            {
                if (pointerId < 0) return;
                EndAcidKnobGesture(pointerId);
                pointerId = -1;
            });
            tile.Add(face);
            var caption = Txt(name, 10, Muted);
            caption.style.marginTop = 7;
            caption.style.unityTextAlign = TextAnchor.MiddleCenter;
            caption.style.unityFontStyleAndWeight = FontStyle.Bold;
            tile.Add(caption);
            row.Add(tile);
        }

        private void ChangeAcidSetting(Action change)
        {
            change?.Invoke();
            acidUnappliedChanges = true;
            RefreshAcidGeneratorPanel();
            QueueAcidLiveUpdate();
        }

        private void QueueAcidLiveUpdate()
        {
            if (acidLiveUpdate != null)
            {
                acidLiveUpdate.Pause();
                acidLiveUpdate = null;
            }
            if (!acidLiveEnabled || !acidAppliedInSession || generatorPanel == null ||
                generatorPanel.style.display.value != DisplayStyle.Flex) return;
            // Coalesce rapid knob/slider gestures into safe clip/transport updates.
            acidLiveUpdate = generatorPanel.schedule.Execute(() =>
            {
                acidLiveUpdate = null;
                if (!acidLiveEnabled || !acidAppliedInSession || !acidUnappliedChanges ||
                    generatorPanel == null || generatorPanel.style.display.value != DisplayStyle.Flex ||
                    song == null || song.tracks == null || generatorTargetTrack != trackIndex ||
                    song.tracks[trackIndex].kind != TrackKind.Acid) return;

                GenerateAcidSequence();
            });

            acidLiveUpdate.ExecuteLater(190);
        }

        private void RefreshAcidStepPreview()
        {
            if (acidPatternPreview == null) return;
            var hits = new bool[16];
            var accents = new bool[16];
            var slides = new bool[16];
            if (acidAppliedInSession && content != null && content.kind == ClipKind.Midi && content.notes != null)
            {
                foreach (var note in content.notes)
                {
                    if (note == null || note.startTick < 0 || note.startTick >= SongData.TicksPerBar4) continue;
                    int step = Mathf.Clamp((int)(note.startTick * 16 / SongData.TicksPerBar4), 0, 15);
                    hits[step] = true;
                    accents[step] |= note.accent;
                    slides[step] |= note.slide;
                }
            }
            for (int i = 0; i < 16; ++i)
            {
                var cell = acidPatternPreview[i];
                cell.style.backgroundColor = !hits[i] ? Raised : accents[i] ?
                    new Color(.98f,.66f,.28f) : slides[i] ? new Color(.35f,.60f,.98f) : Accent;
                cell.style.opacity = hits[i] ? 1f : .5f;
            }
        }

        private void RefreshAcidGeneratorPanel()
        {
            if (acidKeyLabel != null)
                acidKeyLabel.text = ZPunkAcidPatternGenerator.Keys[Mathf.Clamp(acidSettings.key, 0, 11)] +
                    "  /  " + ZPunkAcidPatternGenerator.Scales[Mathf.Clamp(acidSettings.scale, 0, 4)];
            foreach (var paint in acidControlPainters) paint();
            if (acidLiveButton != null)
            {
                acidLiveButton.text = acidLiveEnabled ? "LIVE ON" : "LIVE OFF";
                acidLiveButton.style.backgroundColor = acidLiveEnabled ? SelectedColor() : Raised;
                acidLiveButton.style.color = acidLiveEnabled ? Accent : Muted;
            }
            if (acidLiveStatus != null)
                acidLiveStatus.text = !acidAppliedInSession ? "APPLY TO CREATE / REPLACE THE CLIP" :
                    acidUnappliedChanges ? (acidLiveEnabled ? "LIVE / UPDATING PATTERN..." : "CHANGES PENDING / TAP APPLY") :
                    (acidLiveEnabled ? "LIVE / CHANGES UPDATE THIS CLIP" : "LIVE OFF / TAP APPLY TO UPDATE");
            if (acidGeneratorSummary != null)
                acidGeneratorSummary.text = ZPunkAcidPatternGenerator.Bars[Mathf.Clamp(acidSettings.bars, 0, 4)] +
                    " BARS  /  " + ZPunkAcidPatternGenerator.Divisions[Mathf.Clamp(acidSettings.division, 0, 2)] +
                    " GRID  /  VARIATION " + acidSettings.variation +
                    "  /  EDITS AFFECT ONLY THE SELECTED ACID CLIP";
            RefreshAcidStepPreview();
        }

        private void SaveSharedHarmonicSelection(int? newProgression = null)
        {
            if (projects == null || song == null) return;
            SongData edited = projects.GetSongForArrangementEditor();
            if (edited == null) return;
            if (!ReferenceEquals(projects.CurrentSong, edited))
                edited = ArrangementEditing.IndependentCopy(edited);
            if (newProgression.HasValue)
                edited.sharedProgressionChoice = Mathf.Clamp(newProgression.Value, 0,
                    ZPunkGenreGenerator.ProgressionChoiceCount - 1);
            edited.sharedProgressionKey = generatorKey;
            edited.sharedProgressionMinor = generatorMinor;
            // Manual guidance follows the selected key as it is changed, rather
            // than becoming stuck on the key active when HIGHLIGHT KEY was tapped.
            if (sampleKeyGuideEnabled && !sampleKeyGuideFromSample)
            {
                sampleKeyGuideTonic = generatorKey;
                sampleKeyGuideMinor = generatorMinor;
                ApplySampleKeyGuide();
                RefreshClipSampleKeyReference();
            }
            projects.AcceptArrangementEdit(edited);
            song = edited;
            clip = ArrangementEditing.FindClip(song, clipId, out _);
            content = clip == null ? null : ArrangementEditing.FindContent(song, clip.contentId);
            // This changes future generation settings, not currently playing notes;
            // avoid rebuilding the editor or interrupting the open generator sheet.
        }

        private void StepSharedProgression(int direction)
        {
            int count = ZPunkGenreGenerator.ProgressionChoiceCount;
            int current = song != null ? song.sharedProgressionChoice : 0;
            int selected = (current + direction + count) % count;
            SaveSharedHarmonicSelection(selected);
            // A four-chord progression needs four bars to be fully audible.
            if (selected > 0 && current == 0 && clip == null) generatorBars = 4;
            RefreshGeneratorPanel();
        }

        private void OpenGenerator(int requestedTrack)
        {
            if (!ready || showingSampler || generatorPanel == null || song == null || song.tracks == null ||
                requestedTrack < 0 || requestedTrack >= song.tracks.Count ||
                song.tracks[requestedTrack].kind == TrackKind.Chops) return;
            if (requestedTrack != trackIndex) SelectTrack(requestedTrack);
            generatorTargetTrack = trackIndex;
            if (song.tracks[trackIndex].kind == TrackKind.Acid)
            {
                // Initialize once per project. Never silently reset the user's
                // generator key/scale when they leave and reopen this panel.
                if (!acidSettingsInitialized)
                {
                    acidSettings.key = Mathf.Clamp(song.sharedProgressionKey, 0, 11);
                    acidSettings.scale = song.sharedProgressionMinor ? 0 : 1;
                    acidSettings.noteMask = -1;
                    acidSettingsInitialized = true;
                }
                if (clip != null && content != null)
                {
                    int currentBars = Mathf.Max(1, (int)(content.lengthTicks / SongData.TicksPerBar4));
                    for (int index = 0; index < ZPunkAcidPatternGenerator.Bars.Length; index++)
                        if (ZPunkAcidPatternGenerator.Bars[index] <= currentBars) acidSettings.bars = index;
                }
                // A new session requires an intentional APPLY before live rewrites;
                // reopening never automatically overwrites an edited MIDI clip.
                acidAppliedInSession = false;
                acidUnappliedChanges = false;
                if (acidLiveUpdate != null) { acidLiveUpdate.Pause(); acidLiveUpdate = null; }
                // Preserve the user's complete ACID generation setup.
                RefreshGeneratorPanel();
                generatorPanel.style.display = DisplayStyle.Flex;
                generatorPanel.schedule.Execute(() => SyncAcidKnobTouchTargets()).ExecuteLater(0);
                return;
            }
            // All generator tracks read the SAME saved project-wide progression/key.
            if (song.sharedProgressionChoice > 0)
            {
                generatorKey = Mathf.Clamp(song.sharedProgressionKey, 0, 11);
                generatorMinor = song.sharedProgressionMinor;
            }
            if (song.tracks[trackIndex].kind == TrackKind.Synth)
                generatorSynthChords = content != null &&
                    !string.IsNullOrEmpty(content.generatedTag) &&
                    content.generatedTag.Contains(" / CHORDS / ");
            generatorBars = clip == null ? (song.sharedProgressionChoice > 0 ? 4 : 2) :
                (clip.lengthTicks >= 4 * SongData.TicksPerBar4 ? 4 :
                 clip.lengthTicks >= 2 * SongData.TicksPerBar4 ? 2 : 1);
            generatorVariation++;
            FindSampler();
            RefreshGeneratorPanel();
            generatorPanel.style.display = DisplayStyle.Flex;
        }
        private void CloseGenerator()
        {
            CancelAcidKnobGesture();
            if (acidLiveUpdate != null) { acidLiveUpdate.Pause(); acidLiveUpdate = null; }
            bool showNotes = acidAppliedInSession && generatorPanel != null &&
                generatorPanel.style.display.value == DisplayStyle.Flex &&
                song != null && song.tracks != null && generatorTargetTrack >= 0 &&
                generatorTargetTrack < song.tracks.Count &&
                song.tracks[generatorTargetTrack].kind == TrackKind.Acid;
            if (generatorPanel != null) generatorPanel.style.display = DisplayStyle.None;
            if (acidKnobTouchLayer != null) acidKnobTouchLayer.style.display = DisplayStyle.None;
            if (showNotes && content != null && content.kind == ClipKind.Midi) FocusPatternNotes(true);
            acidAppliedInSession = false;
        }
        private void RefreshGeneratorPanel()
        {
            if (generatorPanel == null || song == null || song.tracks == null ||
                generatorTargetTrack >= song.tracks.Count) return;
            generatorHeading.text = "GENERATE  /  " + song.tracks[generatorTargetTrack].name.ToUpperInvariant();
            bool isAcidTrack = song.tracks[generatorTargetTrack].kind == TrackKind.Acid;
            generatorHint.text = isAcidTrack ? (clip == null ?
                "APPLY creates an ACID clip. The panel remains open for further changes." :
                "APPLY replaces notes in " + clip.name + ". CLOSE keeps the last applied pattern.") :
                clip == null ? "Creates a new clip. No changes until GENERATE is tapped." :
                "REPLACES all notes in " + clip.name + ". Cancel leaves it unchanged." +
                (string.IsNullOrEmpty(content?.generatedTag) ? "" : "\nCURRENT: " + content.generatedTag);
            bool acidGenerator = song.tracks[generatorTargetTrack].kind == TrackKind.Acid;
            if (normalGeneratorSections != null)
                normalGeneratorSections.style.display = acidGenerator ? DisplayStyle.None : DisplayStyle.Flex;
            if (acidGeneratorSections != null)
                acidGeneratorSections.style.display = acidGenerator ? DisplayStyle.Flex : DisplayStyle.None;
            // Layout is recalculated on the next panel update; the overlay
            // follows scrolling and face geometry without blocking other UI.
            SyncAcidKnobTouchTargets();
            if (generatorApplyButton != null)
                generatorApplyButton.text = acidGenerator ? (acidAppliedInSession ? "APPLY AGAIN" : "APPLY") : "GENERATE";
            if (acidLiveButton != null)
                acidLiveButton.style.display = acidGenerator ? DisplayStyle.Flex : DisplayStyle.None;
            if (generatorCancelButton != null)
                generatorCancelButton.text = acidGenerator ? "CLOSE" : "CANCEL";
            if (acidGenerator)
            {
                RefreshAcidGeneratorPanel();
                return;
            }
            generatorGenres.Clear();
            for (int g = 0; g < ZPunkGenreGenerator.Genres.Length; g++)
            {
                int index = g;
                var button = Btn(ZPunkGenreGenerator.Genres[g],() => { generatorGenre = index; generatorStyle = 0; RefreshGeneratorPanel(); },90);
                if (g == generatorGenre) { button.style.backgroundColor = SelectedColor(); button.style.color = Accent; }
                generatorGenres.Add(button);
            }
            generatorStyles.Clear();
            if (generatorGenre == 1 && generatorStyle == 3 && song.tracks[generatorTargetTrack].kind == TrackKind.Drums) generatorStyle = 0;
            for (int st = 0; st < ZPunkGenreGenerator.Styles[generatorGenre].Length; st++)
            {
                if (generatorGenre == 1 && st == 3 && song.tracks[generatorTargetTrack].kind == TrackKind.Drums) continue;
                int index = st;
                var button = Btn(ZPunkGenreGenerator.Styles[generatorGenre][st],() => { generatorStyle = index; RefreshGeneratorPanel(); },91);
                if (st == generatorStyle) { button.style.backgroundColor = SelectedColor(); button.style.color = Accent; }
                generatorStyles.Add(button);
            }
            bool isSynth = song.tracks[generatorTargetTrack].kind == TrackKind.Synth;
            if (generatorSynthModeRow != null)
                generatorSynthModeRow.style.display = isSynth ? DisplayStyle.Flex : DisplayStyle.None;
            if (generatorMelodyButton != null && generatorChordsButton != null)
            {
                generatorMelodyButton.style.backgroundColor = !generatorSynthChords ? SelectedColor() : Raised;
                generatorMelodyButton.style.color = !generatorSynthChords ? Accent : Ink;
                generatorChordsButton.style.backgroundColor = generatorSynthChords ? SelectedColor() : Raised;
                generatorChordsButton.style.color = generatorSynthChords ? Accent : Ink;
            }
            bool chords = isSynth && generatorSynthChords;
            TrackKind generatorKind = song.tracks[generatorTargetTrack].kind;
            if (generatorProgressionSection != null)
                generatorProgressionSection.style.display = generatorKind == TrackKind.Drums
                    ? DisplayStyle.None : DisplayStyle.Flex;
            generatorSummary.text = (chords ?
                ZPunkGenreGenerator.ChordsDescription(generatorGenre, generatorStyle) :
                generatorKind == TrackKind.Bass ? ZPunkGenreGenerator.BassDescription(generatorGenre, generatorStyle) :
                generatorKind == TrackKind.Pads ? ZPunkGenreGenerator.ChordsDescription(generatorGenre, generatorStyle) :
                ZPunkGenreGenerator.Description(generatorGenre, generatorStyle)) + "\n" +
                "READY: " + ZPunkGenreGenerator.Label(generatorGenre, generatorStyle, generatorKey, generatorMinor, chords) +
                (isSynth && !chords ? " / MELODY" : "") +
                (song.sharedProgressionChoice > 0 ? " / SHARED PROGRESSION " + song.sharedProgressionChoice : "");
            generatorKeyLabel.text = ZPunkGenreGenerator.Keys[generatorKey] + (generatorMinor ? " MIN" : " MAJ");
            int progressionChoice = song.sharedProgressionChoice;
            if (generatorProgressionLabel != null)
                generatorProgressionLabel.text = ZPunkGenreGenerator.ProgressionLabel(generatorGenre, generatorMinor, progressionChoice);
            if (generatorProgressionChords != null)
                generatorProgressionChords.text = ZPunkGenreGenerator.ProgressionChordNames(
                    generatorGenre, generatorKey, generatorMinor, progressionChoice) +
                    (progressionChoice > 0 ? " / all parts follow these chords" : " / original genre harmony");
            RefreshGeneratorKeyGuideControls();
            generatorBarsRow.Clear();
            foreach (int count in new[]{1,2,4})
            {
                int selected = count;
                var button = Btn(count + (count == 1 ? " BAR" : " BARS"), () => { generatorBars = selected; RefreshGeneratorPanel(); },76);
                button.style.flexGrow = 1;
                if (generatorBars == count) { button.style.backgroundColor = SelectedColor(); button.style.color = Accent; }
                generatorBarsRow.Add(button);
            }
            generatorVariationLabel.text = "VARIATION " + generatorVariation.ToString();
            RefreshGenerationHistory();
        }

        // Update both on generator edits and while sample-key analysis finishes.
        private void RefreshGeneratorKeyGuideControls()
        {
            FindSampler();
            bool hasSampleKey = samplePlayer != null && samplePlayer.DawSampleKeyAvailable;
            if (generatorSampleKeyButton != null)
            {
                generatorSampleKeyButton.SetEnabled(true);
                generatorSampleKeyButton.text = sampleKeyGuideEnabled ? "RESET KEY ROWS" :
                    hasSampleKey ? "USE SAMPLE KEY" : "HIGHLIGHT KEY";
            }
            if (generatorSampleKeyHint == null) return;
            if (sampleKeyGuideEnabled && !sampleKeyGuideFromSample)
            {
                generatorSampleKeyHint.text = "SELECTED KEY / " +
                    ZPunkGenreGenerator.Keys[generatorKey] + (generatorMinor ? " MIN" : " MAJ");
            }
            else
            {
                generatorSampleKeyHint.text = samplePlayer != null && samplePlayer.DawSampleKeyAnalyzing
                    ? "ANALYZING SAMPLE"
                    : hasSampleKey ? samplePlayer.DawPitchedKeyText + " / " +
                        samplePlayer.DawSampleKeyConfidence + " EST."
                    : "SELECTED KEY / " + ZPunkGenreGenerator.Keys[generatorKey] +
                        (generatorMinor ? " MIN" : " MAJ");
            }
        }

        private void RefreshGenerationHistory()
        {
            if (generatorHistoryRows == null || generatorHistoryLabel == null || projects == null ||
                song == null || song.tracks == null || generatorTargetTrack < 0 ||
                generatorTargetTrack >= song.tracks.Count) return;
            generatorHistoryRows.Clear();
            TrackKind kind = song.tracks[generatorTargetTrack].kind;
            bool chords = kind == TrackKind.Synth && generatorSynthChords;
            var entries = ZPunkGenerationHistory.Read(projects.CurrentSlot, kind, generatorGenre, chords);
            generatorHistoryLabel.text = "PREVIOUS / " + ZPunkGenreGenerator.Genres[generatorGenre] +
                "  (" + entries.Count + ")";
            if (entries.Count == 0)
            {
                var empty = Txt("No saved generations yet. Generate a pattern to keep it here.", 11, Muted);
                empty.style.whiteSpace = WhiteSpace.Normal;
                empty.style.marginTop = 10;
                generatorHistoryRows.Add(empty);
                return;
            }
            for (int historyIndex = 0; historyIndex < entries.Count; historyIndex++)
            {
                var entry = entries[historyIndex];
                if (entry == null || entry.snapshot == null) continue;
                int deleteIndex = historyIndex;
                var row = new VisualElement();
                row.style.flexDirection = FlexDirection.Row;
                row.style.alignItems = Align.Center;
                row.style.marginBottom = 6;
                row.style.paddingLeft = 8;
                row.style.backgroundColor = Raised;
                row.style.borderTopLeftRadius = 6;
                row.style.borderBottomLeftRadius = 6;
                row.style.borderTopRightRadius = 6;
                row.style.borderBottomRightRadius = 6;
                string styleName = ZPunkGenreGenerator.Styles[generatorGenre][Mathf.Clamp(entry.style, 0, ZPunkGenreGenerator.Styles[generatorGenre].Length - 1)];
                var details = Txt(styleName + "  /  " + ZPunkGenreGenerator.Keys[Mathf.Clamp(entry.key, 0, 11)] +
                    (entry.minor ? "m" : "") + "  /  " + entry.bars + " BAR" +
                    (entry.bars == 1 ? "" : "S") + "  /  V" + entry.variation +
                    (ZPunkGenreGenerator.ProgressionFromTag(entry.snapshot.generatedTag) > 0
                        ? "  /  P" + ZPunkGenreGenerator.ProgressionFromTag(entry.snapshot.generatedTag) : ""), 12, Ink);
                details.style.flexGrow = 1;
                details.style.minWidth = 0;
                details.style.overflow = Overflow.Hidden;
                details.style.textOverflow = TextOverflow.Ellipsis;
                details.style.whiteSpace = WhiteSpace.NoWrap;
                row.style.paddingRight = 5;
                row.style.minHeight = 48;
                row.Add(details);
                var use = Btn("USE", () => RestoreGeneration(entry), 53);
                use.style.height = 42;
                use.style.minWidth = 53;
                use.style.backgroundColor = SelectedColor();
                use.style.color = Accent;
                row.Add(use);
                var del = Btn("DEL", () => DeleteGeneration(deleteIndex), 49);
                del.style.height = 42;
                del.style.minWidth = 49;
                del.style.marginLeft = 4;
                del.style.color = new Color(1f,.69f,.67f);
                del.style.backgroundColor = Surface;
                row.Add(del);
                generatorHistoryRows.Add(row);
            }
        }

        private void DeleteGeneration(int index)
        {
            if (projects == null || song == null || song.tracks == null ||
                generatorTargetTrack < 0 || generatorTargetTrack >= song.tracks.Count) return;
            TrackKind kind = song.tracks[generatorTargetTrack].kind;
            bool chords = kind == TrackKind.Synth && generatorSynthChords;
            if (ZPunkGenerationHistory.Delete(projects.CurrentSlot, kind, generatorGenre, chords, index))
                RefreshGenerationHistory();
        }

        private static Color SelectedColor() { return new Color(.10f,.32f,.34f); }

        // Both new generations and restored history use exactly the same clip-writing
        // path, leaving sample content and other tracks untouched.
        private bool PrepareGeneratorContent(int bars)
        {
            if (song == null || song.tracks == null || generatorTargetTrack != trackIndex ||
                song.tracks[trackIndex].kind == TrackKind.Chops) return false;
            if (!Writable()) return false;
            TrackData track = song.tracks[trackIndex];
            if (clip == null)
            {
                long start = ArrangementEditing.NextFreeStart(track, 0, bars * SongData.TicksPerBar4);
                clip = ArrangementEditing.CreateClip(song, track, start);
                if (clip == null) return false;
                clipId = clip.id;
                content = ArrangementEditing.FindContent(song, clip.contentId);
            }
            if (content == null)
            {
                if (song.contents == null) song.contents = new List<ClipContentData>();
                content = new ClipContentData { id = ArrangementEditing.Id("content") };
                song.contents.Add(content);
                clip.contentId = content.id;
            }
            return true;
        }
        // Applies only after the user confirms the ACID parameter sheet.
        private void GenerateAcidSequence()
        {
            // Manual APPLY supersedes any pending debounced live rewrite.
            if (acidLiveUpdate != null) { acidLiveUpdate.Pause(); acidLiveUpdate = null; }
            int bars = ZPunkAcidPatternGenerator.Bars[Mathf.Clamp(acidSettings.bars, 0, 4)];
            if (!PrepareGeneratorContent(bars) || content == null) return;
            ZPunkAcidPatternGenerator.Fill(content, acidSettings);
            acidAppliedInSession = true;
            acidUnappliedChanges = false;
            FinishGeneratorContent(true);
        }

        private void FinishGeneratorContent(bool keepGeneratorOpen = false)
        {
            clip.sourceOffsetTick = 0;
            clip.loopEnabled = false;
            clip.lengthTicks = content.lengthTicks;
            ArrangementEditing.ExtendSong(song, clip.startTick + clip.lengthTicks);
            selectedNote = -1;
            selectedEventRow = -1;
            selectedEventTick = -1;
            if (!keepGeneratorOpen) CloseGenerator();
            Changed(true, keepGeneratorOpen);
            if (keepGeneratorOpen)
            {
                // Redraw only rebuilds the step grid, not the modal sheet.
                // Repeated APPLY/LIVE writes therefore preserve sheet scroll and touch.
                RefreshGeneratorPanel();
            }
            // GEN and history restoration reveal the generated octave after close.
            else if (content.kind == ClipKind.Midi) FocusPatternNotes(true);
        }
        // Prefer existing PAD or chord-mode SYNTH harmony at the selected clip location.
        // Never read notes from the clip currently being regenerated.
        private void ReadArrangementHarmony(int bars, out int[] degrees, out int[][] voices)
        {
            degrees = new int[bars];
            voices = new int[bars][];
            for (int b = 0; b < bars; b++) degrees[b] = -1;
            if (song == null || song.tracks == null || song.contents == null || clip == null) return;
            for (int b = 0; b < bars; b++)
            {
                long tick = clip.startTick + b * SongData.TicksPerBar4;
                List<int> pitches = null;
                foreach (var track in song.tracks)
                {
                    if (track == null || (track.kind != TrackKind.Pads && track.kind != TrackKind.Synth) || track.clips == null) continue;
                    if (track.kind == song.tracks[trackIndex].kind && track.kind != TrackKind.Pads) continue;
                    foreach (var item in track.clips)
                    {
                        if (item == null || item.id == clip.id || tick < item.startTick || tick >= item.startTick + item.lengthTicks) continue;
                        var source = song.contents.Find(x => x != null && x.id == item.contentId);
                        if (source == null || source.kind != ClipKind.Midi || source.notes == null || source.notes.Count < 3) continue;
                        long local = tick - item.startTick + item.sourceOffsetTick;
                        if (item.loopEnabled && source.lengthTicks > 0) local %= source.lengthTicks;
                        var notes = new List<int>();
                        foreach (var note in source.notes)
                            if (note != null && note.startTick <= local && note.startTick + note.durationTicks > local)
                                notes.Add(note.pitch);
                        // A chord may be stabbed on an offbeat instead of held at the barline.
                        if (notes.Count < 3)
                            foreach (var note in source.notes)
                                if (note != null && note.startTick >= local && note.startTick < local + SongData.TicksPerQuarter)
                                    notes.Add(note.pitch);
                        if (notes.Count >= 3) { pitches = notes; break; }
                    }
                    if (pitches != null) break;
                }
                if (pitches == null) continue;
                pitches.Sort();
                voices[b] = pitches.ToArray();
                // Choose the diatonic triad whose pitch classes best fit the chord.
                int bestDegree = -1, bestScore = -1;
                int[] scale = generatorMinor ? new[] {0,2,3,5,7,8,10} : new[] {0,2,4,5,7,9,11};
                for (int d = 0; d < 7; d++)
                {
                    int score = 0;
                    for (int offset = 0; offset <= 4; offset += 2)
                    {
                        int pc = (generatorKey + scale[(d + offset) % 7]) % 12;
                        foreach (int pitch in pitches)
                            if ((pitch % 12 + 12) % 12 == pc) { score += offset == 0 ? 3 : 2; break; }
                    }
                    if (score > bestScore) { bestScore = score; bestDegree = d; }
                }
                if (bestScore >= 4) degrees[b] = bestDegree;
            }
        }

        private void ApplyGenerator()
        {
            if (song != null && song.tracks != null && generatorTargetTrack >= 0 &&
                generatorTargetTrack < song.tracks.Count &&
                song.tracks[generatorTargetTrack].kind == TrackKind.Acid)
            {
                GenerateAcidSequence();
                return;
            }
            if (!PrepareGeneratorContent(generatorBars)) return;
            TrackKind kind = song.tracks[trackIndex].kind;
            bool chords = kind == TrackKind.Synth && generatorSynthChords;
            int[] detectedDegrees = null;
            int[][] detectedVoices = null;
            if (song.sharedProgressionChoice == 0 &&
                (kind == TrackKind.Bass || (kind == TrackKind.Synth && !chords)))
                ReadArrangementHarmony(generatorBars, out detectedDegrees, out detectedVoices);
            // The shared progression takes priority over previously arranged harmony;
            // bar offset is the clip's actual arrangement position, not its local bar.
            int barOffset = clip == null ? 0 : (int)(clip.startTick / SongData.TicksPerBar4);
            ZPunkGenreGenerator.Fill(content, kind, generatorGenre, generatorStyle,
                generatorBars, generatorKey, generatorMinor, generatorVariation, chords,
                detectedDegrees, detectedVoices, song.sharedProgressionChoice, barOffset,
                song.bpm);
            ZPunkGenerationHistory.Add(projects.CurrentSlot, kind, generatorGenre, generatorStyle,
                generatorKey, generatorMinor, generatorBars, generatorVariation, chords, content);
            FinishGeneratorContent();
        }
        private void RestoreGeneration(ZPunkGenerationHistory.Entry entry)
        {
            ClipContentData saved = ZPunkGenerationHistory.Copy(entry);
            if (saved == null || !PrepareGeneratorContent(Mathf.Clamp(entry.bars, 1, 4))) return;
            // Preserve this clip's stable contentId so linked song references remain valid.
            content.kind = saved.kind;
            content.lengthTicks = saved.lengthTicks;
            content.generatedTag = saved.generatedTag;
            int historyProgression = ZPunkGenreGenerator.ProgressionFromTag(saved.generatedTag);
            if (historyProgression > 0)
            {
                generatorKey = Mathf.Clamp(entry.key, 0, 11);
                generatorMinor = entry.minor;
                SaveSharedHarmonicSelection(historyProgression);
            }
            content.notes = saved.notes ?? new List<NoteEvent>();
            content.drums = saved.drums ?? new List<DrumEvent>();
            content.chops = new List<ChopEvent>();
            // Older saved generations may still contain an empty first step.
            // Bring restored patterns onto the same tick-zero convention.
            ZPunkGenreGenerator.AlignToStart(content);
            FinishGeneratorContent();
        }

        private void FindDrumEngine()
        {
            if (drumEngine == null) drumEngine = FindObjectOfType<KMusicDrumSequencer>();
        }
        private void RefreshKitSelector()
        {
            if (kitSelector == null) return;
            // Exactly one slot remains visible at a time. Display.None prevents
            // the inactive slot from taking another 50 points of screen height.
            kitSelector.style.display = trackIndex == 0 ? DisplayStyle.Flex : DisplayStyle.None;
            if (trackScopeRow != null)
                trackScopeRow.style.display = trackIndex > 0 && trackIndex < 6
                    ? DisplayStyle.Flex : DisplayStyle.None;
            if (sampleLabButton != null)
                sampleLabButton.style.display = trackIndex == 4 ? DisplayStyle.Flex : DisplayStyle.None;
            if (trackScope != null)
                trackScope.style.display = DisplayStyle.Flex;
            if (trackScope != null && trackIndex > 0 && trackIndex < 6)
            {
                var color = colors[trackIndex];
                trackScope.Select(trackIndex, color);
                if (trackScopeTitle != null)
                {
                    trackScopeTitle.text = trackIndex == 1 ? "BASS" :
                        trackIndex == 2 ? "SYNTH" : trackIndex == 3 ? "PADS" : trackIndex == 4 ? "CHOPS" : "ACID";
                    trackScopeTitle.style.color = color;
                }
            }
            if (trackIndex != 0) return;
            FindDrumEngine();
            if (kitName != null) kitName.text = drumEngine != null ? drumEngine.DawKitName : "KIT UNAVAILABLE";
        }
        private void StepDrumKit(int direction)
        {
            FindDrumEngine();
            if (drumEngine == null) return;
            drumEngine.DawStepKit(direction);
            RefreshKitSelector();
            if (projects != null)
            {
                var edited = projects.GetSongForArrangementEditor();
                if (edited != null && edited.tracks != null && edited.tracks.Count > 0)
                {
                    if (!ReferenceEquals(projects.CurrentSong, edited))
                        edited = ArrangementEditing.IndependentCopy(edited);
                    edited.tracks[0].instrument.drumKitIndex = drumEngine.CaptureKitIndex();
                    edited.tracks[0].instrument.drumKitId = drumEngine.CaptureKitId();
                    projects.AcceptArrangementEdit(edited);
                    song = edited;
                }
            }
            OnClipChanged?.Invoke();
        }

        private void FindSampler()
        {
            if (samplePlayer == null) samplePlayer = FindObjectOfType<KMusicPlayerUI>();
        }
        private void RefreshSampler()
        {
            FindSampler();
            if (samplerTitle != null)
                samplerTitle.text = samplePlayer != null ? samplePlayer.DawSampleName : "SAMPLER UNAVAILABLE";
            if (samplerBpmLabel != null)
                samplerBpmLabel.text = "SOURCE " + (samplePlayer != null ? samplePlayer.DawTrackBpmCompact : "BPM --");
            if (samplerTapBpmStatus != null)
            {
                string tapStatus = samplePlayer != null ? samplePlayer.DawTapBpmStatus : "";
                samplerTapBpmStatus.text = tapStatus;
                samplerTapBpmStatus.style.display = string.IsNullOrEmpty(tapStatus) ?
                    DisplayStyle.None : DisplayStyle.Flex;
            }
            if (samplerWarpButton != null)
                samplerWarpButton.text = samplePlayer != null && samplePlayer.DawAutoWarp ? "WARP ON" : "WARP OFF";
            if (samplerWarpLabel != null)
                samplerWarpLabel.text = samplePlayer != null ?
                    (samplePlayer.DawAutoWarp ?
                        "WARP / " + samplePlayer.DawTrackBpmLabel + " / " + samplePlayer.DawWarpStatus :
                        "ORIGINAL AUDIO / NO TIME STRETCH") :
                    "NO SAMPLE";
            bool warpBusy = samplePlayer != null && samplePlayer.DawWarpProcessing;
            if (samplerWarpProgressTrack != null)
                samplerWarpProgressTrack.style.display = warpBusy ? DisplayStyle.Flex : DisplayStyle.None;
            if (samplerWarpProgressLabel != null)
            {
                samplerWarpProgressLabel.style.display = warpBusy ? DisplayStyle.Flex : DisplayStyle.None;
                if (warpBusy)
                    samplerWarpProgressLabel.text = samplePlayer.DawWarpStage + " / " +
                        Mathf.RoundToInt(samplePlayer.DawWarpProgress * 100f) + "%";
            }
            if (samplerWarpProgressFill != null)
                samplerWarpProgressFill.style.width = Length.Percent(
                    samplePlayer != null ? Mathf.Clamp01(samplePlayer.DawWarpProgress) * 100f : 0f);
            if (samplerPitchLabel != null)
            {
                int semitones = samplePlayer != null ? samplePlayer.DawPitchSemitones : 0;
                samplerPitchLabel.text = (semitones > 0 ? "+" : "") + semitones + " ST";
            }
            if (samplerSourceKeyLabel != null)
                samplerSourceKeyLabel.text = samplePlayer == null ? "SOURCE KEY  /  NO SAMPLE" :
                    "SOURCE KEY  /  " + samplePlayer.DawSourceKeyText +
                    (samplePlayer.DawSampleKeyAvailable ? "  (" + samplePlayer.DawSampleKeyConfidence + " EST.)" : "");
            if (samplerPitchedKeyLabel != null)
                samplerPitchedKeyLabel.text = samplePlayer == null ? "PITCHED KEY  /  UNKNOWN" :
                    "PITCHED KEY  /  " + samplePlayer.DawPitchedKeyText +
                    "  (" + (samplePlayer.DawPitchSemitones >= 0 ? "+" : "") + samplePlayer.DawPitchSemitones + " ST)";
            if (samplerLibraryLabel != null)
                samplerLibraryLabel.text = samplePlayer != null ? samplePlayer.DawSampleFolder : "SAMPLE LIBRARY";
            if (samplerSelectedMarker != null)
                samplerSelectedMarker.text = samplePlayer != null ? samplePlayer.DawSelectedMarkerLabel : "NO MARKER SELECTED";
            if (samplerHitSliceStatus != null)
                samplerHitSliceStatus.text = samplePlayer != null ?
                    samplePlayer.DawHitSliceStatus + " / " +
                    samplePlayer.DawMusicalGridStatus + " / UP TO 16 PADS" : "NO SAMPLE";
            bool hitsBusy = samplePlayer != null && samplePlayer.DawHitAnalysisRunning;
            if (samplerHitProgressLabel != null)
            {
                samplerHitProgressLabel.style.display = hitsBusy ? DisplayStyle.Flex : DisplayStyle.None;
                if (hitsBusy)
                {
                    float eta = samplePlayer.DawHitAnalysisEta;
                    samplerHitProgressLabel.text = "AMBER HIT GUIDES / " +
                        Mathf.RoundToInt(samplePlayer.DawHitAnalysisProgress * 100f) + "% / " +
                        samplePlayer.DawHitAnalysisSeconds.ToString("0.0") + "s ELAPSED" +
                        (eta >= 0f ? " / ~" + eta.ToString("0") + "s LEFT" : "");
                }
            }
            if (samplerHitProgressTrack != null)
                samplerHitProgressTrack.style.display = hitsBusy ? DisplayStyle.Flex : DisplayStyle.None;
            if (samplerHitProgressFill != null)
                samplerHitProgressFill.style.width = Length.Percent(hitsBusy ?
                    samplePlayer.DawHitAnalysisProgress * 100f : 0f);
            if (samplerGridButton != null)
            {
                bool enabled = samplePlayer != null && samplePlayer.DawShowWaveGrid;
                samplerGridButton.text = enabled ? "GRID ON" : "GRID OFF";
                samplerGridButton.style.backgroundColor = enabled ? new Color(.12f, .31f, .29f) : Raised;
                samplerGridButton.style.color = enabled ? Accent : Ink;
            }
            if (samplerSnapButton != null)
                samplerSnapButton.text = samplePlayer != null ?
                    samplePlayer.DawSnapModeLabel : "HIT SNAP";
            for (int i = 0; i < samplerChopPads.Count; ++i)
            {
                Button button = samplerChopPads[i];
                VisualElement bar = samplerChopRangeBars[i];
                float start = 0f, end = 0f;
                bool exists = samplePlayer != null && samplePlayer.DawTryGetChopRange(i + 1, out start, out end);
                bool selected = exists && samplePlayer.DawSelectedChopPad == i + 1;
                float duration = samplePlayer != null ? samplePlayer.DawSampleDuration : 0f;
                button.text = exists
                    ? "S" + (i + 1).ToString("00") + "\n" +
                      (start * duration).ToString("0.0") + " - " + (end * duration).ToString("0.0") + "s"
                    : "S" + (i + 1).ToString("00") + "\nEMPTY";
                button.style.color = exists ? Ink : Muted;
                button.style.backgroundColor = selected ? new Color(.15f, .38f, .36f) : Raised;
                button.style.borderBottomWidth = selected ? 2f : 0f;
                button.style.borderBottomColor = Accent;
                bar.style.display = exists ? DisplayStyle.Flex : DisplayStyle.None;
                if (exists)
                {
                    bar.style.left = Length.Percent(start * 100f);
                    bar.style.width = Length.Percent(Mathf.Max(1f, (end - start) * 100f));
                }
            }
        }
        private void RefreshClipSampleKeyReference()
        {
            if (clipSampleKeyReference == null) return;
            FindSampler();
            bool midiTrack = song != null && song.tracks != null &&
                trackIndex >= 0 && trackIndex < song.tracks.Count &&
                (song.tracks[trackIndex].kind == TrackKind.Bass ||
                 song.tracks[trackIndex].kind == TrackKind.Synth ||
                 song.tracks[trackIndex].kind == TrackKind.Pads ||
                 song.tracks[trackIndex].kind == TrackKind.Acid);
            bool hasSampleKey = samplePlayer != null && samplePlayer.DawSampleKeyAvailable;
            bool show = midiTrack && (sampleKeyGuideEnabled || hasSampleKey);
            clipSampleKeyReference.style.display = show ? DisplayStyle.Flex : DisplayStyle.None;
            if (!show) return;
            if (sampleKeyGuideEnabled)
            {
                clipSampleKeyReference.text = (sampleKeyGuideFromSample ? "SAMPLE KEY GUIDE  /  " : "KEY GUIDE  /  ") +
                    ZPunkGenreGenerator.Keys[sampleKeyGuideTonic] + (sampleKeyGuideMinor ? " MIN" : " MAJ") +
                    (sampleKeyGuideFromSample && hasSampleKey ?
                        "  (" + samplePlayer.DawSampleKeyConfidence + " EST.)" : "");
            }
            else
                clipSampleKeyReference.text = "SAMPLE KEY  /  " + samplePlayer.DawPitchedKeyText +
                    "  (" + samplePlayer.DawSampleKeyConfidence + " EST.)";
        }

        private void ShowSampler(bool value)
        {
            // This method also runs on CREATE track changes. Never turn a closed
            // chord menu back on when restoring the regular editor controls.
            CloseChordMenu();
            bool wasShowingSampler = showingSampler;
            showingSampler = value;
            ShowDrumDesigner(false);
            if (root == null || samplerPage == null) return;
            if (!value && !wasShowingSampler)
            {
                // No sampler transition: leave the other controls' visibility
                // alone. In particular, don't revive a hidden popup or toolbar.
                CloseGenerator();
                RefreshChordDrawToolbar();
                RefreshKitSelector();
                return;
            }
            foreach (var child in root.Children())
            {
                if (child == generatorPanel || child == drumDesignerPage ||
                    child == chordMenuOverlay || child == drumPresetOverlay)
                    child.style.display = DisplayStyle.None;
                else if (child == samplerPage)
                    child.style.display = value ? DisplayStyle.Flex : DisplayStyle.None;
                else if (child == chordDrawToolbar)
                    child.style.display = !value && IsChordTrack ? DisplayStyle.Flex : DisplayStyle.None;
                else
                    child.style.display = value ? DisplayStyle.None : DisplayStyle.Flex;
            }
            if (!value)
            {
                RefreshChordDrawToolbar();
                RefreshClipSampleKeyReference();
                RefreshKitSelector();
                return;
            }
            FindSampler();
            samplePlayer?.DawPrepareSliceLab();
            if (samplerWave != null && samplerWave.childCount == 0)
            {
                var doc = FindObjectOfType<UIDocument>();
                var oldHost = doc != null ? doc.rootVisualElement.Q<VisualElement>("Waveform") : null;
                if (oldHost != null)
                {
                    oldHost.RemoveFromHierarchy();
                    oldHost.style.height = 170;
                    oldHost.style.flexGrow = 1;
                    samplerWave.Add(oldHost);
                    var waveform = oldHost.Q<KMusic.UI.WaveformView>();
                    if (waveform != null)
                    {
                        waveform.VerticalDragDelta -= ScrollSamplerFromWaveform;
                        waveform.VerticalDragDelta += ScrollSamplerFromWaveform;
                    }
                }
            }
            RefreshSampler();
        }
        private void ScrollSamplerFromWaveform(float deltaY)
        {
            if (!showingSampler || samplerScroll == null) return;
            samplerScroll.scrollOffset = new Vector2(samplerScroll.scrollOffset.x,
                Mathf.Max(0, samplerScroll.scrollOffset.y - deltaY));
        }
        private void OpenSampler() { ShowSampler(true); }

        // A saved set of waveform markers defines playable slices, but not MIDI-style
        // step events. Copy the applied sample assignment into the DAW Chops track
        // so a painted S01-S16 cell can actually trigger that saved slice.
        private void ApplySamplerChops()
        {
            FindSampler();
            if (samplePlayer == null) return;
            samplePlayer.DawApplySlices();
            RefreshSampler();

            if (projects == null) projects = FindObjectOfType<KMusicProjectManager>();
            if (projects == null) return;
            var edited = projects.GetSongForArrangementEditor();
            if (edited == null || edited.tracks == null) return;
            if (!KMusic.KMusicChopState.TryLoadApplied(out string path, out float[] starts, out float[] ends))
                return;
            if (!ReferenceEquals(projects.CurrentSong, edited))
                edited = ArrangementEditing.IndependentCopy(edited);
            if (edited == null) return;
            foreach (var track in edited.tracks)
            {
                if (track == null || track.kind != TrackKind.Chops) continue;
                if (track.instrument == null) track.instrument = new InstrumentState();
                track.instrument.sampleResourcesPath = path;
                track.instrument.sliceStart01 = (float[])starts.Clone();
                track.instrument.sliceEnd01 = (float[])ends.Clone();
                projects.AcceptArrangementEdit(edited);
                song = edited;
                LoadClip(); // Rebind references after copying the document.
                OnClipChanged?.Invoke();
                break;
            }
        }

        // A saved chop kit may have no sequenced steps yet. The legacy converter
        // deliberately omits empty clips, which used to leave CHOPS with no piano
        // roll at all: Redraw() returned before registering the paint callbacks.
        // Open a single editable clip for that track without auto-firing all slices.
        // If a saved 16-step pattern exists, restore its cells once on creation.
        private void EnsureChopsEditable()
        {
            if (projects == null || song == null || song.tracks == null ||
                trackIndex < 0 || trackIndex >= song.tracks.Count) return;
            var track = song.tracks[trackIndex];
            if (track == null || track.kind != TrackKind.Chops) return;
            bool hasApplied = KMusic.KMusicChopState.TryLoadApplied(
                out string path, out float[] starts, out float[] ends);
            bool updateSample = hasApplied && (track.instrument == null ||
                track.instrument.sampleResourcesPath != path ||
                !SameSlices(track.instrument.sliceStart01, starts) ||
                !SameSlices(track.instrument.sliceEnd01, ends));
            if (clip != null && content != null && !updateSample) return;

            if (!ReferenceEquals(projects.CurrentSong, song))
                song = ArrangementEditing.IndependentCopy(song);
            if (song == null) return;
            track = song.tracks[trackIndex];
            if (track == null) return;
            if (track.instrument == null) track.instrument = new InstrumentState();

            if (hasApplied)
            {
                track.instrument.sampleResourcesPath = path;
                track.instrument.sliceStart01 = (float[])starts.Clone();
                track.instrument.sliceEnd01 = (float[])ends.Clone();
            }

            // Repair an existing clip with missing content rather than creating
            // overlapping placements on an imported or partially saved project.
            if (clip != null && content == null)
            {
                clip = ArrangementEditing.FindClip(song, clipId, out _);
                if (clip != null)
                {
                    if (song.contents == null) song.contents = new List<ClipContentData>();
                    content = new ClipContentData {
                        id = ArrangementEditing.Id("content"),
                        kind = ClipKind.Chops,
                        lengthTicks = Math.Max(SongData.TicksPerSixteenth, clip.lengthTicks)
                    };
                    song.contents.Add(content);
                    clip.contentId = content.id;
                }
            }
            else if (clip == null)
            {
                // The track may have saved slices but no arrangement events yet.
                long start = ArrangementEditing.NextFreeStart(track, 0, SongData.TicksPerBar4);
                clip = ArrangementEditing.CreateClip(song, track, start);
                content = clip == null ? null : ArrangementEditing.FindContent(song, clip.contentId);
                if (content != null)
                {
                    // Restore already sequenced legacy chops if present. Slice
                    // markers alone never become automatic note-on events.
                    int[] steps = null;
                    var sampler = FindObjectOfType<KMusicSampleSequencerUI>();
                    if (sampler != null) steps = sampler.CaptureSampleStepsFlat();
                    if (!HasChopSteps(steps))
                    {
                        FindDrumEngine();
                        if (drumEngine != null) steps = drumEngine.CaptureSampleStepsFlat();
                    }
                    if (steps != null)
                    {
                        if (content.chops == null) content.chops = new List<ChopEvent>();
                        for (int step = 0; step < Math.Min(16, steps.Length); step++)
                            if (steps[step] >= 1 && steps[step] <= 16)
                                content.chops.Add(new ChopEvent {
                                    sliceId = steps[step],
                                    startTick = step * SongData.TicksPerSixteenth,
                                    velocity = 100
                                });
                    }
                }
            }
            if (clip != null) clipId = clip.id;
            projects.AcceptArrangementEdit(song);
            OnClipChanged?.Invoke();
        }

        private static bool SameSlices(float[] current, float[] applied)
        {
            if (ReferenceEquals(current, applied)) return true;
            if (current == null || applied == null || current.Length != applied.Length) return false;
            for (int i = 0; i < current.Length; i++)
                if (Mathf.Abs(current[i] - applied[i]) > 0.00001f) return false;
            return true;
        }

        private static bool HasChopSteps(int[] steps)
        {
            if (steps == null) return false;
            for (int i = 0; i < Math.Min(16, steps.Length); i++)
                if (steps[i] >= 1 && steps[i] <= 16) return true;
            return false;
        }

        public void OnShown(int requestedTrack=-1, string requestedClip=null)
        {
            if (!ready) return;
            CloseChordMenu();
            ShowSampler(false);
            ShowDrumDesigner(false);
            if (projects == null) projects = FindObjectOfType<KMusicProjectManager>();
            if (projects == null) return;
            song = projects.GetSongForArrangementEditor();
            // Retain manually selected ACID key/scale while moving between tabs,
            // clips and generator opens. A genuinely different project starts
            // from its own saved song key on the first visit instead.
            if (acidSettingsProjectSlot != projects.CurrentSlot)
            {
                acidSettingsProjectSlot = projects.CurrentSlot;
                acidSettingsInitialized = false;
            }
            if (sampleKeyGuideEnabled && sampleKeyGuideProjectSlot != projects.CurrentSlot)
            {
                sampleKeyGuideEnabled = false;
                sampleKeyGuideFromSample = false;
                sampleKeyGuideSampleId = null;
            }
            if (song == null || song.tracks == null || song.tracks.Count == 0) return;
            if (requestedTrack >= 0 && requestedTrack < song.tracks.Count) trackIndex = requestedTrack;
            trackIndex = Mathf.Clamp(trackIndex,0,song.tracks.Count-1);
            if (!string.IsNullOrEmpty(requestedClip)) clipId = requestedClip;
            LoadClip();
            EnsureChopsEditable();
            FindDrumEngine();
            if (drumEngine != null && song.tracks[0] != null)
            {
                drumEngine.SetDrumFxTempo(song.bpm);
                drumEngine.ApplyDAWDrumDesign(song.tracks[0].instrument != null ?
                    song.tracks[0].instrument.drumDesign : null);
            }
            ZPunkMasterAudioTap.ApplySongSettings(song);
            Redraw(false);
            FocusPatternNotes();
        }
        private void LoadClip()
        {
            clip = ArrangementEditing.FindClip(song,clipId,out TrackData owner);
            if (clip == null || owner != song.tracks[trackIndex])
            {
                clip = null;
                var list = song.tracks[trackIndex].clips;
                if (list != null && list.Count > 0) clip = list[0];
            }
            clipId = clip != null ? clip.id : null;
            content = clip == null ? null : ArrangementEditing.FindContent(song,clip.contentId);
            selectedNote = -1;
            selectedEventRow = -1;
            selectedEventTick = -1;
        }
        private bool Writable()
        {
            if (projects == null || song == null) return false;
            if (!ReferenceEquals(projects.CurrentSong,song))
                song = ArrangementEditing.IndependentCopy(song);
            if (song == null) return false;
            projects.AcceptArrangementEdit(song);
            clip = ArrangementEditing.FindClip(song,clipId,out _);
            content = clip == null ? null : ArrangementEditing.FindContent(song,clip.contentId);
            // Legacy migration can reuse the same content in multiple placements.
            // Give the edited clip independent notes to avoid accidental linked edits.
            if (clip != null && content != null)
            {
                int refs = 0;
                foreach(var t in song.tracks)
                    if (t != null && t.clips != null)
                        foreach(var c in t.clips)
                            if (c != null && c.contentId == content.id) refs++;
                if (refs > 1)
                {
                    content = JsonUtility.FromJson<ClipContentData>(JsonUtility.ToJson(content));
                    content.id = ArrangementEditing.Id("content");
                    song.contents.Add(content);
                    clip.contentId = content.id;
                }
            }
            return true;
        }
        private void Changed(bool rebuild=true, bool preserveViewport=true)
        {
            if (rebuild) Redraw(preserveViewport);
            OnClipChanged?.Invoke();
            // The workspace callback updates the currently sounding transport plan live.
        }
        private void NewClip()
        {
            if (!Writable() || song.tracks == null || trackIndex < 0 ||
                trackIndex >= song.tracks.Count || song.tracks[trackIndex] == null) return;
            var track = song.tracks[trackIndex];
            long start = ArrangementEditing.NextFreeStart(track, 0, SongData.TicksPerBar4);
            var created = ArrangementEditing.CreateClip(song, track, start);
            if (created == null) return;
            // Select the newly created clip immediately. Its content is an
            // independent, blank piano-roll/drum/chop pattern that can be edited.
            clipId = created.id;
            LoadClip();
            Changed(true, false);
            FocusPatternNotes();
        }

        private void StepClip(int direction)
        {
            if (song == null || song.tracks == null || trackIndex < 0 ||
                trackIndex >= song.tracks.Count) return;
            var track = song.tracks[trackIndex];
            if (track == null || track.clips == null || track.clips.Count == 0) return;
            // Navigation is by arrangement position, even when the clip list was
            // populated or reordered by older versions of the app.
            var ordered = new List<ClipData>();
            foreach (var c in track.clips) if (c != null) ordered.Add(c);
            ordered.Sort((a, b) => {
                int cmp = a.startTick.CompareTo(b.startTick);
                return cmp != 0 ? cmp : string.CompareOrdinal(a.id, b.id);
            });
            if (ordered.Count == 0) return;
            int current = ordered.FindIndex(c => c.id == clipId);
            int next = Mathf.Clamp(current + direction, 0, ordered.Count - 1);
            if (current == next) return;
            clipId = ordered[next].id;
            LoadClip();
            Redraw(false);
            FocusPatternNotes();
        }
        private void Save()
        {
            if (projects == null) return;
            projects.SaveProject(projects.CurrentSlot);
            if (info != null) info.text = "SAVED";
        }
        private void SelectTrack(int index)
        {
            CloseChordMenu();
            ShowDrumDesigner(false);
            ShowSampler(false);
            trackIndex = index;
            clipId = null;
            LoadClip();
            EnsureChopsEditable();
            Redraw(false);
            FocusPatternNotes();
        }
        private bool IsAcidNoteTrack => song != null && song.tracks != null &&
            trackIndex >= 0 && trackIndex < song.tracks.Count &&
            song.tracks[trackIndex].kind == TrackKind.Acid;

        private void RefreshAcidNoteButtons()
        {
            if (acidNoteToolbar == null) return;
            bool acidTrack = IsAcidNoteTrack;
            acidNoteToolbar.style.display = acidTrack ? DisplayStyle.Flex : DisplayStyle.None;
            bool selectedValid = acidTrack && content != null && content.kind == ClipKind.Midi &&
                content.notes != null && selectedNote >= 0 && selectedNote < content.notes.Count;
            var note = selectedValid ? content.notes[selectedNote] : null;
            if (accentNoteButton != null)
            {
                accentNoteButton.SetEnabled(note != null);
                accentNoteButton.text = note != null && note.accent ? "ACCENT  ON" : "ACCENT  OFF";
                accentNoteButton.style.backgroundColor = note != null && note.accent ? colors[5] : Raised;
                accentNoteButton.style.color = note != null && note.accent ? Surface : Ink;
            }
            if (slideNoteButton != null)
            {
                slideNoteButton.SetEnabled(note != null);
                slideNoteButton.text = note != null && note.slide ? "SLIDE  ON" : "SLIDE  OFF";
                slideNoteButton.style.backgroundColor = note != null && note.slide ? colors[5] : Raised;
                slideNoteButton.style.color = note != null && note.slide ? Surface : Ink;
            }
        }

        private void ToggleAcidNoteModifier(bool accent)
        {
            if (!IsAcidNoteTrack || content?.notes == null || selectedNote < 0 ||
                selectedNote >= content.notes.Count || !Writable()) return;
            var note = content.notes[selectedNote];
            if (note == null) return;
            if (accent) note.accent = !note.accent;
            else note.slide = !note.slide;
            RefreshAcidNoteButtons();
            Changed(false);
        }

        private bool IsChordTrack => song != null && song.tracks != null &&
            trackIndex >= 0 && trackIndex < song.tracks.Count &&
            (song.tracks[trackIndex].kind == TrackKind.Synth ||
             song.tracks[trackIndex].kind == TrackKind.Pads);

        private bool IsChordDrawing => IsChordTrack && IsMidi && chordDrawEnabled;

        // No OS/Unity PopupField menus: use the app's own visual language and
        // a fixed two-column flyout. Nothing in either menu scrolls sideways.
        private Button CreateChordSelector(string elementName, string tooltip,
            string initialValue, Action onClick, out Label valueLabel)
        {
            var button = new Button(onClick) { name = elementName, tooltip = tooltip };
            button.style.flexDirection = FlexDirection.Row;
            button.style.alignItems = Align.Center;
            button.style.justifyContent = Justify.SpaceBetween;
            button.style.flexGrow = 1.35f;
            button.style.flexShrink = 1;
            button.style.flexBasis = new Length(0, LengthUnit.Pixel);
            button.style.minWidth = 0;
            button.style.height = 43;
            button.style.marginLeft = 2;
            button.style.marginRight = 2;
            button.style.paddingLeft = 8;
            button.style.paddingRight = 6;
            button.style.paddingTop = 0;
            button.style.paddingBottom = 0;
            button.style.backgroundColor = Raised;
            button.style.borderTopLeftRadius = 7;
            button.style.borderTopRightRadius = 7;
            button.style.borderBottomLeftRadius = 7;
            button.style.borderBottomRightRadius = 7;
            button.style.borderTopWidth = 1;
            button.style.borderBottomWidth = 1;
            button.style.borderLeftWidth = 1;
            button.style.borderRightWidth = 1;
            Color outline = new Color(.32f, .42f, .53f);
            button.style.borderTopColor = outline;
            button.style.borderBottomColor = outline;
            button.style.borderLeftColor = outline;
            button.style.borderRightColor = outline;
            button.style.overflow = Overflow.Hidden;

            valueLabel = Txt(initialValue, 11, Ink);
            valueLabel.style.flexGrow = 1;
            valueLabel.style.flexShrink = 1;
            valueLabel.style.minWidth = 0;
            valueLabel.style.whiteSpace = WhiteSpace.NoWrap;
            valueLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            valueLabel.style.unityTextAlign = TextAnchor.MiddleLeft;
            valueLabel.pickingMode = PickingMode.Ignore;
            button.Add(valueLabel);

            var arrow = Txt("▼", 9, Accent);
            arrow.style.width = 13;
            arrow.style.flexShrink = 0;
            arrow.style.marginLeft = 2;
            arrow.style.unityTextAlign = TextAnchor.MiddleCenter;
            arrow.pickingMode = PickingMode.Ignore;
            button.Add(arrow);
            return button;
        }

        private void BuildChordMenuOverlay()
        {
            chordMenuOverlay = new VisualElement { name = "ZPunkChordMenuOverlay" };
            chordMenuOverlay.style.position = Position.Absolute;
            chordMenuOverlay.style.left = 0;
            chordMenuOverlay.style.right = 0;
            chordMenuOverlay.style.top = 0;
            chordMenuOverlay.style.bottom = 0;
            chordMenuOverlay.style.backgroundColor = new Color(0, 0, 0, .25f);
            chordMenuOverlay.style.display = DisplayStyle.None;
            // A tap on the translucent area closes the menu, without also
            // placing a note in the piano roll underneath.
            chordMenuOverlay.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.target != chordMenuOverlay) return;
                CloseChordMenu();
                evt.StopPropagation();
            });
            chordMenuPanel = new VisualElement { name = "ZPunkChordMenuPanel" };
            chordMenuPanel.style.position = Position.Absolute;
            chordMenuPanel.style.flexDirection = FlexDirection.Column;
            chordMenuPanel.style.paddingTop = 8;
            chordMenuPanel.style.paddingBottom = 8;
            chordMenuPanel.style.paddingLeft = 7;
            chordMenuPanel.style.paddingRight = 7;
            chordMenuPanel.style.backgroundColor = new Color(.085f, .12f, .17f);
            chordMenuPanel.style.borderTopLeftRadius = 9;
            chordMenuPanel.style.borderTopRightRadius = 9;
            chordMenuPanel.style.borderBottomLeftRadius = 9;
            chordMenuPanel.style.borderBottomRightRadius = 9;
            chordMenuPanel.style.borderTopWidth = 1;
            chordMenuPanel.style.borderBottomWidth = 1;
            chordMenuPanel.style.borderLeftWidth = 1;
            chordMenuPanel.style.borderRightWidth = 1;
            Color edge = new Color(.36f, .48f, .57f);
            chordMenuPanel.style.borderTopColor = edge;
            chordMenuPanel.style.borderBottomColor = edge;
            chordMenuPanel.style.borderLeftColor = edge;
            chordMenuPanel.style.borderRightColor = edge;
            chordMenuOverlay.Add(chordMenuPanel);
            root.Add(chordMenuOverlay);
        }

        private void CloseChordMenu()
        {
            if (chordMenuOverlay != null)
                chordMenuOverlay.style.display = DisplayStyle.None;
        }

        private void OpenChordMenu(bool qualities)
        {
            if (!IsChordDrawing || chordMenuOverlay == null || chordMenuPanel == null)
                return;
            string[] options = qualities ? ChordQualityLabels : ChordLengthLabels;
            int selected = qualities ? chordQualityIndex : chordLengthIndex;
            var anchor = qualities ? chordQualityButton : chordLengthButton;
            chordMenuPanel.Clear();

            var header = Txt(qualities ? "CHORD TYPE" : "CHORD LENGTH", 11, Accent);
            header.style.unityFontStyleAndWeight = FontStyle.Bold;
            header.style.marginLeft = 5;
            header.style.marginBottom = 6;
            header.pickingMode = PickingMode.Ignore;
            chordMenuPanel.Add(header);

            // Two columns keep all options visible on a phone. Every option
            // remains a full label: no clipped words and no horizontal ScrollView.
            for (int rowIndex = 0; rowIndex < (options.Length + 1) / 2; rowIndex++)
            {
                var row = new VisualElement();
                row.style.flexDirection = FlexDirection.Row;
                row.style.height = 39;
                row.style.marginBottom = 3;
                row.style.flexShrink = 0;
                for (int column = 0; column < 2; column++)
                {
                    int index = rowIndex * 2 + column;
                    if (index >= options.Length) break;
                    int choice = index;
                    bool isSelected = choice == selected;
                    var item = new Button(() =>
                    {
                        if (qualities)
                        {
                            chordQualityIndex = choice;
                            if (chordQualityValue != null) chordQualityValue.text = ChordQualityLabels[choice];
                        }
                        else
                        {
                            chordLengthIndex = choice;
                            if (chordLengthValue != null) chordLengthValue.text = ChordLengthLabels[choice];
                        }
                        CloseChordMenu();
                    }) { text = options[index] };
                    item.style.flexGrow = 1;
                    item.style.flexShrink = 1;
                    item.style.flexBasis = new Length(0, LengthUnit.Pixel);
                    item.style.minWidth = 0;
                    item.style.height = 38;
                    item.style.marginLeft = 2;
                    item.style.marginRight = 2;
                    item.style.paddingLeft = 2;
                    item.style.paddingRight = 2;
                    item.style.fontSize = 12;
                    item.style.whiteSpace = WhiteSpace.NoWrap;
                    item.style.unityTextAlign = TextAnchor.MiddleCenter;
                    item.style.unityFontStyleAndWeight = FontStyle.Bold;
                    item.style.backgroundColor = isSelected ? SelectedColor() : Raised;
                    item.style.color = isSelected ? Accent : Ink;
                    item.style.borderTopLeftRadius = 6;
                    item.style.borderTopRightRadius = 6;
                    item.style.borderBottomLeftRadius = 6;
                    item.style.borderBottomRightRadius = 6;
                    row.Add(item);
                }
                chordMenuPanel.Add(row);
            }

            float width = Mathf.Min(226f, Mathf.Max(0f, root.resolvedStyle.width - 16f));
            float height = 43f + ((options.Length + 1) / 2) * 42f;
            float rootWidth = root.resolvedStyle.width;
            float rootHeight = root.resolvedStyle.height;
            float left = anchor.worldBound.xMin - root.worldBound.xMin;
            left = Mathf.Clamp(left, 8f, Mathf.Max(8f, rootWidth - width - 8f));
            float top = anchor.worldBound.yMax - root.worldBound.yMin + 4f;
            if (top + height > rootHeight - 8f)
                top = anchor.worldBound.yMin - root.worldBound.yMin - height - 4f;
            top = Mathf.Clamp(top, 8f, Mathf.Max(8f, rootHeight - height - 8f));
            chordMenuPanel.style.width = width;
            chordMenuPanel.style.left = left;
            chordMenuPanel.style.top = top;
            chordMenuOverlay.style.display = DisplayStyle.Flex;
            chordMenuOverlay.BringToFront();
        }

        private void RefreshChordDrawToolbar()
        {
            if (chordDrawToolbar == null) return;
            bool available = IsChordTrack;
            chordDrawToolbar.style.display = available ? DisplayStyle.Flex : DisplayStyle.None;
            if (noteDrawButton != null)
            {
                noteDrawButton.style.backgroundColor = !chordDrawEnabled ? SelectedColor() : Raised;
                noteDrawButton.style.color = !chordDrawEnabled ? Accent : Ink;
            }
            if (chordDrawButton != null)
            {
                chordDrawButton.style.backgroundColor = chordDrawEnabled ? SelectedColor() : Raised;
                chordDrawButton.style.color = chordDrawEnabled ? Accent : Ink;
            }
            chordQualityButton?.SetEnabled(available && chordDrawEnabled);
            chordLengthButton?.SetEnabled(available && chordDrawEnabled);
            if (!available || !chordDrawEnabled) CloseChordMenu();
        }

        private string SelectedChordGroup()
        {
            if (!IsChordDrawing || content?.notes == null || selectedNote < 0 ||
                selectedNote >= content.notes.Count) return null;
            return content.notes[selectedNote]?.chordGroupId;
        }

        private bool IsMemberOfSelectedChord(int index)
        {
            if (index == selectedNote && selectedNote >= 0) return true;
            string group = SelectedChordGroup();
            return !string.IsNullOrEmpty(group) && content?.notes != null &&
                index >= 0 && index < content.notes.Count &&
                content.notes[index] != null && content.notes[index].chordGroupId == group;
        }

        // Tap the root in any of the 128 pitch rows; it is never forced to a
        // preset octave. Existing notes remain untouched. The new group is
        // saved with the clip and consists of standard NoteEvent instances.
        // Ensure long chords play their full duration, without overlapping the
        // next arrangement clip on the same track. Used by LEN +/- as well.
        private bool EnsureChordClipDuration(long end)
        {
            if (clip == null || song == null || !IsChordTrack) return false;
            long newLength = Math.Max(clip.lengthTicks, end - Math.Max(0L, clip.sourceOffsetTick));
            if (newLength <= clip.lengthTicks) return true;
            if (clip.startTick + newLength > ArrangementEditing.MaxSongTicks)
            {
                if (info != null) info.text = "CHORD EXCEEDS SONG LIMIT";
                return false;
            }
            var track = song.tracks[trackIndex];
            if (track?.clips != null)
                foreach (var other in track.clips)
                    if (other != null && other != clip && other.lengthTicks > 0 &&
                        other.startTick < clip.startTick + newLength &&
                        other.startTick + other.lengthTicks > clip.startTick + clip.lengthTicks)
                    {
                        if (info != null) info.text = "NO ROOM FOR CHORD  /  EXTEND OR MOVE THE CLIP";
                        return false;
                    }
            clip.lengthTicks = newLength;
            clip.loopEnabled = false;
            ArrangementEditing.ExtendSong(song, clip.startTick + newLength);
            return true;
        }

        private void InsertChord(int rootPitch, int step)
        {
            if (!IsChordDrawing || content == null || clip == null) return;
            int[] intervals = ChordIntervals[Mathf.Clamp(chordQualityIndex, 0, ChordIntervals.Length - 1)];
            if (rootPitch + intervals[intervals.Length - 1] > 127)
            {
                if (info != null) info.text = "CHORD ABOVE MIDI RANGE  /  CHOOSE A LOWER ROOT";
                return;
            }
            long tick = (long)step * quantum;
            long duration = ChordLengthTicks[Mathf.Clamp(chordLengthIndex, 0, ChordLengthTicks.Length - 1)];
            long end = tick + duration;
            // A long chord must be audible in full, not silently cut off at the
            // end of a one-bar arrangement clip. Grow only into free track space.
            long proposedClipLength = Math.Max(clip.lengthTicks, end - Math.Max(0L, clip.sourceOffsetTick));
            if (proposedClipLength > clip.lengthTicks)
            {
                if (clip.startTick + proposedClipLength > ArrangementEditing.MaxSongTicks)
                {
                    if (info != null) info.text = "CHORD EXCEEDS SONG LIMIT";
                    return;
                }
                var track = song.tracks[trackIndex];
                if (track?.clips != null)
                    foreach (var other in track.clips)
                        if (other != null && other != clip && other.lengthTicks > 0 &&
                            other.startTick < clip.startTick + proposedClipLength &&
                            other.startTick + other.lengthTicks > clip.startTick + clip.lengthTicks)
                        {
                            if (info != null) info.text = "NO ROOM FOR CHORD  /  EXTEND OR MOVE THE CLIP";
                            return;
                        }
            }
            if (!Writable() || content == null || clip == null) return;
            if (content.notes == null) content.notes = new List<NoteEvent>();
            string group = ArrangementEditing.Id("chord");
            int firstIndex = content.notes.Count;
            foreach (int interval in intervals)
                content.notes.Add(new NoteEvent {
                    pitch = rootPitch + interval, startTick = tick,
                    durationTicks = duration, velocity = velocity,
                    chordGroupId = group
                });
            content.lengthTicks = Math.Max(content.lengthTicks, end);
            if (proposedClipLength > clip.lengthTicks) EnsureChordClipDuration(end);
            selectedNote = firstIndex;
            selectedEventRow = -1;
            selectedEventTick = -1;
            Changed();
            var focusedClip = clipId;
            int focusedIndex = firstIndex;
            scroller?.schedule.Execute(() => {
                if (clipId == focusedClip && selectedNote == focusedIndex)
                    FocusSelectedChord(focusedIndex);
            }).ExecuteLater(30);
        }

        private void ChangeLength(int direction)
        {
            if (content == null || !Writable()) return;
            if (content.kind == ClipKind.Midi && content.notes != null && selectedNote >= 0 && selectedNote < content.notes.Count)
            {
                var n = content.notes[selectedNote];
                if (n == null) return;
                string group = SelectedChordGroup();
                if (string.IsNullOrEmpty(group))
                    n.durationTicks = Math.Max(quantum, n.durationTicks + direction * quantum);
                else
                {
                    long desiredEnd = 0L;
                    foreach (var member in content.notes)
                        if (member != null && member.chordGroupId == group)
                            desiredEnd = Math.Max(desiredEnd, member.startTick +
                                Math.Max(quantum, member.durationTicks + direction * quantum));
                    if (!EnsureChordClipDuration(desiredEnd)) return;
                    foreach (var member in content.notes)
                        if (member != null && member.chordGroupId == group)
                            member.durationTicks = Math.Max(quantum, member.durationTicks + direction * quantum);
                }
                long noteEnd = n.startTick + n.durationTicks;
                content.lengthTicks = Math.Max(content.lengthTicks, noteEnd);
                Changed();
            }
            else if (clip != null)
            {
                ArrangementEditing.Resize(song,clip,Math.Max(quantum,clip.lengthTicks + direction * SongData.TicksPerBar4));
                if (content.lengthTicks < clip.lengthTicks) content.lengthTicks = clip.lengthTicks;
                Changed();
            }
        }
        private void DeleteSelectedNote()
        {
            if (content == null || content.kind != ClipKind.Midi || selectedNote < 0 ||
                content.notes == null || selectedNote >= content.notes.Count || !Writable()) return;
            var selected = content.notes[selectedNote];
            if (selected == null) return;
            // An earlier version could stack a manual note directly over a humanized
            // generated note. Delete the complete same-pitch, same-step stack, rather
            // than leaving an inaccessible note underneath the visible one.
            int pitch = selected.pitch;
            int step = GridStepForTick(selected.startTick);
            string group = SelectedChordGroup();
            for (int i = content.notes.Count - 1; i >= 0; i--)
            {
                var note = content.notes[i];
                if (note != null && (!string.IsNullOrEmpty(group)
                    ? note.chordGroupId == group
                    : note.pitch == pitch && GridStepForTick(note.startTick) == step))
                    content.notes.RemoveAt(i);
            }
            selectedNote = -1;
            Changed();
        }
        // The slider edits the selected event, or acts as the brush velocity when
        // nothing is selected. Selecting never toggles/deletes the event.
        private void RefreshVelocityRail()
        {
            float percent = Mathf.Clamp(velocity, 1, 127) / 127f * 100f;
            if (velocityFill != null) velocityFill.style.width = new Length(percent, LengthUnit.Percent);
            if (velocityThumb != null) velocityThumb.style.left = new Length(percent, LengthUnit.Percent);
            if (selectedInfo != null) selectedInfo.text = velocity.ToString();
            RefreshAcidNoteButtons();
        }
        private void SelectNoteVelocity(int index)
        {
            if (content == null || content.notes == null || index < 0 || index >= content.notes.Count ||
                content.notes[index] == null) return;
            selectedNote = index;
            selectedEventRow = -1;
            selectedEventTick = -1;
            velocity = Mathf.Clamp(content.notes[index].velocity, 1, 127);
            RefreshVelocityRail();
            RefreshVelocityDisplays();
        }
        private bool HasStepEvent(int row, long tick)
        {
            if (content == null) return false;
            int step = GridStepForTick(tick);
            if (content.kind == ClipKind.Drums) return FindDrumStepIndex(row, step) >= 0;
            if (content.kind == ClipKind.Chops) return FindChopStepIndex(row, step) >= 0;
            return false;
        }
        private void SelectStepVelocity(int row, long tick)
        {
            if (content == null) return;
            int step = GridStepForTick(tick);
            int index = content.kind == ClipKind.Drums ? FindDrumStepIndex(row, step) :
                        content.kind == ClipKind.Chops ? FindChopStepIndex(row, step) : -1;
            if (index < 0) return;
            // Keep the REAL (humanized) tick for subsequent velocity updates.
            // Replacing it with the grid tick would make the selected event
            // inaccessible to ChangeVelocity().
            long actualTick;
            if (content.kind == ClipKind.Drums)
            {
                var hit = content.drums[index];
                actualTick = hit.startTick;
                velocity = Mathf.Clamp(hit.velocity, 1, 127);
            }
            else
            {
                var hit = content.chops[index];
                actualTick = hit.startTick;
                velocity = Mathf.Clamp(hit.velocity, 1, 127);
            }
            selectedNote = -1;
            selectedEventRow = row;
            selectedEventTick = actualTick;
            RefreshVelocityRail();
            RefreshVelocityDisplays();
        }
        private void RefreshVelocityDisplays()
        {
            foreach (var display in velocityDisplays)
            {
                bool selected = IsMidi ? IsMemberOfSelectedChord(display.noteIndex) :
                    display.row == selectedEventRow && display.tick == selectedEventTick && selectedEventRow >= 0;
                display.cell.style.backgroundColor = selected ? Accent : colors[Mathf.Min(trackIndex, colors.Length - 1)];
                display.cell.style.borderBottomWidth = selected ? 2 : 0;
                display.cell.style.borderBottomColor = Ink;
                float span = Mathf.Max(1f, display.width - 6f);
                display.meter.style.width = Mathf.Max(1f, span * Mathf.Clamp(display.velocity, 1, 127) / 127f);
                if (display.number != null) display.number.text = Mathf.Clamp(display.velocity, 1, 127).ToString();
            }
        }
        private void ChangeVelocity()
        {
            if (selectedInfo != null) selectedInfo.text = velocity.ToString();
            if (content == null) return;
            if (content.kind == ClipKind.Midi)
            {
                if (selectedNote < 0 || content.notes == null || selectedNote >= content.notes.Count ||
                    content.notes[selectedNote] == null || !Writable()) return;
                string group = SelectedChordGroup();
                if (string.IsNullOrEmpty(group)) content.notes[selectedNote].velocity = velocity;
                else foreach (var member in content.notes)
                    if (member != null && member.chordGroupId == group) member.velocity = velocity;
            }
            else if (content.kind == ClipKind.Drums)
            {
                if (content.drums == null || selectedEventRow < 0) return;
                var hit = content.drums.Find(d => d != null && d.lane == selectedEventRow && d.startTick == selectedEventTick);
                if (hit == null || hit.velocity == velocity || !Writable()) return;
                hit = content.drums.Find(d => d != null && d.lane == selectedEventRow && d.startTick == selectedEventTick);
                if (hit == null) return;
                hit.velocity = velocity;
            }
            else if (content.kind == ClipKind.Chops)
            {
                if (content.chops == null || selectedEventRow < 0) return;
                var hit = content.chops.Find(d => d != null && d.sliceId == selectedEventRow + 1 && d.startTick == selectedEventTick);
                if (hit == null || hit.velocity == velocity || !Writable()) return;
                hit = content.chops.Find(d => d != null && d.sliceId == selectedEventRow + 1 && d.startTick == selectedEventTick);
                if (hit == null) return;
                hit.velocity = velocity;
            }
            else return;
            // Update the active cell without rebuilding the piano roll while the
            // slider is moving; the scroll position and touch gesture stay put.
            foreach (var display in velocityDisplays)
            {
                bool selected = IsMidi ? IsMemberOfSelectedChord(display.noteIndex) :
                    display.row == selectedEventRow && display.tick == selectedEventTick && selectedEventRow >= 0;
                if (selected) display.velocity = velocity;
            }
            RefreshVelocityDisplays();
            OnClipChanged?.Invoke();
        }
        private bool IsMidi => content != null && content.kind == ClipKind.Midi;
        private int RowCount => IsMidi ? MidiRows : content != null && content.kind == ClipKind.Chops ? 16 : 8;
        private int PitchForRow(int row) => Mathf.Clamp(127 - row, 0, 127);
        private int RowForPitch(int pitch) => 127 - pitch;

        private static bool IsGuidePitch(int pitch, int tonic, bool minor)
        {
            int interval = ((pitch - tonic) % 12 + 12) % 12;
            // Major 0,2,4,5,7,9,11; natural minor 0,2,3,5,7,8,10.
            int intervals = minor ? 0x5AD : 0xAB5;
            return ((intervals >> interval) & 1) != 0;
        }

        // Colors are intentionally restrained and do not obscure note velocities.
        // Recolor existing rows without rebuilding the clip or resetting its viewport.
        private void ApplySampleKeyGuide()
        {
            bool enabled = sampleKeyGuideEnabled && IsMidi && song != null &&
                song.tracks != null && trackIndex >= 0 && trackIndex < song.tracks.Count &&
                (song.tracks[trackIndex].kind == TrackKind.Bass ||
                 song.tracks[trackIndex].kind == TrackKind.Synth ||
                 song.tracks[trackIndex].kind == TrackKind.Pads ||
                 song.tracks[trackIndex].kind == TrackKind.Acid);
            for (int row = 0; row < pitchRowBackgrounds.Count; row++)
            {
                int pitch = PitchForRow(row);
                bool inKey = enabled && IsGuidePitch(pitch, sampleKeyGuideTonic, sampleKeyGuideMinor);
                bool tonic = inKey && pitch % 12 == sampleKeyGuideTonic;
                pitchRowBackgrounds[row].style.backgroundColor = tonic
                    ? new Color(.125f, .215f, .213f)
                    : inKey ? new Color(.108f, .174f, .182f)
                    : row % 2 == 0 ? new Color(.11f, .145f, .19f) : new Color(.09f, .12f, .16f);
                if (row < pitchRowLabels.Count)
                    pitchRowLabels[row].style.color = tonic ? Accent :
                        inKey ? new Color(.68f, .82f, .79f) : pitch % 12 == 0 ? Accent : Muted;
            }
        }

        // Only sample-derived guides follow live semitone changes; manually
        // selected keys remain independent of the sample player's state.
        private void FollowPitchedSampleKey()
        {
            if (!sampleKeyGuideEnabled || !sampleKeyGuideFromSample || samplePlayer == null) return;
            // Selecting a different sample must not silently transfer the old guide.
            string sampleId = samplePlayer.DawSampleFolder + "/" + samplePlayer.DawSampleName;
            if (sampleId != sampleKeyGuideSampleId)
            {
                sampleKeyGuideEnabled = false;
                sampleKeyGuideFromSample = false;
                sampleKeyGuideSampleId = null;
                ApplySampleKeyGuide();
                RefreshClipSampleKeyReference();
                return;
            }
            if (!samplePlayer.DawSampleKeyAvailable) return;
            int tonic = samplePlayer.DawPitchedKeyTonic;
            bool minor = samplePlayer.DawSampleKeyMinor;
            if (tonic == sampleKeyGuideTonic && minor == sampleKeyGuideMinor) return;
            sampleKeyGuideTonic = tonic;
            sampleKeyGuideMinor = minor;
            ApplySampleKeyGuide();
            RefreshClipSampleKeyReference();
        }

        private void SyncFixedRuler()
        {
            if (rulerContent == null || scroller == null) return;
            rulerContent.style.translate = new Translate(
                new Length(-scroller.scrollOffset.x, LengthUnit.Pixel),
                new Length(0f, LengthUnit.Pixel), 0f);
        }

        // Keep the fixed label column aligned with the vertically scrolling notes.
        // Translation avoids relaying out the 128-row MIDI keyboard on each scroll.
        private void SyncPianoRollLabels()
        {
            if (labelColumn == null || scroller == null) return;
            labelColumn.style.translate = new Translate(
                new Length(0f, LengthUnit.Pixel),
                new Length(-scroller.scrollOffset.y, LengthUnit.Pixel), 0f);
        }

        // Auto-frame the populated pitch area on pattern load or generation.
        // Never invoke this from an ordinary paint/drag redraw: doing so would
        // fight the user's manual scrolling and touch gestures.
        private void FocusPatternNotes(bool afterGeneration = false)
        {
            if (scroller == null || !IsMidi) return;
            if (content.notes == null || content.notes.Count == 0)
            {
                ScrollToOctave();
                return;
            }

            var noteRows = new List<int>();
            foreach (var note in content.notes)
                if (note != null) noteRows.Add(RowForPitch(Mathf.Clamp(note.pitch, 0, 127)));
            if (noteRows.Count == 0) { ScrollToOctave(); return; }
            noteRows.Sort();
            int revision = ++noteFocusRevision;
            var intendedScroller = scroller;
            string focusedClip = clipId;
            // A freshly generated clip changes the scroll content's geometry.
            // One first-frame scroll can be clamped by UI Toolkit before it
            // computes the new content height; repeat after layout settles.
            Action applyFocus = () =>
            {
                if (clipId != focusedClip) return;
                if (revision != noteFocusRevision || scroller != intendedScroller || !IsMidi) return;
                float height = intendedScroller.contentViewport.resolvedStyle.height;
                if (height < RowH * 2f) height = intendedScroller.resolvedStyle.height;
                if (height < RowH * 2f) height = RowH * 7f;
                int rowsVisible = Mathf.Max(2, Mathf.FloorToInt((height - 25f) / RowH));

                // Fit all notes if possible. Otherwise show the densest group
                // of notes within the visible rows (not merely the first note).
                int top = noteRows[0], bottom = noteRows[noteRows.Count - 1];
                if (bottom - top >= rowsVisible - 2)
                {
                    int bestStart = 0, bestEnd = 0, end = 0;
                    for (int start = 0; start < noteRows.Count; start++)
                    {
                        if (end < start) end = start;
                        while (end + 1 < noteRows.Count &&
                               noteRows[end + 1] - noteRows[start] <= rowsVisible - 2)
                            end++;
                        if (end - start > bestEnd - bestStart)
                        {
                            bestStart = start;
                            bestEnd = end;
                        }
                    }
                    top = noteRows[bestStart];
                    bottom = noteRows[bestEnd];
                }
                float middle = 0.5f * (top + bottom);
                float y = Mathf.Max(0f, 25f + (middle + .5f) * RowH - height * .5f);
                float maxY = Mathf.Max(0f, 25f + MidiRows * RowH - height);
                // Also bring a pattern's first note into horizontal view if the
                // previous clip was scrolled to a different part of the timeline.
                long earliestTick = long.MaxValue;
                foreach (var note in content.notes)
                    if (note != null && note.startTick < earliestTick) earliestTick = note.startTick;
                float earliestX = earliestTick == long.MaxValue ? 0f : (float)earliestTick / quantum * StepW;
                float visibleWidth = intendedScroller.contentViewport.resolvedStyle.width;
                if (visibleWidth < StepW * 2f) visibleWidth = StepW * 8f;
                float gridWidth = steps * StepW;
                float maxX = Mathf.Max(0f, gridWidth - visibleWidth);
                float x = Mathf.Clamp(earliestX - StepW, 0f, maxX);
                intendedScroller.scrollOffset = new Vector2(x, Mathf.Min(y, maxY));
                SyncPianoRollLabels();
                SyncFixedRuler();
                int pitch = Mathf.Clamp(127 - Mathf.RoundToInt(middle), 0, 127);
                octave = Mathf.Clamp(pitch / 12 - 1, -1, 9);
                SyncMidiNoteTouchTargets();
            };
            intendedScroller.schedule.Execute(applyFocus).ExecuteLater(30);
            if (afterGeneration)
                intendedScroller.schedule.Execute(applyFocus).ExecuteLater(160);
        }

        // Full 128-note keyboard: OCT buttons scroll vertically, not horizontally.
        private void ScrollToOctave()
        {
            // Manual octave navigation must supersede an older scheduled auto-focus.
            ++noteFocusRevision;
            if (scroller == null || !IsMidi) return;
            int desiredTopPitch = Mathf.Clamp((octave + 2) * 12 - 1, 0, 127);
            float y = 25f + (127 - desiredTopPitch) * RowH;
            scroller.schedule.Execute(() =>
            {
                if (scroller != null && IsMidi)
                {
                    scroller.scrollOffset = new Vector2(scroller.scrollOffset.x, y);
                    SyncPianoRollLabels();
                }
            }).ExecuteLater(0);
        }
        private float EditorHeight => RowCount * RowH;
        private int QuantizedStep(float x) => Mathf.Clamp(Mathf.FloorToInt(Mathf.Max(0,x)/StepW),0,steps-1);
        private long TickAt(float x) => QuantizedStep(x)*quantum;
        private int RowAt(float y) => Mathf.Clamp(Mathf.FloorToInt(y/RowH),0,RowCount-1);
        // Generator humanization deliberately offsets notes slightly from each
        // sixteenth-note boundary. The editor must identify events by their musical
        // cell, not by exact tick equality, or tapping an existing event creates a
        // second one on top of it. No event timing is changed by these lookups.
        private int GridStepForTick(long tick)
        {
            return (int)Math.Max(0L, (Math.Max(0L, tick) + quantum / 2) / quantum);
        }

        private int FindDrumStepIndex(int row, int step)
        {
            if (content?.drums == null) return -1;
            int best = -1;
            long distance = long.MaxValue;
            long gridTick = (long)step * quantum;
            for (int i = 0; i < content.drums.Count; i++)
            {
                var hit = content.drums[i];
                if (hit == null || hit.lane != row || GridStepForTick(hit.startTick) != step) continue;
                long delta = Math.Abs(hit.startTick - gridTick);
                if (delta < distance) { best = i; distance = delta; }
            }
            return best;
        }

        private int FindChopStepIndex(int row, int step)
        {
            if (content?.chops == null) return -1;
            int best = -1;
            long distance = long.MaxValue;
            long gridTick = (long)step * quantum;
            for (int i = 0; i < content.chops.Count; i++)
            {
                var hit = content.chops[i];
                if (hit == null || hit.sliceId != row + 1 || GridStepForTick(hit.startTick) != step) continue;
                long delta = Math.Abs(hit.startTick - gridTick);
                if (delta < distance) { best = i; distance = delta; }
            }
            return best;
        }

        private int FindNote(int pitch, long tick)
        {
            if (content?.notes == null) return -1;
            int step = GridStepForTick(tick);
            // Prefer a note starting in this step over a note sustained from an
            // earlier one. Scan in reverse to handle legacy duplicate stacks.
            for (int i = content.notes.Count - 1; i >= 0; i--)
            {
                var n = content.notes[i];
                if (n != null && n.pitch == pitch && GridStepForTick(n.startTick) == step)
                    return i;
            }
            // A longer generated MIDI note also occupies subsequent grid cells.
            // Check intersection with the cell, including microtimed attacks.
            long cellEnd = tick + quantum;
            for (int i = content.notes.Count - 1; i >= 0; i--)
            {
                var n = content.notes[i];
                if (n != null && n.pitch == pitch &&
                    n.startTick < cellEnd && n.startTick + n.durationTicks > tick)
                    return i;
            }
            return -1;
        }

        // Resolve taps against the *drawn* rectangle before falling back to a
        // quantized grid step. Humanized hits can straddle the next cell by a
        // couple of pixels; selecting from the artwork prevents a second note
        // being inserted when the user taps that visible trailing edge.
        private int HitStepAtVisualPosition(int row, int defaultStep, float x)
        {
            if (content == null) return defaultStep;
            const float hitSlop = 1.5f;
            float nearest = float.MaxValue;
            int foundStep = -1;
            if (content.kind == ClipKind.Drums && content.drums != null)
            {
                foreach (var hit in content.drums)
                {
                    if (hit == null || hit.lane != row) continue;
                    float left = (float)hit.startTick / quantum * StepW + 1f;
                    float width = Mathf.Max(13f, StepW - 2f);
                    if (x < left - hitSlop || x > left + width + hitSlop) continue;
                    float distance = Mathf.Abs(x - (left + width * .5f));
                    if (distance >= nearest) continue;
                    nearest = distance;
                    foundStep = GridStepForTick(hit.startTick);
                }
            }
            else if (content.kind == ClipKind.Chops && content.chops != null)
            {
                foreach (var hit in content.chops)
                {
                    if (hit == null || hit.sliceId != row + 1) continue;
                    float left = (float)hit.startTick / quantum * StepW + 1f;
                    float width = Mathf.Max(13f, StepW - 2f);
                    if (x < left - hitSlop || x > left + width + hitSlop) continue;
                    float distance = Mathf.Abs(x - (left + width * .5f));
                    if (distance >= nearest) continue;
                    nearest = distance;
                    foundStep = GridStepForTick(hit.startTick);
                }
            }
            else if (content.kind == ClipKind.Midi && content.notes != null)
            {
                int pitch = PitchForRow(row);
                foreach (var note in content.notes)
                {
                    if (note == null || note.pitch != pitch) continue;
                    float left = (float)note.startTick / quantum * StepW + 1f;
                    float width = Mathf.Max(13f, (float)note.durationTicks / quantum * StepW - 2f);
                    if (x < left - hitSlop || x > left + width + hitSlop) continue;
                    float distance = Mathf.Abs(x - (left + width * .5f));
                    if (distance >= nearest) continue;
                    nearest = distance;
                    foundStep = GridStepForTick(note.startTick);
                }
            }
            return foundStep >= 0 ? foundStep : defaultStep;
        }

        private void ToggleGrid(int row,int step)
        {
            if (content == null || !Writable()) return;
            long tick = step * quantum;
            if (content.kind == ClipKind.Drums)
            {
                if (content.drums == null) content.drums = new List<DrumEvent>();
                int i = FindDrumStepIndex(row, step);
                if (i >= 0)
                {
                    // Clear any pre-existing duplicate stack in this musical cell.
                    for (int j = content.drums.Count - 1; j >= 0; j--)
                    {
                        var hit = content.drums[j];
                        if (hit != null && hit.lane == row && GridStepForTick(hit.startTick) == step)
                            content.drums.RemoveAt(j);
                    }
                    if (selectedEventRow == row && GridStepForTick(selectedEventTick) == step)
                    { selectedEventRow = -1; selectedEventTick = -1; }
                }
                else
                {
                    content.drums.Add(new DrumEvent { lane = row, startTick = tick, velocity = velocity, legacyVelocityTier = 2 });
                    selectedEventRow = row;
                    selectedEventTick = tick;
                }
                selectedNote = -1;
            }
            else if (content.kind == ClipKind.Chops)
            {
                if (content.chops == null) content.chops = new List<ChopEvent>();
                int i = FindChopStepIndex(row, step);
                if (i >= 0)
                {
                    for (int j = content.chops.Count - 1; j >= 0; j--)
                    {
                        var hit = content.chops[j];
                        if (hit != null && hit.sliceId == row + 1 && GridStepForTick(hit.startTick) == step)
                            content.chops.RemoveAt(j);
                    }
                    if (selectedEventRow == row && GridStepForTick(selectedEventTick) == step)
                    { selectedEventRow = -1; selectedEventTick = -1; }
                }
                else
                {
                    content.chops.Add(new ChopEvent { sliceId = row + 1, startTick = tick, velocity = velocity });
                    selectedEventRow = row;
                    selectedEventTick = tick;
                }
                selectedNote = -1;
            }
            else
            {
                if (content.notes == null) content.notes = new List<NoteEvent>();
                int pitch = PitchForRow(row);
                int existing = FindNote(pitch, tick);
                if (existing >= 0)
                {
                    var hit = content.notes[existing];
                    int startingStep = GridStepForTick(hit.startTick);
                    // Remove a legacy pile of same-pitch notes that start on the
                    // same step; tapping must not reveal another hidden copy.
                    for (int i = content.notes.Count - 1; i >= 0; i--)
                    {
                        var n = content.notes[i];
                        if (n != null && n.pitch == pitch && GridStepForTick(n.startTick) == startingStep)
                            content.notes.RemoveAt(i);
                    }
                    selectedNote = -1;
                }
                else
                {
                    content.notes.Add(new NoteEvent { pitch = pitch, startTick = tick, durationTicks = quantum, velocity = velocity });
                    selectedNote = content.notes.Count - 1;
                }
                selectedEventRow = -1;
            }
            content.lengthTicks = Math.Max(content.lengthTicks, tick + quantum);
            Changed();
        }

        // Use the grid's local coordinates, which continue advancing correctly
        // while edge auto-scroll shifts the viewport beneath a stationary finger.
        // The starting drag mode is fixed on pointer-down: body=move, end=resize.
        private void UpdateMidiDragPreview(Drag d, Vector2 localPosition)
        {
            if (d == null) return;
            float dx = localPosition.x - d.start.x;
            float dy = localPosition.y - d.start.y;
            int stepDelta = Mathf.RoundToInt(dx / StepW);
            long gridEnd = Math.Max(quantum, (long)steps * quantum);
            long newStart = d.startTick;
            long newDuration = d.duration;
            int newPitch = d.pitch;

            if (d.mode == MidiDragMode.ResizeEnd)
            {
                // Only the right end moves. The start and pitch stay anchored.
                newDuration = Math.Max(quantum, Math.Min(gridEnd - d.startTick,
                    d.duration + stepDelta * quantum));
            }
            else // MidiDragMode.Move
            {
                // Move the WHOLE note by sixteenth-note steps; length stays fixed.
                // The same gesture can also shift pitch without moving the viewport.
                long maxStart = Math.Max(0L, gridEnd - d.duration);
                newStart = Math.Max(0L, Math.Min(maxStart,
                    d.startTick + stepDelta * quantum));
                newPitch = Mathf.Clamp(d.pitch - Mathf.RoundToInt(dy / RowH), 0, 127);
            }

            if (d.chordMembers != null && d.chordMembers.Count > 0)
            {
                long minTick = long.MaxValue, maxEnd = 0L;
                int minPitch = 127, maxPitch = 0;
                foreach (var member in d.chordMembers)
                {
                    minTick = Math.Min(minTick, member.tick);
                    maxEnd = Math.Max(maxEnd, member.tick + member.duration);
                    minPitch = Math.Min(minPitch, member.pitch);
                    maxPitch = Math.Max(maxPitch, member.pitch);
                }
                long deltaTick = 0L, deltaDuration = 0L;
                int deltaPitch = 0;
                if (d.mode == MidiDragMode.Move)
                {
                    deltaTick = Math.Max(-minTick, Math.Min(gridEnd - maxEnd,
                        (long)stepDelta * quantum));
                    deltaPitch = Mathf.Clamp(-Mathf.RoundToInt(dy / RowH), -minPitch, 127 - maxPitch);
                }
                else
                {
                    long shortest = long.MaxValue;
                    foreach (var member in d.chordMembers) shortest = Math.Min(shortest, member.duration);
                    deltaDuration = Math.Max(quantum - shortest, Math.Min(gridEnd - maxEnd,
                        (long)stepDelta * quantum));
                }
                foreach (var member in d.chordMembers)
                {
                    member.candidateTick = member.tick + deltaTick;
                    member.candidateDuration = member.duration + deltaDuration;
                    member.candidatePitch = member.pitch + deltaPitch;
                    PositionMidiPreview(member.display, member.candidateTick,
                        member.candidateDuration, member.candidatePitch);
                }
                newStart = d.startTick + deltaTick;
                newDuration = d.duration + deltaDuration;
                newPitch = d.pitch + deltaPitch;
            }
            d.candidateTick = newStart;
            d.candidateDuration = newDuration;
            d.candidatePitch = newPitch;
            if (d.chordMembers != null) { SyncMidiNoteTouchTargets(); return; }
            if (d.preview == null) return;
            float width = Mathf.Max(13f, (float)newDuration / quantum * StepW - 2f);
            d.preview.style.left = (float)newStart / quantum * StepW + 1f;
            d.preview.style.top = RowForPitch(newPitch) * RowH + 4f;
            d.preview.style.width = width;
            SyncMidiNoteTouchTargets();
            // Keep the velocity meter and number visually coherent as the note changes width.
            if (d.display != null)
            {
                d.display.meter.style.width = Mathf.Max(1f, (width - 6f) *
                    Mathf.Clamp(d.display.velocity, 1, 127) / 127f);
                if (d.display.number != null)
                    d.display.number.style.display = width >= 28f ? DisplayStyle.Flex : DisplayStyle.None;
            }
        }

        private static void PositionMidiPreview(VelocityDisplay display, long tick, long duration, int pitch)
        {
            if (display == null || display.cell == null) return;
            float width = Mathf.Max(13f, (float)duration / SongData.TicksPerSixteenth * StepW - 2f);
            display.cell.style.left = (float)tick / SongData.TicksPerSixteenth * StepW + 1f;
            display.cell.style.top = (127 - pitch) * RowH + 4f;
            display.cell.style.width = width;
            display.meter.style.width = Mathf.Max(1f, (width - 6f) *
                Mathf.Clamp(display.velocity, 1, 127) / 127f);
            if (display.number != null)
                display.number.style.display = width >= 28f ? DisplayStyle.Flex : DisplayStyle.None;
        }

        private void RestoreMidiDragPreview(Drag d)
        {
            if (d?.chordMembers != null)
            {
                foreach (var member in d.chordMembers)
                {
                    member.candidateTick = member.tick;
                    member.candidateDuration = member.duration;
                    member.candidatePitch = member.pitch;
                    PositionMidiPreview(member.display, member.tick, member.duration, member.pitch);
                }
                SyncMidiNoteTouchTargets();
                return;
            }
            if (d == null || d.preview == null) return;
            float width = Mathf.Max(13f, (float)d.duration / quantum * StepW - 2f);
            d.preview.style.left = (float)d.startTick / quantum * StepW + 1f;
            d.preview.style.top = RowForPitch(d.pitch) * RowH + 4f;
            d.preview.style.width = width;
            if (d.display != null)
            {
                d.display.meter.style.width = Mathf.Max(1f, (width - 6f) *
                    Mathf.Clamp(d.display.velocity, 1, 127) / 127f);
                if (d.display.number != null)
                    d.display.number.style.display = width >= 28f ? DisplayStyle.Flex : DisplayStyle.None;
            }
        }

        // UI Toolkit's ScrollView has its own touch pan manipulator. Capture on
        // the note plane and reassert only this intentional offset while editing,
        // so vertical note dragging never scrolls the entire 128-key keyboard.
        private void KeepMidiDragViewportLocked()
        {
            if (drag == null || scroller == null) return;
            if ((scroller.scrollOffset - drag.allowedScrollOffset).sqrMagnitude > .1f)
                scroller.scrollOffset = drag.allowedScrollOffset;
        }

        private static float MidiEdgeScrollVelocity(float pos, float min, float max)
        {
            if (pos < min + MidiEdgeScrollZone)
                return -Mathf.Clamp01((min + MidiEdgeScrollZone - pos) / MidiEdgeScrollZone) *
                    MidiMaxEdgeScrollPerTick;
            if (pos > max - MidiEdgeScrollZone)
                return Mathf.Clamp01((pos - (max - MidiEdgeScrollZone)) / MidiEdgeScrollZone) *
                    MidiMaxEdgeScrollPerTick;
            return 0f;
        }

        // Runs during an active gesture even when the finger is held stationary
        // at the viewport's edge (there may be no further PointerMoveEvents).
        private void AutoScrollMidiDrag(Drag d, VisualElement plane)
        {
            if (!ReferenceEquals(drag, d) || !d.moved || scroller == null ||
                scroller.contentViewport == null || plane == null) return;
            var bounds = scroller.contentViewport.worldBound;
            if (bounds.width <= 1f || bounds.height <= 1f) return;
            float sx = 0f, sy = 0f;
            // Body drags can cross both time and pitch boundaries. Resize handles
            // only need horizontal edge scrolling; never pan vertically while resizing.
            sx = MidiEdgeScrollVelocity(d.latestWorldPosition.x, bounds.xMin, bounds.xMax);
            if (d.mode == MidiDragMode.Move)
                sy = MidiEdgeScrollVelocity(d.latestWorldPosition.y, bounds.yMin, bounds.yMax);
            if (Mathf.Abs(sx) < .01f && Mathf.Abs(sy) < .01f) return;
            float maxX = Mathf.Max(0f, steps * StepW - bounds.width);
            float maxY = Mathf.Max(0f, 25f + EditorHeight - bounds.height);
            Vector2 desired = new Vector2(
                Mathf.Clamp(d.allowedScrollOffset.x + sx, 0f, maxX),
                Mathf.Clamp(d.allowedScrollOffset.y + sy, 0f, maxY));
            if ((desired - d.allowedScrollOffset).sqrMagnitude <= .01f) return;
            d.allowedScrollOffset = desired;
            scroller.scrollOffset = desired;
            SyncPianoRollLabels();
            SyncFixedRuler();
            UpdateMidiDragPreview(d, MidiWorldToPlane(d.latestWorldPosition));
            SyncMidiNoteTouchTargets();
        }

        // Coordinates are measured in the moving grid's own space. Using the
        // transparent overlay coordinates plus the ScrollView offset keeps note
        // movement accurate even while the viewport follows the finger.
        private Vector2 MidiWorldToPlane(Vector2 worldPosition)
        {
            if (noteTouchLayer == null || scroller == null) return worldPosition;
            Vector2 position = noteTouchLayer.WorldToLocal(worldPosition);
            return position + scroller.scrollOffset;
        }

        // Frame a tapped MIDI note when it sits partly outside the viewport.
        // While the user drags, the edge-scroll scheduler follows as needed.
        private void FocusSelectedMidiNote(int index)
        {
            if (scroller == null || scroller.contentViewport == null || !IsMidi ||
                content?.notes == null || index < 0 || index >= content.notes.Count) return;
            var note = content.notes[index];
            if (note == null) return;
            float vw = scroller.contentViewport.resolvedStyle.width;
            float vh = scroller.contentViewport.resolvedStyle.height;
            if (vw < StepW || vh < RowH) return;
            float nx = (float)note.startTick / quantum * StepW;
            float ny = 25f + RowForPitch(note.pitch) * RowH;
            var offset = scroller.scrollOffset;
            const float xMargin = 20f;
            const float yMargin = 18f;
            float x = offset.x, y = offset.y;
            if (nx < x + xMargin) x = nx - xMargin;
            else if (nx > x + vw - xMargin - StepW) x = nx - vw + xMargin + StepW;
            // For a long note, favour its beginning rather than scrolling
            // to its right edge and losing the selected pitch on-screen.
            if (ny < y + yMargin) y = ny - yMargin;
            else if (ny + RowH > y + vh - yMargin) y = ny + RowH - vh + yMargin;
            float maxX = Mathf.Max(0f, steps * StepW - vw);
            float maxY = Mathf.Max(0f, 25f + EditorHeight - vh);
            var desired = new Vector2(Mathf.Clamp(x, 0f, maxX), Mathf.Clamp(y, 0f, maxY));
            if ((desired - offset).sqrMagnitude > 0.25f)
            {
                scroller.scrollOffset = desired;
                SyncPianoRollLabels();
                SyncFixedRuler();
                SyncMidiNoteTouchTargets();
            }
        }

        private void FocusSelectedChord(int index)
        {
            FocusSelectedMidiNote(index);
            if (!IsChordDrawing || scroller?.contentViewport == null ||
                content?.notes == null || index < 0 || index >= content.notes.Count) return;
            string group = content.notes[index]?.chordGroupId;
            if (string.IsNullOrEmpty(group)) return;
            float top = float.MaxValue, bottom = float.MinValue;
            foreach (var member in content.notes)
            {
                if (member == null || member.chordGroupId != group) continue;
                float y = 25f + RowForPitch(member.pitch) * RowH;
                top = Mathf.Min(top, y);
                bottom = Mathf.Max(bottom, y + RowH);
            }
            float visible = scroller.contentViewport.resolvedStyle.height;
            if (top == float.MaxValue || visible < RowH * 2f || bottom - top > visible - 20f) return;
            Vector2 offset = scroller.scrollOffset;
            if (top >= offset.y + 10f && bottom <= offset.y + visible - 10f) return;
            float maxY = Mathf.Max(0f, 25f + EditorHeight - visible);
            scroller.scrollOffset = new Vector2(offset.x,
                Mathf.Clamp((top + bottom - visible) * 0.5f, 0f, maxY));
            SyncPianoRollLabels();
            SyncMidiNoteTouchTargets();
        }

        // Create one transparent, independent touch target for each MIDI note.
        // The rightmost portion is the resize anchor; the body moves the note.
        private void AddMidiNoteTouchTarget(int index)
        {
            if (noteTouchLayer == null || content?.notes == null ||
                index < 0 || index >= content.notes.Count || content.notes[index] == null) return;
            var hit = new VisualElement { name = "ZPunkMidiNoteHit_" + index };
            hit.style.position = Position.Absolute;
            hit.pickingMode = PickingMode.Position;
            var rightEnd = new VisualElement { name = "ZPunkMidiNoteRightEnd_" + index };
            rightEnd.style.position = Position.Absolute;
            rightEnd.style.right = 0;
            rightEnd.style.top = 0;
            rightEnd.style.bottom = 0;
            rightEnd.style.width = 12;
            rightEnd.pickingMode = PickingMode.Position;
            hit.Add(rightEnd);
            noteTouchLayer.Add(hit);
            midiNoteTouchTargets.Add(new MidiNoteTouchTarget { body = hit, noteIndex = index });

            hit.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || !IsMidi || drag != null ||
                    content?.notes == null || index >= content.notes.Count) return;
                var note = content.notes[index];
                if (note == null) return;
                SelectNoteVelocity(index);
                FocusSelectedMidiNote(index);
                var display = velocityDisplays.Find(v => v.noteIndex == index);
                Vector2 startPosition = MidiWorldToPlane(evt.position);
                drag = new Drag {
                    index = index, pointerId = evt.pointerId,
                    start = startPosition, startTick = note.startTick,
                    duration = note.durationTicks, pitch = note.pitch,
                    mode = ReferenceEquals(evt.target, rightEnd) ? MidiDragMode.ResizeEnd : MidiDragMode.Move,
                    preview = display != null ? display.cell : null, display = display,
                    latestWorldPosition = evt.position,
                    allowedScrollOffset = scroller.scrollOffset,
                    candidateTick = note.startTick, candidateDuration = note.durationTicks,
                    candidatePitch = note.pitch
                };
                if (IsChordDrawing && !string.IsNullOrEmpty(note.chordGroupId))
                {
                    drag.chordMembers = new List<ChordGestureNote>();
                    for (int i = 0; i < content.notes.Count; i++)
                    {
                        var member = content.notes[i];
                        if (member == null || member.chordGroupId != note.chordGroupId) continue;
                        drag.chordMembers.Add(new ChordGestureNote {
                            index = i, tick = member.startTick, duration = member.durationTicks,
                            pitch = member.pitch, candidateTick = member.startTick,
                            candidateDuration = member.durationTicks, candidatePitch = member.pitch,
                            display = velocityDisplays.Find(v => v.noteIndex == i)
                        });
                    }
                }
                RefreshVelocityDisplays();
                var active = drag;
                // Scheduled scrolling also works if the finger is held motionless
                // at an edge of the viewport.
                active.edgeScroll = hit.schedule.Execute(() =>
                    AutoScrollMidiDrag(active, hit)).Every(16);
                hit.CapturePointer(evt.pointerId);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (drag == null || drag.pointerId != evt.pointerId ||
                    !hit.HasPointerCapture(evt.pointerId)) return;
                drag.latestWorldPosition = evt.position;
                KeepMidiDragViewportLocked();
                Vector2 position = MidiWorldToPlane(evt.position);
                if ((position - drag.start).sqrMagnitude > MidiGestureThreshold * MidiGestureThreshold)
                    drag.moved = true;
                if (drag.moved) UpdateMidiDragPreview(drag, position);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerUpEvent>(evt =>
            {
                if (drag == null || drag.pointerId != evt.pointerId ||
                    !hit.HasPointerCapture(evt.pointerId)) return;
                var d = drag;
                KeepMidiDragViewportLocked();
                if (d.moved) UpdateMidiDragPreview(d, MidiWorldToPlane(evt.position));
                // Release capture first: Changed() rebuilds the overlay and
                // must not trigger cancellation of an already committed drag.
                EndMidiDragGesture(d);
                if (hit.HasPointerCapture(evt.pointerId)) hit.ReleasePointer(evt.pointerId);
                if (d.moved) CommitMidiDragGesture(d);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerCancelEvent>(evt =>
            {
                if (drag == null || drag.pointerId != evt.pointerId) return;
                RestoreMidiDragPreview(drag);
                EndMidiDragGesture(drag);
                if (hit.HasPointerCapture(evt.pointerId)) hit.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            hit.RegisterCallback<PointerCaptureOutEvent>(evt =>
            {
                if (drag == null || drag.pointerId != evt.pointerId) return;
                RestoreMidiDragPreview(drag);
                EndMidiDragGesture(drag);
            });
        }

        // Move the invisible targets together with their notes when the user
        // pans the piano roll. Only the note rectangles, not the empty overlay,
        // intercept pointer events.
        private void SyncMidiNoteTouchTargets()
        {
            if (noteTouchLayer == null || scroller == null || !IsMidi || content?.notes == null) return;
            Vector2 offset = scroller.scrollOffset;
            foreach (var target in midiNoteTouchTargets)
            {
                if (target.noteIndex < 0 || target.noteIndex >= content.notes.Count) continue;
                var note = content.notes[target.noteIndex];
                if (note == null) continue;
                var active = drag != null && drag.index == target.noteIndex ? drag : null;
                ChordGestureNote member = drag?.chordMembers?.Find(m => m.index == target.noteIndex);
                long tick = member != null ? member.candidateTick : active != null ? active.candidateTick : note.startTick;
                long duration = member != null ? member.candidateDuration : active != null ? active.candidateDuration : note.durationTicks;
                int pitch = member != null ? member.candidatePitch : active != null ? active.candidatePitch : note.pitch;
                target.body.style.left = (float)tick / quantum * StepW + 1f - offset.x;
                target.body.style.top = RowForPitch(pitch) * RowH + 4f - offset.y;
                target.body.style.width = Mathf.Max(13f, (float)duration / quantum * StepW - 2f);
                target.body.style.height = RowH - 7f;
            }
        }

        private void CommitMidiDragGesture(Drag d)
        {
            if (d == null) return;
            bool modified = d.candidateTick != d.startTick ||
                d.candidateDuration != d.duration || d.candidatePitch != d.pitch;
            if (!modified) { RestoreMidiDragPreview(d); return; }
            if (!Writable() || content?.notes == null || d.index < 0 || d.index >= content.notes.Count)
            {
                RestoreMidiDragPreview(d);
                return;
            }
            var note = content.notes[d.index];
            if (note == null) { RestoreMidiDragPreview(d); return; }
            if (d.chordMembers != null && d.chordMembers.Count > 0)
            {
                foreach (var member in d.chordMembers)
                {
                    if (member.index < 0 || member.index >= content.notes.Count ||
                        content.notes[member.index] == null) continue;
                    var n = content.notes[member.index];
                    n.startTick = member.candidateTick;
                    n.durationTicks = member.candidateDuration;
                    n.pitch = member.candidatePitch;
                    content.lengthTicks = Math.Max(content.lengthTicks, n.startTick + n.durationTicks);
                }
            }
            else
            {
                note.startTick = d.candidateTick;
                note.durationTicks = d.candidateDuration;
                note.pitch = d.candidatePitch;
                content.lengthTicks = Math.Max(content.lengthTicks, note.startTick + note.durationTicks);
            }
            selectedNote = d.index;
            // Selected note remains visible after a commit, including when the
            // viewport has followed the drag to a new pitch or beat.
            Changed();
            // Redraw restores the previous scroll offset on its next layout pass.
            // Focus the moved note AFTER that restoration so the viewport follows
            // its new location instead of jumping back to its original position.
            var focusedScroller = scroller;
            var focusedClipId = clipId;
            int focusedIndex = d.index;
            focusedScroller?.schedule.Execute(() =>
            {
                if (scroller == focusedScroller && clipId == focusedClipId &&
                    selectedNote == focusedIndex && IsMidi)
                    FocusSelectedChord(focusedIndex);
            }).ExecuteLater(20);
        }

        private void EndMidiDragGesture(Drag d)
        {
            if (d == null) return;
            d.edgeScroll?.Pause();
            if (ReferenceEquals(drag, d)) drag = null;
        }

        private void Redraw(bool preserveViewport=true)
        {
            if (!ready || root == null || chips == null || gridScrollContainer == null) return;
            // A refresh detaches the old note plane. Cancel any hold that was
            // scheduled against it before rebuilding the cells.
            if (pendingTap != null)
            {
                pendingTap.hold?.Pause();
                pendingTap = null;
            }
            EndMidiDragGesture(drag);
            // Refreshing note rectangles must not throw the user back to MIDI 127.
            // OCT +/- and initial track selection can still reposition afterwards.
            Vector2 previousOffset = scroller != null ? scroller.scrollOffset : Vector2.zero;
            if (!preserveViewport) ++noteFocusRevision;
            float chipX = trackScroller != null ? trackScroller.scrollOffset.x : 0f;
            chips.Clear();
            if (song == null || song.tracks == null) return;
            for (int i=0;i<song.tracks.Count;i++)
            {
                int index=i;
                bool isGeneratable = song.tracks[i].kind != TrackKind.Chops;
                bool suppressNextClick = false;
                bool pressing = false;
                bool moved = false;
                Vector2 down = Vector2.zero;
                IVisualElementScheduledItem hold = null;
                var item=EqualButton(song.tracks[i].name.ToUpperInvariant(),()=> {
                    if (suppressNextClick) { suppressNextClick = false; return; }
                    SelectTrack(index);
                });
                if (isGeneratable)
                {
                    item.RegisterCallback<PointerDownEvent>(evt => {
                        if (evt.button != 0) return;
                        hold?.Pause();
                        pressing = true;
                        moved = false;
                        down = evt.position;
                        hold = item.schedule.Execute(() => {
                            if (!pressing || moved) return;
                            suppressNextClick = true;
                            pressing = false;
                            OpenGenerator(index);
                        });
                        hold.ExecuteLater(525);
                    }, TrickleDown.TrickleDown);
                    item.RegisterCallback<PointerMoveEvent>(evt => {
                        if (pressing && ((Vector2)evt.position - down).sqrMagnitude > 196f)
                        {
                            moved = true;
                            pressing = false;
                            hold?.Pause();
                        }
                    }, TrickleDown.TrickleDown);
                    item.RegisterCallback<PointerUpEvent>(evt => { pressing = false; hold?.Pause(); }, TrickleDown.TrickleDown);
                    item.RegisterCallback<PointerCancelEvent>(evt => { pressing = false; hold?.Pause(); });
                    item.RegisterCallback<PointerCaptureOutEvent>(evt => { pressing = false; hold?.Pause(); });
                    item.RegisterCallback<DetachFromPanelEvent>(evt => { pressing = false; hold?.Pause(); });
                }
                var trackColor = colors[Mathf.Min(i, colors.Length - 1)];
                bool isSelectedTrack = i == trackIndex;
                item.style.backgroundColor = isSelectedTrack ? trackColor : Raised;
                item.style.color = isSelectedTrack ? new Color(.03f,.07f,.10f) : trackColor;
                item.style.borderTopWidth = 1;
                item.style.borderBottomWidth = 1;
                item.style.borderLeftWidth = 1;
                item.style.borderRightWidth = 1;
                item.style.borderTopColor = isSelectedTrack ? trackColor : new Color(trackColor.r, trackColor.g, trackColor.b, 0.82f);
                item.style.borderBottomColor = isSelectedTrack ? trackColor : new Color(trackColor.r, trackColor.g, trackColor.b, 0.82f);
                item.style.borderLeftColor = isSelectedTrack ? trackColor : new Color(trackColor.r, trackColor.g, trackColor.b, 0.82f);
                item.style.borderRightColor = isSelectedTrack ? trackColor : new Color(trackColor.r, trackColor.g, trackColor.b, 0.82f);
                chips.Add(item);
            }
            // SAMPLE moved to the existing 50pt CHOPS context row.
            // Six generous track buttons fit where five tracks + SAMPLE sat,
            // without a seventh narrow button or a hidden horizontal scroll.
            if (trackScroller != null)
                trackScroller.schedule.Execute(() => { if (trackScroller != null) trackScroller.scrollOffset = new Vector2(chipX, 0); }).ExecuteLater(0);
            RefreshKitSelector();
            var designButton = root.Q<Button>("ZPunkDrumDesignerButton");
            if (designButton != null) designButton.style.display = trackIndex == 0 ? DisplayStyle.Flex : DisplayStyle.None;
            RefreshClipSampleKeyReference();
            RefreshChordDrawToolbar();
            RefreshAcidNoteButtons();
            if (generatorQuickButton != null)
                generatorQuickButton.SetEnabled(song.tracks[trackIndex].kind != TrackKind.Chops);
            // Explicit navigation also makes NEW CLIP immediately useful when
            // a track has several patterns. Don't silently reopen clip one.
            var trackClips = song.tracks[trackIndex].clips;
            var orderedClips = new List<ClipData>();
            if (trackClips != null)
                foreach (var item in trackClips) if (item != null) orderedClips.Add(item);
            orderedClips.Sort((a, b) => {
                int cmp = a.startTick.CompareTo(b.startTick);
                return cmp != 0 ? cmp : string.CompareOrdinal(a.id, b.id);
            });
            int activeClip = orderedClips.FindIndex(c => c.id == clipId);
            if (previousClipButton != null) previousClipButton.SetEnabled(activeClip > 0);
            if (nextClipButton != null) nextClipButton.SetEnabled(activeClip >= 0 && activeClip < orderedClips.Count - 1);
            if (title != null) title.text = song.tracks[trackIndex].name.ToUpperInvariant() +
                "  /  " + (clip != null ? (activeClip + 1) + "/" + orderedClips.Count : "NO CLIP");
            if (info != null) info.text= clip == null ? "NO CLIP  /  HOLD TRACK TO GENERATE" :
                (!string.IsNullOrEmpty(content?.generatedTag) ? "GEN " + content.generatedTag :
                (IsMidi ? "PIANO ROLL" : content != null && content.kind==ClipKind.Drums ? "DRUM STEP EDITOR" : "SAMPLE STEP EDITOR") +
                "  /  Bar " + (clip.startTick / SongData.TicksPerBar4 + 1)) + "  /  HOLD TRACK TO GEN";
            gridScrollContainer.Clear();
            noteTouchLayer?.Clear();
            midiNoteTouchTargets.Clear();
            if (noteTouchLayer != null)
            {
                noteTouchLayer.style.display = IsMidi && clip != null && content != null ?
                    DisplayStyle.Flex : DisplayStyle.None;
                noteTouchLayer.style.left = IsMidi ? 57f : 83f;
            }
            rulerContent?.Clear();
            rulerPlayhead = null;
            pitchRowBackgrounds.Clear();
            pitchRowLabels.Clear();
            labelViewport?.Clear();
            labelColumn = null;
            if (labelViewport != null)
                labelViewport.style.display = clip != null && content != null ? DisplayStyle.Flex : DisplayStyle.None;
            velocityDisplays.Clear();
            RefreshVelocityRail();
            editorPlayhead = null;
            lastPlayheadX = -1f;
            if (clip==null || content==null) return;
            long editLength=Math.Max(clip.lengthTicks,content.lengthTicks);
            steps=Mathf.Clamp(Mathf.CeilToInt((float)editLength/quantum),16,4096);
            var names=Box(new Color(.095f,.13f,.18f));
            names.style.width=IsMidi ? 57f : 83f;
            names.style.position=Position.Absolute;
            names.style.left=0;
            names.style.top=0;
            names.style.flexShrink=0;
            names.style.flexGrow=0;
            if (labelViewport != null)
                labelViewport.style.width = IsMidi ? 57f : 83f;
            if (rulerGutter != null)
                rulerGutter.style.width = IsMidi ? 57f : 83f;
            names.style.borderTopLeftRadius=0;
            names.style.borderTopRightRadius=0;
            names.style.borderBottomLeftRadius=0;
            names.style.borderBottomRightRadius=0;
            var labelRulerSpacer = Txt("", 10);
            labelRulerSpacer.style.height = 25;
            labelRulerSpacer.style.minHeight = 25;
            labelRulerSpacer.style.maxHeight = 25;
            labelRulerSpacer.style.flexShrink = 0;
            names.Add(labelRulerSpacer);
            // Exact DrumKit.GetClipByDrumId() order: 1..8. No Tom/FX lanes.
            string[] drums={"KICK","SNARE","CLAP","CLOSED","OPEN","RIDE","RIM","CRASH"};
            for(int row=0;row<RowCount;row++)
            {
                string name=IsMidi? NoteName(PitchForRow(row)) : content.kind==ClipKind.Drums ? drums[row] : "S"+(row+1).ToString("00");
                var label=Txt(name,9,IsMidi && PitchForRow(row)%12==0?Accent:Muted);
                label.style.height=RowH;
                label.style.minHeight=RowH;
                label.style.maxHeight=RowH;
                label.style.flexShrink=0;
                label.style.flexGrow=0;
                label.style.paddingTop=0;
                label.style.paddingBottom=0;
                label.style.paddingLeft=5;
                label.style.marginTop=0;
                label.style.marginBottom=0;
                label.style.unityTextAlign=TextAnchor.MiddleLeft;
                names.Add(label);
                if (IsMidi) pitchRowLabels.Add(label);
            }
            labelColumn = names;
            labelViewport.Add(names);
            SyncPianoRollLabels();
            var grid=new VisualElement();
            canvas=grid;
            grid.style.position=Position.Relative;
            grid.style.flexShrink=0;
            grid.style.width=steps*StepW;
            grid.style.height=25+EditorHeight;
            grid.style.minHeight=25+EditorHeight;
            grid.style.backgroundColor=new Color(.055f,.075f,.112f);
            gridScrollContainer.Add(grid);
            // Every beat label lives in the pinned ruler, outside vertical scrolling.
            // The 1.1 / 1.2 / 1.3 / 1.4 notation is common to MIDI and step clips.
            if (rulerContent != null)
            {
                rulerContent.style.width = steps * StepW;
                for (int beat = 0; beat < steps; beat += 4)
                {
                    var num = Txt(((beat / 16) + 1) + "." + ((beat % 16) / 4 + 1), 11,
                        beat % 16 == 0 ? Ink : Muted);
                    num.style.position = Position.Absolute;
                    num.style.left = beat * StepW + 4;
                    num.style.top = 3;
                    num.style.height = 19;
                    num.pickingMode = PickingMode.Ignore;
                    rulerContent.Add(num);
                }
                SyncFixedRuler();
            }
            var plane=new VisualElement { name="ZPunkNotePlane" };
            plane.style.position=Position.Absolute;
            plane.style.left=0;
            plane.style.top=25;
            plane.style.width=steps*StepW;
            plane.style.height=EditorHeight;
            plane.style.minHeight=EditorHeight;
            grid.Add(plane);
            for(int row=0;row<RowCount;row++)
            {
                var background=new VisualElement();
                background.style.position=Position.Absolute;
                background.style.top=row*RowH;
                background.style.left=0;
                background.style.width=steps*StepW;
                background.style.height=RowH;
                background.style.backgroundColor=row%2==0?new Color(.11f,.145f,.19f):new Color(.09f,.12f,.16f);
                background.pickingMode=PickingMode.Ignore;
                plane.Add(background);
                if (IsMidi) pitchRowBackgrounds.Add(background);
            }
            ApplySampleKeyGuide();
            for(int step=0;step<=steps;step++)
            {
                var line=new VisualElement();
                line.style.position=Position.Absolute;
                line.style.left=step*StepW;
                line.style.top=0;
                line.style.width=step%16==0?2:1;
                line.style.height=EditorHeight;
                line.style.backgroundColor=step%16==0?new Color(.40f,.48f,.56f):
                    step%4==0?new Color(.24f,.31f,.40f):new Color(.16f,.21f,.29f);
                line.pickingMode=PickingMode.Ignore;
                plane.Add(line);
            }
            if (IsMidi && content.notes!=null)
            {
                for(int i=0;i<content.notes.Count;i++)
                {
                    var n=content.notes[i];
                    if(n==null) continue;
                    int row=RowForPitch(n.pitch);
                    if(row<0 || row>=RowCount) continue;
                    DrawEvent(plane,n.startTick,n.durationTicks,row,i,n.velocity);
                    AddMidiNoteTouchTarget(i);
                }
            }
            else if (content.kind == ClipKind.Drums && content.drums != null)
            {
                foreach (var hit in content.drums)
                {
                    if (hit != null && hit.lane >= 0 && hit.lane < RowCount)
                        DrawEvent(plane, hit.startTick, quantum, hit.lane, -1, hit.velocity);
                }
            }
            else if (content.kind == ClipKind.Chops && content.chops != null)
            {
                foreach (var chop in content.chops)
                {
                    if (chop != null && chop.sliceId >= 1 && chop.sliceId <= RowCount)
                        DrawEvent(plane, chop.startTick, quantum, chop.sliceId - 1, -1, chop.velocity);
                }
            }
            RefreshVelocityDisplays();
            SyncMidiNoteTouchTargets();
            // Shared transport playhead for all clip editors.
            // Covers both the timeline ruler and the note grid.
            editorPlayhead = new VisualElement
            {
                name = "ZPunkEditorPlayhead"
            };

            editorPlayhead.style.position = Position.Absolute;
            editorPlayhead.style.top = 0;
            editorPlayhead.style.left = 0;
            editorPlayhead.style.width = 3;
            editorPlayhead.style.height = 25 + EditorHeight;
            editorPlayhead.style.backgroundColor = Accent;
            editorPlayhead.style.opacity = 0.95f;

            editorPlayhead.pickingMode = PickingMode.Ignore;
            editorPlayhead.style.display = DisplayStyle.None;

            // Add to the outer grid so it spans the ruler and notes.
            // Adding it last also keeps it visible above the notes.
            grid.Add(editorPlayhead);
            if (rulerContent != null)
            {
                rulerPlayhead = new VisualElement { name = "ZPunkRulerPlayhead" };
                rulerPlayhead.style.position = Position.Absolute;
                rulerPlayhead.style.top = 0;
                rulerPlayhead.style.left = 0;
                rulerPlayhead.style.width = 2;
                rulerPlayhead.style.height = 25;
                rulerPlayhead.style.backgroundColor = Accent;
                rulerPlayhead.pickingMode = PickingMode.Ignore;
                rulerPlayhead.style.display = DisplayStyle.None;
                rulerContent.Add(rulerPlayhead);
            }
            plane.RegisterCallback<PointerDownEvent>(evt=>
            {
                if (evt.button != 0) return;
                Vector2 p = plane.WorldToLocal(evt.position);
                int row = RowAt(p.y), step = QuantizedStep(p.x);
                step = HitStepAtVisualPosition(row, step, p.x);
                // Existing MIDI notes are picked by the overlay, not this
                // ScrollView child. Empty cells remain regular grid touches.
                // A finger may be scrolling the piano roll. Defer creating a new
                // note/step until pointer up, and never create one during a swipe.
                var tap = new Tap { pointerId = evt.pointerId, start = evt.position, row = row, step = step };
                pendingTap = tap;
                if (!IsMidi && HasStepEvent(row, step * quantum))
                {
                    tap.hold = plane.schedule.Execute(() =>
                    {
                        if (!ReferenceEquals(pendingTap, tap)) return;
                        tap.handled = true;
                        SelectStepVelocity(tap.row, tap.step * quantum);
                        plane.CapturePointer(tap.pointerId);
                    });

                    tap.hold.ExecuteLater(440);
                }
            });
            plane.RegisterCallback<PointerMoveEvent>(evt=>
            {
                if (pendingTap != null && pendingTap.pointerId == evt.pointerId && pendingTap.handled)
                {
                    evt.StopPropagation();
                    return;
                }
                if (pendingTap != null && pendingTap.pointerId == evt.pointerId && !pendingTap.handled &&
                    ((Vector2)evt.position - pendingTap.start).sqrMagnitude > 49f)
                {
                    pendingTap.hold?.Pause();
                    pendingTap = null;
                }
                if (drag == null || drag.pointerId != evt.pointerId) return;
                drag.latestWorldPosition = evt.position;
                KeepMidiDragViewportLocked();
                Vector2 p = plane.WorldToLocal(evt.position);
                if ((p-drag.start).sqrMagnitude > MidiGestureThreshold * MidiGestureThreshold)
                    drag.moved = true;
                if (drag.moved) UpdateMidiDragPreview(drag, p);
                evt.StopPropagation();
            });
            plane.RegisterCallback<PointerUpEvent>(evt=>
            {
                if (pendingTap != null && pendingTap.pointerId == evt.pointerId)
                {
                    var tap = pendingTap;
                    pendingTap = null;
                    tap.hold?.Pause();
                    if (plane.HasPointerCapture(evt.pointerId)) plane.ReleasePointer(evt.pointerId);
                    if (!tap.handled && ((Vector2)evt.position - tap.start).sqrMagnitude <= 49f)
                    {
                        if (IsChordDrawing) InsertChord(PitchForRow(tap.row), tap.step);
                        else ToggleGrid(tap.row, tap.step);
                    }
                    evt.StopPropagation();
                    return;
                }
                if (drag == null || drag.pointerId != evt.pointerId) return;
                var d = drag;
                KeepMidiDragViewportLocked();
                // Finish the preview before releasing capture; otherwise the
                // scroll view may interpret the release as a pan or fling.
                if (d.moved)
                {
                    UpdateMidiDragPreview(d, MidiWorldToPlane(evt.position));
                    CommitMidiDragGesture(d);
                }
                EndMidiDragGesture(d);
                if (plane.HasPointerCapture(evt.pointerId)) plane.ReleasePointer(evt.pointerId);
                evt.StopPropagation();
            });
            plane.RegisterCallback<PointerCancelEvent>(evt =>
            {
                if (pendingTap != null && pendingTap.pointerId == evt.pointerId)
                {
                    pendingTap.hold?.Pause();
                    pendingTap = null;
                }
                if (drag != null && drag.pointerId == evt.pointerId)
                {
                    RestoreMidiDragPreview(drag);
                    EndMidiDragGesture(drag);
                }
                if (plane.HasPointerCapture(evt.pointerId)) plane.ReleasePointer(evt.pointerId);
            });
            plane.RegisterCallback<PointerCaptureOutEvent>(evt =>
            {
                if (pendingTap != null && pendingTap.pointerId == evt.pointerId)
                {
                    pendingTap.hold?.Pause();
                    pendingTap = null;
                }
                if (drag != null && drag.pointerId == evt.pointerId)
                {
                    RestoreMidiDragPreview(drag);
                    EndMidiDragGesture(drag);
                }
            });
            if (scroller != null)
                scroller.schedule.Execute(() =>
                {
                    if (scroller != null)
                    {
                        // New drum/chop clips start at the first lane; MIDI clips
                        // are positioned by FocusPatternNotes / ScrollToOctave.
                        if (preserveViewport) scroller.scrollOffset = previousOffset;
                        else if (!IsMidi) scroller.scrollOffset = Vector2.zero;
                        SyncPianoRollLabels();
                        SyncFixedRuler();
                        SyncMidiNoteTouchTargets();
                    }
                }).ExecuteLater(0);
        }
        private void SetEditorPlayheadVisible(bool visible)
        {
            var display = visible ? DisplayStyle.Flex : DisplayStyle.None;
            if (editorPlayhead != null) editorPlayhead.style.display = display;
            if (rulerPlayhead != null) rulerPlayhead.style.display = display;
            if (!visible) lastPlayheadX = -1f;
        }

        private void UpdateTrackScope()
        {
            if (!ready || trackScope == null || root == null || root.panel == null ||
                root.resolvedStyle.display == DisplayStyle.None || showingSampler ||
                song == null || song.tracks == null || trackIndex < 1 || trackIndex > 5 ||
                Time.unscaledTime < nextTrackScopeSample) return;
            nextTrackScopeSample = Time.unscaledTime + 1f / 24f;
            if (songTransport == null) songTransport = FindObjectOfType<ZPunkSongTransport>();
            if (drumEngine == null) FindDrumEngine();
            // Reuse the identical audio-derived meter sources used by MIX.
            // No native audio callbacks, DSP changes or generated motion.
            float bass = songTransport != null ? songTransport.GetTrackPeak(1) : 0f;
            float synth = songTransport != null ? songTransport.GetTrackPeak(2) : 0f;
            float pads = songTransport != null ? songTransport.GetTrackPeak(3) : 0f;
            float chops = drumEngine != null ? drumEngine.GetDAWChopPeak() : 0f;
            float acid = songTransport != null ? songTransport.GetTrackPeak(5) : 0f;
            trackScope.PushLevels(bass, synth, pads, chops, acid);
        }

        private void Update()
        {
            UpdateTrackScope();
            KeepMidiDragViewportLocked();
            // Sample-key guidance must continue updating when the transport is stopped.
            FollowPitchedSampleKey();
            if (!ready || editorPlayhead == null) return;

            if (songTransport == null)
                songTransport = FindObjectOfType<ZPunkSongTransport>();

            if (root == null || root.resolvedStyle.display == DisplayStyle.None ||
                showingSampler || songTransport == null || clip == null || content == null ||
                song == null || song.tracks == null || trackIndex < 0 ||
                trackIndex >= song.tracks.Count ||
                !songTransport.SongMode || !songTransport.IsPlaying)
            {
                SetEditorPlayheadVisible(false);
                return;
            }

            // Only display the neon cursor while this particular clip is being
            // played by the arrangement. Never wrap an inactive clip's timeline.
            TrackData track = song.tracks[trackIndex];
            if (track == null || track.mute || track.volume <= 0f)
            {
                SetEditorPlayheadVisible(false);
                return;
            }
            bool anotherTrackSoloed = false;
            bool thisTrackSoloed = track.solo;
            foreach (TrackData other in song.tracks)
                if (other != null && other.solo) { anotherTrackSoloed = true; break; }
            if (anotherTrackSoloed && !thisTrackSoloed)
            {
                SetEditorPlayheadVisible(false);
                return;
            }

            long globalTick = songTransport.CurrentTick;
            long clipRelativeTick = globalTick - clip.startTick;
            if (clipRelativeTick < 0 || clip.lengthTicks <= 0 ||
                clipRelativeTick >= clip.lengthTicks)
            {
                SetEditorPlayheadVisible(false);
                return;
            }

            // Match SongEventPlanner: non-loop clips end after their source
            // content has played; looping clips wrap at source-content length.
            long contentTicks = Math.Max(1L, content.lengthTicks);
            long sourceOffset = ((clip.sourceOffsetTick % contentTicks) + contentTicks) % contentTicks;
            long sourceTick = clipRelativeTick + sourceOffset;
            if (!clip.loopEnabled && sourceTick >= contentTicks)
            {
                SetEditorPlayheadVisible(false);
                return;
            }
            if (clip.loopEnabled) sourceTick %= contentTicks;

            // Throttle *position updates*, not the active/inactive visibility check.
            SetEditorPlayheadVisible(true);
            if (Time.unscaledTime < nextPlayheadPaint) return;
            nextPlayheadPaint = Time.unscaledTime + 1f / 30f;

            long visibleTicks = Math.Max(quantum, (long)steps * quantum);
            if (sourceTick >= visibleTicks)
            {
                SetEditorPlayheadVisible(false);
                return;
            }
            float x = Mathf.Max(1f, (float)sourceTick / quantum * StepW);
            if (Mathf.Abs(x - lastPlayheadX) >= 0.4f)
            {
                lastPlayheadX = x;
                editorPlayhead.style.left = x;
                if (rulerPlayhead != null) rulerPlayhead.style.left = x;
            }
        }
        private void DrawEvent(VisualElement plane, long tick, long duration, int row, int index, int eventVelocity)
        {
            float x = (float)tick / quantum * StepW;
            if (x >= steps * StepW) return;
            float w = Mathf.Max(13f, (float)duration / quantum * StepW - 2f);
            var e = Box(colors[Mathf.Min(trackIndex, colors.Length - 1)], 3);
            e.style.position = Position.Absolute;
            e.style.left = x + 1;
            e.style.top = row * RowH + 4;
            e.style.width = w;
            e.style.height = RowH - 7;
            e.pickingMode = PickingMode.Ignore; // Single plane handles all touch gestures.

            // Every occupied cell carries its own numerical velocity and a
            // proportional mini-meter. Neither adds a touch target to the grid.
            Label amount = null;
            if (w >= 28f)
            {
                amount = new Label(Mathf.Clamp(eventVelocity, 1, 127).ToString());
                amount.style.position = Position.Absolute;
                amount.style.left = 2;
                amount.style.top = 3;
                amount.style.width = Mathf.Min(31f, w - 5f);
                amount.style.height = 17;
                amount.style.fontSize = 10;
                amount.style.color = new Color(.045f, .07f, .10f);
                amount.style.unityTextAlign = TextAnchor.MiddleCenter;
                amount.pickingMode = PickingMode.Ignore;
                e.Add(amount);
            }
            var meter = Box(new Color(.045f, .075f, .10f, .82f), 1);
            meter.style.position = Position.Absolute;
            meter.style.left = 3;
            meter.style.bottom = 3;
            meter.style.height = 3;
            meter.style.width = 1;
            meter.pickingMode = PickingMode.Ignore;
            e.Add(meter);
            if (IsMidi && w > 20)
            {
                var grip = Box(new Color(.08f, .18f, .21f, .55f), 1);
                grip.style.position = Position.Absolute;
                grip.style.right = 2;
                grip.style.top = 2;
                grip.style.width = 3;
                grip.style.height = RowH - 11;
                grip.pickingMode = PickingMode.Ignore;
                e.Add(grip);
            }
            velocityDisplays.Add(new VelocityDisplay
            {
                cell = e, meter = meter, number = amount, row = row, noteIndex = index,
                tick = tick, width = w, velocity = eventVelocity
            });
            plane.Add(e);
        }
        private static string NoteName(int pitch)
        {
            string[] names={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
            return names[pitch%12]+(pitch/12-1);
        }
    }
}
